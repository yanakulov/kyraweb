<div align="center">
  <img src="assets/2d-lcd-mt32-web-player.png" alt="2D LCD display" />
  <h1><strong>MT-32 Web Player</strong></h1>
</div>


A static-site MIDI player for the Roland MT-32 and CM-32L.
Hybrid multi-engine architecture: authentic munt (libmt32emu) and TinySoundFont fallback.
<div>
  <p align="center">
   <img src="assets/3d-mt32.png" alt="3D MT-32 panel"/>
  </p>
</div>

> This project is **vibe-coded** — built through an iterative AI-assisted
> workflow. Contributions and code reviews are welcome.

## Features

- **Lil bit of MT-32 emulation** — munt (libmt32emu) compiled to WASM, with MT-32 ROM support
- **3D interactive panel** — a three.js-rendered MT-32 front panel with
  clickable controls
- **2D LCD mirror** — a large, readable replica of the MT-32 LCD alongside the 3D view
- **SoundFont fallback** — TinySoundFont engine for playing when no ROMs are available
- **Live MIDI input** — Web MIDI support for playing from a connected hardware MIDI device
- **No build step for users** — pure static site, no Node required

## Quick Start

```bash
# Use whatever static file server you like. For example, Python 3's built-in HTTP server:
# From the project root:
python -m http.server 8080
```

Then open [http://127.0.0.1:8080/](http://127.0.0.1:8080/) in a browser, voila!

> **Do not use `file://`** — WASM loading and AudioContext require HTTP serving.

## How to Use

* **Drop ROM files** onto the `#rom-drop` zone (MT-32: `MT32_CONTROL.ROM` + `MT32_PCM.ROM`;
   CM-32L: `CM32L_CONTROL.ROM` + `CM32L_PCM.ROM`), or **Drop a SoundFont** onto `#sf2-drop`
   for the TSF fallback engine.
* **Load a MIDI file** via `#mid-file`.
* Click **Play**.
* Alternatively, connect a MIDI device and allow the browser to access it. The engine will play incoming MIDI messages in real time.

The **3D panel controls** are interactive — best experienced with the **munt** engine.

## Screenshots

![MT-32 Web Player interface](assets/web-interface.png)

## Engines

| Engine | Source | License | ROM Required |
|--------|--------|---------|-------------|
| munt   | libmt32emu | LGPL-2.1+ | MT-32 or CM-32L |
| tsf    | TinySoundFont | MIT | None (SF2 only) |

See [NOTICE](NOTICE) for full license information.

## ROMs & Legal

**This project does NOT include or redistribute Roland® ROM data.**

**Trademarks:** Roland is a trademark of Roland Corp. All other brand and product
names are trademarks or registered trademarks of their respective holder. Use of
trademarks is for informational purposes only and does not imply endorsement by
or affiliation with the holder.

You must supply the ROM images yourself, dumped from a physical unit you own:

- **MT-32**: `MT32_CONTROL.ROM` + `MT32_PCM.ROM`
- **CM-32L**: `CM32L_CONTROL.ROM` + `CM32L_PCM.ROM`

ROM images are copyrighted material; obtaining them is your responsibility.
This project does not host, link to, or direct users to unofficial sources.

A **private bundle** can be configured later via the `MT32_PRIVATE_BUNDLE=1` flag
(see [tools/README.md](tools/README.md)). By default, the project never ships ROMs.

## SoundFonts

The TSF engine requires a `.sf2` file. A high-quality MT-32 SoundFont
can be used but is **not** shipped with this project.

## Build Requirements (for WASM engines)

- **emsdk** (Emscripten SDK) — required for compiling libmt32emu and TinySoundFont to WASM
- **Zig 0.16** (preferred host C/C++ compiler) or **CMake**

See [tools/README.md](tools/README.md) for detailed build instructions.

## License

Project code is LGPL-3.0+ (see [LICENSE](LICENSE)). Engine libraries carry their own
licenses (LGPL-2.1+, MIT). See [NOTICE](NOTICE).
