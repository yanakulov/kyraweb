#!/usr/bin/env bash
# MT-32 LCD SysEx generator
# Usage: ./sysex-lcd.sh [text] [unit]
set -euo pipefail

if [ $# -eq 0 ] || [ -z "$1" ]; then
  read -r -p "Enter text (20 chars max, default '  INSERT BUCKAZOID  '): " input
  TEXT="${input:-  INSERT BUCKAZOID  }"
else
  TEXT="$1"
fi
UNIT="${2:-17}"

# Pad/truncate to 20 chars
if [ ${#TEXT} -gt 20 ]; then
  TEXT="${TEXT:0:20}"
  echo "Warning: truncated to 20 chars" >&2
fi
while [ ${#TEXT} -lt 20 ]; do
  TEXT="$TEXT "
done

DEV=$(( (UNIT - 1) & 0x7F ))
ADDR=(0x20 0x00 0x00)

# Convert text to ASCII bytes
DATA=()
for ((i=0; i<${#TEXT}; i++)); do
  c="${TEXT:$i:1}"
  printf -v code '%d' "'$c"
  DATA+=($code)
done

# Roland checksum: (128 - sum(addr+data) & 0x7F) & 0x7F
SUM=0
for b in "${ADDR[@]}" "${DATA[@]}"; do
  SUM=$(( SUM + (b & 0x7F) ))
done
CHECKSUM=$(( (128 - (SUM & 0x7F)) & 0x7F ))

# Build SysEx
SYSEX=(0xF0 0x41 $DEV 0x16 0x12 "${ADDR[@]}" "${DATA[@]}" $CHECKSUM 0xF7)

# Format hex
HEX=""
for b in "${SYSEX[@]}"; do
  HEX+=$(printf '%02X ' "$b")
done

echo ""
echo "MT-32 LCD SysEx (${#TEXT} chars, unit $UNIT)"
echo "Text: [$TEXT]"
echo "Hex:  $HEX"
echo ""
echo "Paste for CC:"
echo "$HEX"
