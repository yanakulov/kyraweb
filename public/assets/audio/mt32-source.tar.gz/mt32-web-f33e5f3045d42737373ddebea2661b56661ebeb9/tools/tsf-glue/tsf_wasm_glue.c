/* LGPL-3.0-or-later glue for TinySoundFont WASM (vendor/TinySoundFont is MIT).
 * Copyright (C) 2026 not-hanjo-mei */
#define TSF_IMPLEMENTATION
#define TSF_NO_STDIO
#include "tsf.h"

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void *tsf_wasm_load(const uint8_t *data, int32_t size) {
  uint8_t *owned;
  tsf *f;
  if (!data || size <= 0) {
    return NULL;
  }
  owned = (uint8_t *)malloc((size_t)size);
  if (!owned) {
    return NULL;
  }
  memcpy(owned, data, (size_t)size);
  f = tsf_load_memory(owned, size);
  free(owned);
  return (void *)f;
}

void tsf_wasm_close(void *handle) {
  if (!handle) {
    return;
  }
  tsf_close((tsf *)handle);
}

void tsf_wasm_reset(void *handle) {
  if (!handle) {
    return;
  }
  tsf_reset((tsf *)handle);
}

void tsf_wasm_set_output(void *handle, int32_t sample_rate, float gain_db) {
  if (!handle || sample_rate <= 0) {
    return;
  }
  tsf_set_output((tsf *)handle, TSF_STEREO_INTERLEAVED, sample_rate, gain_db);
}

int32_t tsf_wasm_set_max_voices(void *handle, int32_t max_voices) {
  if (!handle) {
    return 0;
  }
  return tsf_set_max_voices((tsf *)handle, max_voices);
}

void tsf_wasm_channel_setup(void *handle, int32_t channels) {
  int i;
  if (!handle) {
    return;
  }
  if (channels < 1) {
    channels = 16;
  }
  if (channels > 16) {
    channels = 16;
  }
  for (i = 0; i < channels; i++) {
    int drums = (i == 9) ? 1 : 0;
    tsf_channel_set_bank_preset((tsf *)handle, i, drums ? 128 : 0, 0);
  }
}

int32_t tsf_wasm_channel_note_on(void *handle, int32_t channel, int32_t key, float vel) {
  if (!handle) {
    return 0;
  }
  return tsf_channel_note_on((tsf *)handle, channel, key, vel);
}

void tsf_wasm_channel_note_off(void *handle, int32_t channel, int32_t key) {
  if (!handle) {
    return;
  }
  tsf_channel_note_off((tsf *)handle, channel, key);
}

void tsf_wasm_channel_note_off_all(void *handle, int32_t channel) {
  if (!handle) {
    return;
  }
  tsf_channel_note_off_all((tsf *)handle, channel);
}

void tsf_wasm_note_off_all(void *handle) {
  if (!handle) {
    return;
  }
  tsf_note_off_all((tsf *)handle);
}

int32_t tsf_wasm_channel_midi_control(void *handle, int32_t channel, int32_t controller,
                                      int32_t value) {
  if (!handle) {
    return 0;
  }
  return tsf_channel_midi_control((tsf *)handle, channel, controller, value);
}

int32_t tsf_wasm_channel_set_pitchwheel(void *handle, int32_t channel, int32_t pitch_wheel) {
  if (!handle) {
    return 0;
  }
  return tsf_channel_set_pitchwheel((tsf *)handle, channel, pitch_wheel);
}

int32_t tsf_wasm_channel_set_presetnumber(void *handle, int32_t channel, int32_t preset_number,
                                          int32_t flag_mididrums) {
  if (!handle) {
    return 0;
  }
  return tsf_channel_set_presetnumber((tsf *)handle, channel, preset_number, flag_mididrums);
}

int32_t tsf_wasm_channel_set_bank_preset(void *handle, int32_t channel, int32_t bank,
                                         int32_t preset_number) {
  if (!handle) {
    return 0;
  }
  return tsf_channel_set_bank_preset((tsf *)handle, channel, bank, preset_number);
}

void tsf_wasm_render_float(void *handle, float *buffer, int32_t samples, int32_t flag_mixing) {
  if (!handle || !buffer || samples <= 0) {
    return;
  }
  tsf_render_float((tsf *)handle, buffer, samples, flag_mixing);
}

int32_t tsf_wasm_get_presetcount(void *handle) {
  if (!handle) {
    return 0;
  }
  return tsf_get_presetcount((tsf *)handle);
}

int32_t tsf_wasm_active_voice_count(void *handle) {
  if (!handle) {
    return 0;
  }
  return tsf_active_voice_count((tsf *)handle);
}

void *tsf_wasm_malloc(uint32_t size) {
  return malloc((size_t)size);
}

void tsf_wasm_free_buf(void *ptr) {
  free(ptr);
}
