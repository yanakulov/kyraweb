﻿<#
.SYNOPSIS
    Builds libmt32emu (munt) + thin C glue to WASM via Emscripten.
.DESCRIPTION
    1. Ensures vendor/munt/mt32emu source is present
    2. Configures static lib with emcmake (C interface ON)
    3. Builds with emmake / cmake --build
    4. Links glue + static lib into wasm/mt32emu.{js,wasm}
    5. Writes js/engine/munt/glue.js

    Activate emsdk first:
      . <path-to-emsdk>\emsdk_env.ps1
.NOTES
    Host: Windows + emsdk 3.1.73+, CMake 3.5+, mingw32-make.
    WASM via emcc only (not Zig). Separate .wasm (not SINGLE_FILE) for LGPL.
#>

$ErrorActionPreference = "Stop"
$ProjectRoot = [System.IO.Path]::GetDirectoryName($PSScriptRoot)
$WasmDir = Join-Path -Path $ProjectRoot -ChildPath "wasm"
$GlueJsDir = Join-Path -Path $ProjectRoot -ChildPath "js\engine\munt"
$SourceDir = Join-Path -Path $ProjectRoot -ChildPath "vendor\munt\mt32emu"
$GlueSrc = Join-Path -Path $PSScriptRoot -ChildPath "mt32emu-glue\mt32emu_wasm_glue.c"
$BuildDir = Join-Path -Path $ProjectRoot -ChildPath "build\mt32emu-wasm"
$EmsdkDefault = if ($env:EMSDK_PATH) { $env:EMSDK_PATH } else { "$env:USERPROFILE\emsdk" }

Write-Host "=== build-mt32emu.ps1 ===" -ForegroundColor Cyan
Write-Host "Project root : $ProjectRoot"
Write-Host "Wasm output  : $WasmDir"
Write-Host "Source       : $SourceDir"
Write-Host "Glue         : $GlueSrc"
Write-Host ""

$emcc = Get-Command emcc -ErrorAction SilentlyContinue
if (-not $emcc) {
    $envPs1 = Join-Path -Path $EmsdkDefault -ChildPath "emsdk_env.ps1"
    if (Test-Path -LiteralPath $envPs1) {
        Write-Host "[INFO] Sourcing $envPs1"
        $env:EMSDK_QUIET = "1"
        . $envPs1
        $emcc = Get-Command emcc -ErrorAction SilentlyContinue
    }
}
if (-not $emcc) {
    Write-Host "[ERROR] emcc not found on PATH." -ForegroundColor Red
    Write-Host "Install emsdk at: $EmsdkDefault"
    Write-Host "  git clone https://github.com/emscripten-core/emsdk.git $EmsdkDefault"
    Write-Host "  cd $EmsdkDefault"
    Write-Host "  .\emsdk install 3.1.73"
    Write-Host "  .\emsdk activate 3.1.73"
    Write-Host "  . .\emsdk_env.ps1"
    exit 1
}
Write-Host "[OK] emcc: $($emcc.Source)"

$emcmake = Get-Command emcmake -ErrorAction SilentlyContinue
if (-not $emcmake) {
    Write-Host "[ERROR] emcmake not found" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path -LiteralPath (Join-Path -Path $SourceDir -ChildPath "CMakeLists.txt"))) {
    Write-Host "[INFO] Cloning munt (mt32emu only) into vendor/munt ..."
    $vendorMunt = Join-Path -Path $ProjectRoot -ChildPath "vendor\munt"
    if (Test-Path -LiteralPath $vendorMunt) {
        Remove-Item -LiteralPath $vendorMunt -Recurse -Force
    }
    git clone --depth 1 --filter=blob:none --sparse https://github.com/munt/munt.git $vendorMunt
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    Push-Location $vendorMunt
    git sparse-checkout set mt32emu
    Pop-Location
}
if (-not (Test-Path -LiteralPath (Join-Path -Path $SourceDir -ChildPath "CMakeLists.txt"))) {
    Write-Host "[ERROR] libmt32emu source missing at $SourceDir" -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath $GlueSrc)) {
    Write-Host "[ERROR] Glue source missing: $GlueSrc" -ForegroundColor Red
    exit 1
}
Write-Host "[OK] libmt32emu source + glue present"

if (Test-Path -LiteralPath $BuildDir) {
    Remove-Item -LiteralPath $BuildDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $WasmDir | Out-Null
New-Item -ItemType Directory -Force -Path $GlueJsDir | Out-Null

Write-Host ""
Write-Host "[1/3] emcmake cmake configure (static, C interface)..." -ForegroundColor Cyan
$cmakeArgs = @(
    "cmake",
    $SourceDir,
    "-DCMAKE_BUILD_TYPE=Release",
    "-Dlibmt32emu_SHARED=OFF",
    "-Dlibmt32emu_C_INTERFACE=ON",
    "-Dlibmt32emu_CPP_INTERFACE=OFF",
    "-Dlibmt32emu_WITH_INTERNAL_RESAMPLER=ON",
    "-DBUILD_TESTING=OFF",
    "-Dlibmt32emu_BUILD_TESTING=OFF"
)

Push-Location $BuildDir
try {
    & emcmake @cmakeArgs
    if ($LASTEXITCODE -ne 0) {
        throw "emcmake cmake failed with exit $LASTEXITCODE"
    }

    Write-Host ""
    Write-Host "[2/3] emmake / cmake --build..." -ForegroundColor Cyan
    $jobs = [Environment]::ProcessorCount
    if ($jobs -lt 1) { $jobs = 2 }
    & emmake cmake --build . --config Release -j $jobs
    if ($LASTEXITCODE -ne 0) {
        throw "library build failed with exit $LASTEXITCODE"
    }
} finally {
    Pop-Location
}

$libCandidates = @(
    (Join-Path -Path $BuildDir -ChildPath "libmt32emu.a"),
    (Join-Path -Path $BuildDir -ChildPath "libmt32emu.lib"),
    (Join-Path -Path $BuildDir -ChildPath "Release\libmt32emu.a"),
    (Join-Path -Path $BuildDir -ChildPath "Release\mt32emu.lib")
)
$staticLib = $null
foreach ($c in $libCandidates) {
    if (Test-Path -LiteralPath $c) {
        $staticLib = $c
        break
    }
}
if (-not $staticLib) {
    $found = Get-ChildItem -Path $BuildDir -Recurse -Include "libmt32emu.a","libmt32emu.lib","mt32emu.lib" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($found) { $staticLib = $found.FullName }
}
if (-not $staticLib) {
    Write-Host "[ERROR] Could not find built libmt32emu static library under $BuildDir" -ForegroundColor Red
    exit 1
}
Write-Host "[OK] Static lib: $staticLib"

$incPublic = Join-Path -Path $BuildDir -ChildPath "include"
$incSrc = Join-Path -Path $SourceDir -ChildPath "src"
if (-not (Test-Path -LiteralPath $incPublic)) {
    Write-Host "[ERROR] Public headers missing at $incPublic" -ForegroundColor Red
    exit 1
}
Write-Host "[OK] include: $incPublic"

Write-Host ""
Write-Host "[3/3] emcc link glue + lib -> wasm/mt32emu.js + .wasm" -ForegroundColor Cyan

$outJs = Join-Path -Path $WasmDir -ChildPath "mt32emu.js"
$exports = "_mt32_create,_mt32_free,_mt32_add_rom_data,_mt32_open,_mt32_close,_mt32_is_open,_mt32_play_msg,_mt32_play_sysex,_mt32_render_float,_mt32_render_bit16s,_mt32_get_samplerate,_mt32_set_samplerate,_mt32_library_version,_mt32_get_display_state,_mt32_set_main_display_mode,_mt32_set_display_compatibility,_mt32_is_display_old_mt32_compatible,_mt32_is_default_display_old_mt32_compatible,_mt32_malloc,_mt32_free_buf,_malloc,_free"
$exportRuntime = "ccall,cwrap,HEAPU8,HEAPF32,HEAP16,UTF8ToString,getValue,setValue"

$emccArgs = @(
    $GlueSrc,
    $staticLib,
    "-O2",
    "-I$incPublic",
    "-I$incSrc",
    "-sALLOW_MEMORY_GROWTH=1",
    "-sINITIAL_MEMORY=33554432",
    "-sSTACK_SIZE=1048576",
    "-sMODULARIZE=1",
    "-sEXPORT_NAME=createMt32EmuModule",
    "-sENVIRONMENT=web,worker",
    "-sFILESYSTEM=0",
    "-sEXPORTED_FUNCTIONS=$exports",
    "-sEXPORTED_RUNTIME_METHODS=$exportRuntime",
    "-sNO_EXIT_RUNTIME=1",
    "-sDISABLE_EXCEPTION_CATCHING=1",
    "-o", $outJs
)

& emcc @emccArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] emcc link failed" -ForegroundColor Red
    exit $LASTEXITCODE
}

$outWasm = Join-Path -Path $WasmDir -ChildPath "mt32emu.wasm"
if (-not (Test-Path -LiteralPath $outWasm)) {
    Write-Host "[ERROR] Expected $outWasm not produced" -ForegroundColor Red
    exit 1
}

$helperJs = Join-Path -Path $GlueJsDir -ChildPath "glue.js"
Copy-Item -LiteralPath (Join-Path -Path $PSScriptRoot -ChildPath "..\js\engine\munt\glue.js") -Destination $helperJs -Force -ErrorAction SilentlyContinue
if (-not (Test-Path -LiteralPath $helperJs)) {
    Write-Host "[WARN] js/engine/munt/glue.js missing; create manually if needed"
}

$wasmSize = (Get-Item -LiteralPath $outWasm).Length
$jsSize = (Get-Item -LiteralPath $outJs).Length
Write-Host ""
Write-Host "[DONE] Built munt WASM:" -ForegroundColor Green
Write-Host "  $outWasm  ($wasmSize bytes)"
Write-Host "  $outJs    ($jsSize bytes)"
Write-Host "  helper: js/engine/munt/glue.js"
Write-Host ""
Write-Host "emsdk path used: $env:EMSDK"
Write-Host "Activate: . $EmsdkDefault\emsdk_env.ps1"
exit 0
