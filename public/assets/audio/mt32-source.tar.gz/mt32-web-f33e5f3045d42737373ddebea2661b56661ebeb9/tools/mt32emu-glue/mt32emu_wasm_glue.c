﻿/* LGPL-3.0-or-later glue for libmt32emu WASM (vendor/munt is LGPL-2.1+).
 * Copyright (C) 2026 not-hanjo-mei */

#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "mt32emu.h"

typedef struct mt32_wasm_state {
  mt32emu_context ctx;
  uint8_t *control_rom;
  size_t control_rom_size;
  uint8_t *pcm_rom;
  size_t pcm_rom_size;
} mt32_wasm_state;

static mt32emu_report_handler_i g_null_report = {NULL};

mt32_wasm_state *mt32_create(void) {
  mt32_wasm_state *st = (mt32_wasm_state *)calloc(1, sizeof(mt32_wasm_state));
  if (!st) {
    return NULL;
  }
  st->ctx = mt32emu_create_context(g_null_report, NULL);
  if (!st->ctx) {
    free(st);
    return NULL;
  }
  return st;
}

void mt32_free(mt32_wasm_state *st) {
  if (!st) {
    return;
  }
  if (st->ctx) {
    if (mt32emu_is_open(st->ctx)) {
      mt32emu_close_synth(st->ctx);
    }
    mt32emu_free_context(st->ctx);
    st->ctx = NULL;
  }
  free(st->control_rom);
  free(st->pcm_rom);
  free(st);
}

int32_t mt32_add_rom_data(mt32_wasm_state *st, const uint8_t *data, uint32_t size, int32_t type) {
  uint8_t *copy;
  mt32emu_return_code rc;

  if (!st || !st->ctx || !data || size == 0) {
    return (int32_t)MT32EMU_RC_FAILED;
  }

  copy = (uint8_t *)malloc((size_t)size);
  if (!copy) {
    return (int32_t)MT32EMU_RC_FAILED;
  }
  memcpy(copy, data, (size_t)size);

  if (type == 0) {
    free(st->control_rom);
    st->control_rom = copy;
    st->control_rom_size = (size_t)size;
  } else {
    free(st->pcm_rom);
    st->pcm_rom = copy;
    st->pcm_rom_size = (size_t)size;
  }

  rc = mt32emu_add_rom_data(st->ctx, copy, (size_t)size, NULL);
  return (int32_t)rc;
}

int32_t mt32_open(mt32_wasm_state *st) {
  if (!st || !st->ctx) {
    return (int32_t)MT32EMU_RC_FAILED;
  }
  return (int32_t)mt32emu_open_synth(st->ctx);
}

void mt32_close(mt32_wasm_state *st) {
  if (st && st->ctx) {
    mt32emu_close_synth(st->ctx);
  }
}

int32_t mt32_is_open(mt32_wasm_state *st) {
  if (!st || !st->ctx) {
    return 0;
  }
  return mt32emu_is_open(st->ctx) ? 1 : 0;
}

int32_t mt32_play_msg(mt32_wasm_state *st, uint32_t msg) {
  if (!st || !st->ctx) {
    return (int32_t)MT32EMU_RC_FAILED;
  }
  return (int32_t)mt32emu_play_msg(st->ctx, msg);
}

int32_t mt32_play_sysex(mt32_wasm_state *st, const uint8_t *sysex, uint32_t len) {
  if (!st || !st->ctx || !sysex || len == 0) {
    return (int32_t)MT32EMU_RC_FAILED;
  }
  return (int32_t)mt32emu_play_sysex(st->ctx, sysex, len);
}

void mt32_render_float(mt32_wasm_state *st, float *stream, uint32_t len) {
  if (!st || !st->ctx || !stream || len == 0) {
    return;
  }
  mt32emu_render_float(st->ctx, stream, len);
}

void mt32_render_bit16s(mt32_wasm_state *st, int16_t *stream, uint32_t len) {
  if (!st || !st->ctx || !stream || len == 0) {
    return;
  }
  mt32emu_render_bit16s(st->ctx, stream, len);
}

uint32_t mt32_get_samplerate(mt32_wasm_state *st) {
  if (!st || !st->ctx) {
    return 0;
  }
  return mt32emu_get_actual_stereo_output_samplerate(st->ctx);
}

void mt32_set_samplerate(mt32_wasm_state *st, double rate) {
  if (!st || !st->ctx) {
    return;
  }
  mt32emu_set_stereo_output_samplerate(st->ctx, rate);
}

const char *mt32_library_version(void) {
  return mt32emu_get_library_version_string();
}

int32_t mt32_get_display_state(mt32_wasm_state *st, char *target_buffer, int32_t narrow_lcd) {
  if (!st || !st->ctx || !target_buffer) {
    return 0;
  }
  if (!mt32emu_is_open(st->ctx)) {
    target_buffer[0] = '\0';
    return 0;
  }
  return mt32emu_get_display_state(
             st->ctx,
             target_buffer,
             narrow_lcd ? MT32EMU_BOOL_TRUE : MT32EMU_BOOL_FALSE)
             ? 1
             : 0;
}

void mt32_set_main_display_mode(mt32_wasm_state *st) {
  if (!st || !st->ctx || !mt32emu_is_open(st->ctx)) {
    return;
  }
  mt32emu_set_main_display_mode(st->ctx);
}

void mt32_set_display_compatibility(mt32_wasm_state *st, int32_t old_mt32_compatibility_enabled) {
  if (!st || !st->ctx || !mt32emu_is_open(st->ctx)) {
    return;
  }
  mt32emu_set_display_compatibility(
      st->ctx,
      old_mt32_compatibility_enabled ? MT32EMU_BOOL_TRUE : MT32EMU_BOOL_FALSE);
}

int32_t mt32_is_display_old_mt32_compatible(mt32_wasm_state *st) {
  if (!st || !st->ctx || !mt32emu_is_open(st->ctx)) {
    return 0;
  }
  return mt32emu_is_display_old_mt32_compatible(st->ctx) ? 1 : 0;
}

int32_t mt32_is_default_display_old_mt32_compatible(mt32_wasm_state *st) {
  if (!st || !st->ctx || !mt32emu_is_open(st->ctx)) {
    return 0;
  }
  return mt32emu_is_default_display_old_mt32_compatible(st->ctx) ? 1 : 0;
}

void *mt32_malloc(uint32_t size) {
  return malloc((size_t)size);
}

void mt32_free_buf(void *p) {
  free(p);
}
