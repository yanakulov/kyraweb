<#
.SYNOPSIS
    Builds TinySoundFont to WASM via Emscripten.
.DESCRIPTION
    Compiles tsf_wasm_glue.c (includes tsf.h with TSF_IMPLEMENTATION) to
    wasm/tsf.wasm + wasm/tsf.js (MODULARIZE, createTsfModule).

    Activate emsdk first:
      . <path-to-emsdk>\emsdk_env.ps1
#>

$ErrorActionPreference = "Stop"
$ProjectRoot = [System.IO.Path]::GetDirectoryName($PSScriptRoot)
$WasmDir = Join-Path -Path $ProjectRoot -ChildPath "wasm"
$SourceDir = Join-Path -Path $ProjectRoot -ChildPath "vendor\TinySoundFont"
$GlueSrc = Join-Path -Path $PSScriptRoot -ChildPath "tsf-glue\tsf_wasm_glue.c"
$EmsdkDefault = if ($env:EMSDK_PATH) { $env:EMSDK_PATH } else { "$env:USERPROFILE\emsdk" }

Write-Host "=== build-tsf.ps1 ===" -ForegroundColor Cyan
Write-Host "Project root : $ProjectRoot"
Write-Host "Wasm output  : $WasmDir"
Write-Host "Source       : $SourceDir"
Write-Host "Glue         : $GlueSrc"
Write-Host ""

$emcc = Get-Command emcc -ErrorAction SilentlyContinue
if (-not $emcc) {
    $envPs1 = Join-Path -Path $EmsdkDefault -ChildPath "emsdk_env.ps1"
    if (Test-Path -LiteralPath $envPs1) {
        Write-Host "[INFO] Sourcing $envPs1"
        $env:EMSDK_QUIET = "1"
        . $envPs1
        $emcc = Get-Command emcc -ErrorAction SilentlyContinue
    }
}
if (-not $emcc) {
    Write-Host "[ERROR] emcc not found on PATH." -ForegroundColor Red
    Write-Host "Install emsdk: $EmsdkDefault then . .\emsdk_env.ps1"
    exit 1
}
Write-Host "[OK] emcc: $($emcc.Source)"

if (-not (Test-Path -LiteralPath (Join-Path -Path $SourceDir -ChildPath "tsf.h"))) {
    Write-Host "[ERROR] TinySoundFont tsf.h missing at $SourceDir" -ForegroundColor Red
    Write-Host "Download: https://github.com/schellingb/TinySoundFont (MIT)"
    exit 1
}
if (-not (Test-Path -LiteralPath $GlueSrc)) {
    Write-Host "[ERROR] Glue missing: $GlueSrc" -ForegroundColor Red
    exit 1
}
Write-Host "[OK] TinySoundFont source + glue present"

New-Item -ItemType Directory -Force -Path $WasmDir | Out-Null

$outJs = Join-Path -Path $WasmDir -ChildPath "tsf.js"
$exports = "_tsf_wasm_load,_tsf_wasm_close,_tsf_wasm_reset,_tsf_wasm_set_output,_tsf_wasm_set_max_voices,_tsf_wasm_channel_setup,_tsf_wasm_channel_note_on,_tsf_wasm_channel_note_off,_tsf_wasm_channel_note_off_all,_tsf_wasm_note_off_all,_tsf_wasm_channel_midi_control,_tsf_wasm_channel_set_pitchwheel,_tsf_wasm_channel_set_presetnumber,_tsf_wasm_channel_set_bank_preset,_tsf_wasm_render_float,_tsf_wasm_get_presetcount,_tsf_wasm_active_voice_count,_tsf_wasm_malloc,_tsf_wasm_free_buf,_malloc,_free"
$exportRuntime = "ccall,cwrap,HEAPU8,HEAPF32,HEAP16,UTF8ToString,getValue,setValue"

Write-Host ""
Write-Host "[1/1] emcc compile glue -> wasm/tsf.js + .wasm" -ForegroundColor Cyan

$emccArgs = @(
    $GlueSrc,
    "-O2",
    "-I$SourceDir",
    "-sALLOW_MEMORY_GROWTH=1",
    "-sINITIAL_MEMORY=67108864",
    "-sSTACK_SIZE=1048576",
    "-sMODULARIZE=1",
    "-sEXPORT_NAME=createTsfModule",
    "-sENVIRONMENT=web,worker",
    "-sFILESYSTEM=0",
    "-sEXPORTED_FUNCTIONS=$exports",
    "-sEXPORTED_RUNTIME_METHODS=$exportRuntime",
    "-sNO_EXIT_RUNTIME=1",
    "-sDISABLE_EXCEPTION_CATCHING=1",
    "-o", $outJs
)

& emcc @emccArgs
if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] emcc failed" -ForegroundColor Red
    exit $LASTEXITCODE
}

$outWasm = Join-Path -Path $WasmDir -ChildPath "tsf.wasm"
if (-not (Test-Path -LiteralPath $outWasm)) {
    Write-Host "[ERROR] Expected $outWasm not produced" -ForegroundColor Red
    exit 1
}

$wasmSize = (Get-Item -LiteralPath $outWasm).Length
$jsSize = (Get-Item -LiteralPath $outJs).Length
Write-Host ""
Write-Host "[DONE] Built TinySoundFont WASM:" -ForegroundColor Green
Write-Host "  $outWasm  ($wasmSize bytes)"
Write-Host "  $outJs    ($jsSize bytes)"
Write-Host "  helper: js/engine/tsf/glue.js"
Write-Host ""
Write-Host "Activate: . $EmsdkDefault\emsdk_env.ps1"
exit 0
