# Toolchain & Build Guide

This directory contains build scripts and documentation for compiling the
WASM engines used by MT-32 Web Player.

## Build Requirements (v1)

| Tool | Required | Version | For |
|------|----------|---------|-----|
| **emsdk** (Emscripten) | **Yes** | 3.1.73+ recommended | Compiling munt & TSF to WASM |
| **Zig** | Preferred host C/C++ | **0.16** (on dev machine) | Cross-compiling C sources |
| **CMake** | Alternative host | **4.2.0** (on dev machine) | Configuring builds |
| **MinGW GCC** | Available fallback | **8.1.0** (on dev machine) | Host-side test builds |

---

## Setting up emsdk

### Windows

**Documented install path (this machine):**
`<emsdk-install>` (e.g. `C:\Users\<you>\emsdk`)

```powershell
# Install (one-time):
git clone https://github.com/emscripten-core/emsdk.git <emsdk-install>
cd <emsdk-install>
.\emsdk install 3.1.73
.\emsdk activate 3.1.73

# Activate in current shell (required every new session):
. .\emsdk_env.ps1

# Verify:
emcc --version
```

> The emsdk path should be added to `PATH` or sourced via `emsdk_env.ps1`
> before running any build scripts. `build-mt32emu.ps1` will try to auto-source
> the path above if `emcc` is missing.

### libmt32emu (munt) WASM

```powershell
. <emsdk-install>\emsdk_env.ps1
cd mt32-web
.\tools\build-mt32emu.ps1
```

Produces:

| Artifact | Path |
|----------|------|
| WASM binary | `wasm/mt32emu.wasm` |
| Emscripten JS | `wasm/mt32emu.js` (`createMt32EmuModule`) |
| App glue | `js/engine/munt/glue.js` |

CMake flags: `libmt32emu_SHARED=OFF`, `libmt32emu_C_INTERFACE=ON`,
`libmt32emu_CPP_INTERFACE=OFF`, `BUILD_TESTING=OFF`.
Exported C glue: `mt32_create`, `mt32_add_rom_data`, `mt32_open`, `mt32_play_msg`,
`mt32_play_sysex`, `mt32_render_float`, `mt32_render_bit16s`, `mt32_free`, …

---

## Engine Build Scripts

| Script | Target | Requires |
|--------|--------|----------|
| `build-mt32emu.ps1` | `wasm/mt32emu.wasm` + JS glue | emsdk |
| `build-tsf.ps1` | `wasm/tsf.wasm` + `wasm/tsf.js` (`createTsfModule`) | emsdk |

Each script prints out the build steps it performs. They can be run from the
project root:

```powershell
cd mt32-web
.\tools\build-mt32emu.ps1
```

### TinySoundFont WASM

```powershell
. <emsdk-install>\emsdk_env.ps1
cd mt32-web
.\tools\build-tsf.ps1
```

Produces `wasm/tsf.wasm` + `wasm/tsf.js` (`createTsfModule`). Source: `vendor/TinySoundFont/tsf.h` (MIT). Glue: `tools/tsf-glue/tsf_wasm_glue.c`. QA fixture: `fixtures/tiny.sf2`.

---

## Private ROM Bundle

For development convenience, you can place ROM files under `private/roms/`:

```
private/roms/
├── MT32_CONTROL.ROM
├── MT32_PCM.ROM
├── CM32L_CONTROL.ROM
└── CM32L_PCM.ROM
```

These files are gitignored and never committed.

When the build system encounters `MT32_PRIVATE_BUNDLE=1` and finds a complete
ROM set in `private/roms/`, it embeds the ROMs directly into the WASM binary
so end users don't need to drag-and-drop ROM files.

> Legal: Do NOT distribute the resulting bundle. Private bundles are for
> personal/development use only — the embedded ROMs are copyrighted Roland
> material, and distributing the bundle would redistribute them.

---

## Zig note

Zig v0.16 is what was used as the C/C++ compiler for the project. When both
Zig and CMake are available, the build scripts default to Zig because it
provides cross-compilation out of the box (no need for a separate emsdk host
toolchain).

Zig install ref: <https://ziglang.org/download/>
