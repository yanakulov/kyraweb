param(
  [string]$Text,
  [int]$Unit = 17
)

if (-not $Text) {
  $input = Read-Host "Enter text (20 chars max, default '  INSERT BUCKAZOID  ')"
  $text = if ([string]::IsNullOrEmpty($input)) { '  INSERT BUCKAZOID  ' } else { $input }
} else {
  $text = $Text
}

if ($text.Length -gt 20) {
  Write-Warning "Text longer than 20 chars, truncating"
  $text = $text.Substring(0, 20)
}
$text = $text.PadRight(20, ' ')

$dev = ($Unit - 1) -band 0x7F
$addr = @(0x20, 0x00, 0x00)
$data = $text.ToCharArray() | ForEach-Object { [int][char]$_ }

$sum = ($addr | ForEach-Object { $_ -band 0x7F } | Measure-Object -Sum).Sum +
      ($data | ForEach-Object { $_ -band 0x7F } | Measure-Object -Sum).Sum
$checksum = (128 - ($sum -band 0x7F)) -band 0x7F

$sysex = @(0xF0, 0x41, $dev, 0x16, 0x12) + $addr + $data + $checksum + @(0xF7)
$hex = ($sysex | ForEach-Object { '{0:X2}' -f $_ }) -join ' '

Write-Host "`nMT-32 LCD SysEx ($($text.Length) chars, unit $Unit)"
Write-Host "Text: [$text]"
Write-Host "Hex:  $hex"
Write-Host "`nPaste for CC:"
Write-Host $hex
