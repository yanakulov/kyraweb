// Schema v1 keys: 'control', 'pcm', 'sf2'
// Each value: { name, data: ArrayBuffer, size, sha256, timestamp }

const DB_NAME    = 'mt32-web';
const DB_VERSION = 1;
const STORE_NAME = 'roms';

const CONTROL_SIZES     = [65536, 131072];
const CONTROL_TOLERANCE = 128;
const PCM_SIZES         = [524288, 1048576];
const PCM_TOLERANCE     = 1024;

const SF2_WARN_THRESHOLD = 32 * 1024 * 1024;

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

function dbPut(key, value) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(value, key);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror    = () => { db.close(); reject(tx.error); };
  }));
}

function dbGet(key) {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const r = tx.objectStore(STORE_NAME).get(key);
    r.onsuccess = () => { db.close(); resolve(r.result); };
    r.onerror   = () => { db.close(); reject(r.error); };
  }));
}

function dbClear() {
  return openDB().then(db => new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).clear();
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror    = () => { db.close(); reject(tx.error); };
  }));
}

async function computeSHA256(buf) {
  // crypto.subtle only exists in secure contexts (HTTPS or localhost).
  // LAN access via http://192.168.x.x leaves subtle undefined — skip hash.
  const subtle = globalThis.crypto && globalThis.crypto.subtle;
  if (!subtle || typeof subtle.digest !== 'function') {
    return '';
  }
  try {
    const hash = await subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hash))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  } catch (_) {
    return '';
  }
}

function inRange(size, accepted, tol) {
  return accepted.some(s => Math.abs(size - s) <= tol);
}

function classifyRom(name, size) {
  const up = name.toUpperCase();
  if (up.includes('PCM') && !up.includes('CONTROL') && !up.includes('CTRL')) return 'pcm';
  if (
    up.includes('CONTROL') ||
    up.includes('CTRL') ||
    /MT32.*2\.0|2\.0[3467].*MT|CTRL_MT32_2|MT32_2_0/i.test(name)
  ) {
    return 'control';
  }
  if (inRange(size, CONTROL_SIZES, CONTROL_TOLERANCE)) return 'control';
  if (inRange(size, PCM_SIZES, PCM_TOLERANCE)) return 'pcm';
  return null;
}

export const KNOWN_CONTROL_SHA1 = {
  '47b52adefedaec475c925e54340e37673c11707c': 'MT-32 Control v2.07 (128 KiB)',
  '2869cf4c235d671668cfcb62415e2ce8323ad4ed': 'MT-32 Control v2.06 (128 KiB)',
  '2c16432b6c73dd2a3947cba950a0f4c19d6180eb': 'MT-32 Control v2.04 (128 KiB)',
  b083518fffb7f66b03c23b7eb4f868e62dc5a987: 'MT-32 Control v1.07 (64 KiB)',
  a439fbb390da38cada95a7cbb1d6ca199cd66ef8: 'CM-32L Control v1.02 (64 KiB)',
};

export function describeControlRom(size, sha1hex) {
  const sha = String(sha1hex || '').toLowerCase();
  if (KNOWN_CONTROL_SHA1[sha]) return KNOWN_CONTROL_SHA1[sha];
  if (Math.abs(size - 131072) <= CONTROL_TOLERANCE) return 'Control ROM ~128 KiB (MT-32 2.x / new-gen)';
  if (Math.abs(size - 65536) <= CONTROL_TOLERANCE) return 'Control ROM ~64 KiB (MT-32 1.0x / CM-32L)';
  return `Control ROM (${size} B)`;
}

function validRomSize(type, size) {
  if (type === 'control') return inRange(size, CONTROL_SIZES, CONTROL_TOLERANCE);
  if (type === 'pcm')     return inRange(size, PCM_SIZES, PCM_TOLERANCE);
  return false;
}

/**
 * @param {number} bytes
 * @returns {{ ok: boolean, warn: boolean }}
 *   ok=true  → safe to store in IndexedDB
 *   ok=false → exceeds 32 MiB threshold
 *   warn=true → file is larger than recommended
 */
export function validateSf2Size(bytes) {
  return {
    ok:   bytes <= SF2_WARN_THRESHOLD,
    warn: bytes  > SF2_WARN_THRESHOLD,
  };
}

/** @returns {Promise<{ control?: object, pcm?: object, sf2?: object }>} */
export async function getStoredRoms() {
  const [control, pcm, sf2] = await Promise.all([
    dbGet('control'), dbGet('pcm'), dbGet('sf2'),
  ]);
  const r = {};
  if (control) r.control = control;
  if (pcm)     r.pcm     = pcm;
  if (sf2)     r.sf2     = sf2;
  return r;
}

export async function clearRoms() {
  await dbClear();
}

function onDragOver(e) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'copy';
}

function makeOverlayFileInput(accept, multiple) {
  const inp = document.createElement('input');
  inp.type = 'file';
  if (accept) inp.accept = accept;
  if (multiple) inp.multiple = true;
  inp.className = 'file-input-overlay';
  inp.title = 'Choose file';
  return inp;
}

function wireDropZone(zoneEl, input, onFiles) {
  if (!zoneEl || !input) return;

  zoneEl.classList.add('drop-zone--picker');
  if (!zoneEl.contains(input)) zoneEl.appendChild(input);

  input.addEventListener('change', () => {
    if (!input.files || !input.files.length) return;
    onFiles(input.files);
    input.value = '';
  });

  zoneEl.addEventListener('dragover', (e) => {
    onDragOver(e);
    zoneEl.classList.add('drag-over');
  });
  zoneEl.addEventListener('dragleave', () => {
    zoneEl.classList.remove('drag-over');
  });
  zoneEl.addEventListener('drop', (e) => {
    e.preventDefault();
    zoneEl.classList.remove('drag-over');
    if (!e.dataTransfer || !e.dataTransfer.files || !e.dataTransfer.files.length) return;
    onFiles(e.dataTransfer.files);
  });
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload  = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsArrayBuffer(file);
  });
}

function setStatus(el, msg) {
  el.textContent = msg;
}

export function setupRomDrop(zoneEl, statusEl, onStored) {
  const input = makeOverlayFileInput('.rom,.bin,application/octet-stream', true);
  wireDropZone(zoneEl, input, (files) => {
    handleRomFiles(files, statusEl, onStored);
  });
}

export function setupSf2Drop(zoneEl, statusEl, onStored) {
  const input = makeOverlayFileInput('.sf2,application/x-sf2,audio/*', false);
  wireDropZone(zoneEl, input, (files) => {
    handleSf2File(files[0], statusEl, onStored);
  });
}

async function handleRomFiles(fileList, statusEl, onStored) {
  const files = Array.from(fileList);
  let stored = 0;
  const errors = [];
  const hints = [];

  for (const f of files) {
    const type = classifyRom(f.name, f.size);
    if (!type) {
      errors.push(`"${f.name}" (${f.size} B) — unrecognised ROM type`);
      continue;
    }
    if (!validRomSize(type, f.size)) {
      errors.push(`"${f.name}" (${f.size} B) — invalid size for ${type} ROM` +
        ` (expected ~${type === 'control' ? '64K/128K' : '512K/1M'})`);
      continue;
    }
    try {
      const buf = await readFileAsArrayBuffer(f);
      const sha = await computeSHA256(buf);
      const rec = {
        name: f.name,
        data: buf,
        size: f.size,
        sha256: sha,
        timestamp: Date.now(),
      };
      if (type === 'control') {
        rec.kind = describeControlRom(f.size, '');
        rec.bytes = f.size;
        hints.push(`${f.name}: ${rec.kind}`);
      }
      await dbPut(type, rec);
      stored++;
    } catch (err) {
      errors.push(`"${f.name}" — ${err.message}`);
    }
  }

  const parts = [];
  if (stored > 0) parts.push(`${stored} ROM${stored > 1 ? 's' : ''} stored`);
  if (hints.length) parts.push(hints.join('; '));
  if (errors.length) parts.push(`Errors: ${errors.join('; ')}`);
  setStatus(statusEl, parts.join(' | ') || 'No ROMs processed');

  if (typeof onStored === 'function') {
    try {
      await onStored();
    } catch (err) {
      setStatus(statusEl, (statusEl.textContent || '') + ' | engine: ' + err.message);
    }
  }
}

async function handleSf2File(file, statusEl, onStored) {
  if (!file.name.toLowerCase().endsWith('.sf2')) {
    setStatus(statusEl, `Invalid: "${file.name}" is not a .sf2 file`);
    return;
  }

  const { ok, warn } = validateSf2Size(file.size);
  void ok;

  try {
    const buf = await readFileAsArrayBuffer(file);
    const sha = await computeSHA256(buf);

    await dbPut('sf2', {
      name: file.name,
      data: buf,
      size: file.size,
      sha256: sha,
      timestamp: Date.now(),
    });

    const sizeStr = formatSize(file.size);
    let msg = `SF2 loaded: ${file.name} (${sizeStr})`;
    if (warn) {
      msg += ` — Warning: file exceeds 32 MB (session-only recommended)`;
    }
    setStatus(statusEl, msg);

    if (typeof onStored === 'function') {
      try {
        await onStored();
      } catch (err) {
        setStatus(statusEl, (statusEl.textContent || '') + ' | engine: ' + err.message);
      }
    }
  } catch (err) {
    setStatus(statusEl, `SF2 error: ${err.message}`);
  }
}

function formatSize(bytes) {
  if (bytes < 1024)    return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}
