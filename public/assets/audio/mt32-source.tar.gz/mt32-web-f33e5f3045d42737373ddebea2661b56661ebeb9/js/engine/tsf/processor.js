function wrapTsfApi(Module) {
  const c = (name, ret, args) => Module.cwrap(name, ret, args);
  return {
    load: c('tsf_wasm_load', 'number', ['number', 'number']),
    close: c('tsf_wasm_close', null, ['number']),
    reset: c('tsf_wasm_reset', null, ['number']),
    setOutput: c('tsf_wasm_set_output', null, ['number', 'number', 'number']),
    setMaxVoices: c('tsf_wasm_set_max_voices', 'number', ['number', 'number']),
    channelSetup: c('tsf_wasm_channel_setup', null, ['number', 'number']),
    channelNoteOn: c('tsf_wasm_channel_note_on', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelNoteOff: c('tsf_wasm_channel_note_off', null, ['number', 'number', 'number']),
    channelNoteOffAll: c('tsf_wasm_channel_note_off_all', null, ['number', 'number']),
    noteOffAll: c('tsf_wasm_note_off_all', null, ['number']),
    channelMidiControl: c('tsf_wasm_channel_midi_control', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelSetPitchwheel: c('tsf_wasm_channel_set_pitchwheel', 'number', [
      'number',
      'number',
      'number',
    ]),
    channelSetPresetnumber: c('tsf_wasm_channel_set_presetnumber', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelSetBankPreset: c('tsf_wasm_channel_set_bank_preset', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    renderFloat: c('tsf_wasm_render_float', null, ['number', 'number', 'number', 'number']),
    getPresetcount: c('tsf_wasm_get_presetcount', 'number', ['number']),
    activeVoiceCount: c('tsf_wasm_active_voice_count', 'number', ['number']),
    malloc: c('tsf_wasm_malloc', 'number', ['number']),
    freeBuf: c('tsf_wasm_free_buf', null, ['number']),
    HEAPU8: Module.HEAPU8,
    HEAPF32: Module.HEAPF32,
    Module,
  };
}

function applyMidiMsg(api, handle, status, data1, data2) {
  if (!api || !handle) return;
  const cmd = status & 0xf0;
  const ch = status & 0x0f;
  switch (cmd) {
    case 0x80:
      api.channelNoteOff(handle, ch, data1 & 0x7f);
      break;
    case 0x90: {
      const vel = (data2 & 0x7f) / 127;
      if (vel <= 0) api.channelNoteOff(handle, ch, data1 & 0x7f);
      else api.channelNoteOn(handle, ch, data1 & 0x7f, vel);
      break;
    }
    case 0xb0:
      api.channelMidiControl(handle, ch, data1 & 0x7f, data2 & 0x7f);
      break;
    case 0xc0:
      api.channelSetPresetnumber(handle, ch, data1 & 0x7f, ch === 9 ? 1 : 0);
      break;
    case 0xe0: {
      const wheel = ((data2 & 0x7f) << 7) | (data1 & 0x7f);
      api.channelSetPitchwheel(handle, ch, wheel);
      break;
    }
    default:
      break;
  }
}

function xhrArrayBuffer(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.response);
      else reject(new Error('XHR ' + xhr.status + ' ' + url));
    };
    xhr.onerror = () => reject(new Error('XHR network error ' + url));
    xhr.send();
  });
}

function xhrText(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'text';
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.responseText);
      else reject(new Error('XHR ' + xhr.status + ' ' + url));
    };
    xhr.onerror = () => reject(new Error('XHR network error ' + url));
    xhr.send();
  });
}

async function loadModuleInWorklet(jsUrl, wasmUrl, prefetched) {
  let jsText;
  let wasmBinary;
  if (prefetched && prefetched.jsText) {
    jsText = prefetched.jsText;
    wasmBinary = prefetched.wasmBinary || null;
  } else if (typeof fetch === 'function') {
    jsText = await (await fetch(jsUrl, { credentials: 'same-origin' })).text();
    if (wasmUrl) {
      wasmBinary = await (await fetch(wasmUrl, { credentials: 'same-origin' })).arrayBuffer();
    }
  } else {
    jsText = await xhrText(jsUrl);
    if (wasmUrl) wasmBinary = await xhrArrayBuffer(wasmUrl);
  }
  const factory = new Function(
    jsText +
      ';\n' +
      'if (typeof createTsfModule === "function") return createTsfModule;\n' +
      'throw new Error("createTsfModule missing after eval");\n'
  )();
  if (typeof factory !== 'function') {
    throw new Error('createTsfModule not a function');
  }
  const config = {};
  if (wasmBinary) {
    config.wasmBinary = wasmBinary;
  } else {
    config.locateFile = (path) => (path.endsWith('.wasm') ? wasmUrl : path);
  }
  return await factory(config);
}

class TsfProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this._api = null;
    this._handle = 0;
    this._renderPtr = 0;
    this._renderFrames = 0;
    this._volume = 1;
    this._sampleRate = sampleRate;
    this._initPromise = null;
    this._sf2Ready = false;
    this._peak = 0;
    this._peakCounter = 0;

    this.port.onmessage = (ev) => {
      this._onMessage(ev.data).catch((err) => {
        this.port.postMessage({
          type: 'error',
          message: String(err && err.message ? err.message : err),
        });
      });
    };
  }

  async _onMessage(msg) {
    if (!msg || !msg.type) return;
    switch (msg.type) {
      case 'init':
        await this._init(msg);
        break;
      case 'sf2':
        await this._loadSf2(msg.data);
        break;
      case 'msg':
        if (this._api && this._handle && this._sf2Ready) {
          applyMidiMsg(
            this._api,
            this._handle,
            msg.status & 0xff,
            (msg.data1 || 0) & 0xff,
            (msg.data2 || 0) & 0xff
          );
        }
        break;
      case 'sysex':
        break;
      case 'reset':
        if (this._api && this._handle) {
          this._api.reset(this._handle);
          this._api.channelSetup(this._handle, 16);
        }
        break;
      case 'setVolume':
        if (typeof msg.volume === 'number') {
          this._volume = Math.max(0, Math.min(1, msg.volume));
        }
        break;
      default:
        break;
    }
  }

  async _init(msg) {
    if (this._initPromise) {
      await this._initPromise;
      return;
    }
    this._initPromise = (async () => {
      const jsUrl = msg.jsUrl || './wasm/tsf.js';
      const wasmUrl = msg.wasmUrl || './wasm/tsf.wasm';
      if (typeof msg.sampleRate === 'number' && msg.sampleRate > 0) {
        this._sampleRate = msg.sampleRate;
      }
      const Module = await loadModuleInWorklet(jsUrl, wasmUrl, {
        jsText: msg.jsText || null,
        wasmBinary: msg.wasmBinary || null,
      });
      this._api = wrapTsfApi(Module);
      this.port.postMessage({ type: 'ready' });
    })();
    await this._initPromise;
  }

  _ensureRenderBuf(frames) {
    if (this._renderFrames >= frames && this._renderPtr) return;
    if (this._renderPtr) {
      this._api.freeBuf(this._renderPtr);
      this._renderPtr = 0;
    }
    this._renderPtr = this._api.malloc(frames * 2 * 4);
    if (!this._renderPtr) throw new Error('tsf render malloc failed');
    this._renderFrames = frames;
  }

  async _loadSf2(data) {
    if (!this._api) {
      this.port.postMessage({ type: 'sf2Loaded', ok: false, detail: 'module not ready' });
      return;
    }
    if (!data) {
      this.port.postMessage({ type: 'sf2Loaded', ok: false, detail: 'missing SF2 data' });
      return;
    }
    try {
      if (this._handle) {
        this._api.close(this._handle);
        this._handle = 0;
        this._sf2Ready = false;
      }
      const u8 = data instanceof Uint8Array ? data : new Uint8Array(data);
      const ptr = this._api.malloc(u8.byteLength);
      if (!ptr) throw new Error('malloc SF2 failed');
      this._api.Module.HEAPU8.set(u8, ptr);
      const handle = this._api.load(ptr, u8.byteLength);
      this._api.freeBuf(ptr);
      if (!handle) {
        this.port.postMessage({ type: 'sf2Loaded', ok: false, detail: 'tsf_load_memory failed' });
        return;
      }
      this._handle = handle;
      this._api.setMaxVoices(handle, 64);
      this._api.setOutput(handle, this._sampleRate, 0);
      this._api.channelSetup(handle, 16);
      const presets = this._api.getPresetcount(handle);
      this._sf2Ready = true;
      this.port.postMessage({
        type: 'sf2Loaded',
        ok: true,
        detail: `presets=${presets} rate=${this._sampleRate}`,
        presets,
      });
    } catch (err) {
      this._sf2Ready = false;
      this.port.postMessage({
        type: 'sf2Loaded',
        ok: false,
        detail: String(err && err.message ? err.message : err),
      });
    }
  }

  process(_inputs, outputs) {
    const output = outputs[0];
    if (!output || !output.length) return true;
    const left = output[0];
    const right = output[1] || output[0];
    const frames = left.length;
    left.fill(0);
    if (right !== left) right.fill(0);

    if (!this._api || !this._handle || !this._sf2Ready) return true;

    try {
      this._ensureRenderBuf(frames);
      this._api.renderFloat(this._handle, this._renderPtr, frames, 0);
      const heap = this._api.Module.HEAPF32;
      const base = this._renderPtr >> 2;
      const vol = this._volume;
      let peak = 0;
      for (let i = 0; i < frames; i++) {
        const l = heap[base + i * 2] * vol;
        const r = heap[base + i * 2 + 1] * vol;
        left[i] = l;
        right[i] = r;
        const a = Math.abs(l) > Math.abs(r) ? Math.abs(l) : Math.abs(r);
        if (a > peak) peak = a;
      }
      this._peak = Math.max(this._peak * 0.95, peak);
      this._peakCounter++;
      if (this._peakCounter >= 64) {
        this._peakCounter = 0;
        this.port.postMessage({ type: 'peak', value: this._peak });
      }
    } catch (err) {
      this.port.postMessage({
        type: 'error',
        message: 'render: ' + (err && err.message ? err.message : err),
      });
    }
    return true;
  }
}

registerProcessor('tsf-processor', TsfProcessor);
