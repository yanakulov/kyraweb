export async function loadTsfModule(options = {}) {
  const base = options.baseUrl || './wasm';
  const jsUrl = options.jsUrl || `${base}/tsf.js`;
  const wasmUrl = options.wasmUrl || `${base}/tsf.wasm`;

  await new Promise((resolve, reject) => {
    if (typeof createTsfModule === 'function') {
      resolve();
      return;
    }
    const s = document.createElement('script');
    s.src = jsUrl;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Failed to load ${jsUrl}`));
    document.head.appendChild(s);
  });

  if (typeof createTsfModule !== 'function') {
    throw new Error('createTsfModule not found after loading tsf.js');
  }

  const Module = await createTsfModule({
    locateFile: (path) => (path.endsWith('.wasm') ? wasmUrl : `${base}/${path}`),
    ...(options.moduleConfig || {}),
  });
  return Module;
}

export function wrapTsfApi(Module) {
  const c = (name, ret, args) => Module.cwrap(name, ret, args);
  return {
    load: c('tsf_wasm_load', 'number', ['number', 'number']),
    close: c('tsf_wasm_close', null, ['number']),
    reset: c('tsf_wasm_reset', null, ['number']),
    setOutput: c('tsf_wasm_set_output', null, ['number', 'number', 'number']),
    setMaxVoices: c('tsf_wasm_set_max_voices', 'number', ['number', 'number']),
    channelSetup: c('tsf_wasm_channel_setup', null, ['number', 'number']),
    channelNoteOn: c('tsf_wasm_channel_note_on', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelNoteOff: c('tsf_wasm_channel_note_off', null, ['number', 'number', 'number']),
    channelNoteOffAll: c('tsf_wasm_channel_note_off_all', null, ['number', 'number']),
    noteOffAll: c('tsf_wasm_note_off_all', null, ['number']),
    channelMidiControl: c('tsf_wasm_channel_midi_control', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelSetPitchwheel: c('tsf_wasm_channel_set_pitchwheel', 'number', [
      'number',
      'number',
      'number',
    ]),
    channelSetPresetnumber: c('tsf_wasm_channel_set_presetnumber', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    channelSetBankPreset: c('tsf_wasm_channel_set_bank_preset', 'number', [
      'number',
      'number',
      'number',
      'number',
    ]),
    renderFloat: c('tsf_wasm_render_float', null, ['number', 'number', 'number', 'number']),
    getPresetcount: c('tsf_wasm_get_presetcount', 'number', ['number']),
    activeVoiceCount: c('tsf_wasm_active_voice_count', 'number', ['number']),
    malloc: c('tsf_wasm_malloc', 'number', ['number']),
    freeBuf: c('tsf_wasm_free_buf', null, ['number']),
    HEAPU8: Module.HEAPU8,
    HEAPF32: Module.HEAPF32,
    Module,
  };
}

export function applyMidiMsg(api, handle, status, data1, data2) {
  if (!api || !handle) return;
  const cmd = status & 0xf0;
  const ch = status & 0x0f;
  switch (cmd) {
    case 0x80:
      api.channelNoteOff(handle, ch, data1 & 0x7f);
      break;
    case 0x90: {
      const vel = (data2 & 0x7f) / 127;
      if (vel <= 0) api.channelNoteOff(handle, ch, data1 & 0x7f);
      else api.channelNoteOn(handle, ch, data1 & 0x7f, vel);
      break;
    }
    case 0xb0:
      api.channelMidiControl(handle, ch, data1 & 0x7f, data2 & 0x7f);
      break;
    case 0xc0:
      api.channelSetPresetnumber(handle, ch, data1 & 0x7f, ch === 9 ? 1 : 0);
      break;
    case 0xe0: {
      const wheel = ((data2 & 0x7f) << 7) | (data1 & 0x7f);
      api.channelSetPitchwheel(handle, ch, wheel);
      break;
    }
    default:
      break;
  }
}
