import { Engine } from './interface.js';
import { loadTsfModule, wrapTsfApi, applyMidiMsg } from './tsf/glue.js';

const PROCESSOR_URL = new URL('./tsf/processor.js', import.meta.url).href;
const WASM_JS_URL = new URL('../../wasm/mt32emu.js', import.meta.url).href;
const WASM_BIN_URL = new URL('../../wasm/mt32emu.wasm', import.meta.url).href;

export class TsfEngine extends Engine {
  constructor() {
    super('tsf', 'TinySoundFont');
    this._mode = 'none';
    this._ctx = null;
    this._destination = null;
    this._node = null;
    this._gain = null;
    this._workletReady = false;
    this._sf2Loaded = false;
    this._peakLevel = 0;
    this._pendingSf2 = null;
    this._api = null;
    this._handle = 0;
    this._renderPtr = 0;
    this._renderFrames = 0;
    this._spnHandler = null;
    this._lastError = null;
    this._connectPromise = null;
    this._sf2Resolve = null;
    this._presetCount = 0;
  }

  get audioMode() {
    return this._mode;
  }

  get peakLevel() {
    return this._peakLevel;
  }

  get sf2Loaded() {
    return this._sf2Loaded;
  }

  get lastError() {
    return this._lastError;
  }

  async init(_opts = {}) {
    this._initialized = true;
  }

  async loadRoms(_roms) {}

  async loadSf2(bytes) {
    if (!bytes) {
      this._lastError = 'SF2 data required for tsf';
      this._sf2Loaded = false;
      throw new Error(this._lastError);
    }
    this._pendingSf2 = bytes instanceof ArrayBuffer ? bytes : bytes.buffer || bytes;

    if (this._mode === 'worklet' && this._node && this._workletReady) {
      await this._postSf2ToWorklet(this._pendingSf2);
      return;
    }
    if (this._mode === 'script') {
      await this._ensureMainWasm();
      await this._loadSf2Main(this._pendingSf2);
      return;
    }
    this._sf2Loaded = false;
  }

  playMsg(status, data1 = 0, data2 = 0) {
    if (!this._sf2Loaded) return;
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({
        type: 'msg',
        status: status & 0xff,
        data1: data1 & 0xff,
        data2: data2 & 0xff,
      });
      return;
    }
    if (this._mode === 'script' && this._api && this._handle) {
      applyMidiMsg(this._api, this._handle, status, data1, data2);
    }
  }

  playSysex(_sysex) {}

  reset() {
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'reset' });
      return;
    }
    if (this._mode === 'script' && this._api && this._handle) {
      this._api.reset(this._handle);
      this._api.channelSetup(this._handle, 16);
    }
  }

  setVolume(vol) {
    super.setVolume(vol);
    if (this._gain && this._ctx) {
      this._gain.gain.setValueAtTime(this._volume, this._ctx.currentTime);
    }
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'setVolume', volume: this._volume });
    }
  }

  connect(ctx, destination) {
    if (!ctx || !destination) {
      throw new Error('[tsf] connect() requires AudioContext and destination');
    }
    this._ctx = ctx;
    this._destination = destination;
    this._disconnectAudio();
    this._gain = ctx.createGain();
    this._gain.gain.value = this._volume;
    this._gain.connect(destination);
    this._connectPromise = this._connectAsync(ctx);
    return this._connectPromise;
  }

  async ensureConnected() {
    if (this._connectPromise) await this._connectPromise;
    return this._mode;
  }

  async dispose() {
    this._disconnectAudio();
    this._freeMainSynth();
    this._mode = 'none';
    this._sf2Loaded = false;
    this._initialized = false;
    this._pendingSf2 = null;
  }

  getDisplayState() {
    return {
      text: null,
      patch: this._mode === 'worklet' ? 'AW' : this._mode === 'script' ? 'SP' : '---',
      ledReady: this._sf2Loaded,
      ledMidi: false,
    };
  }

  async _connectAsync(ctx) {
    const sampleRate = ctx.sampleRate || 44100;
    try {
      await this._connectWorklet(ctx, sampleRate);
      this._mode = 'worklet';
    } catch (err) {
      console.warn('[tsf] AudioWorklet unavailable, using ScriptProcessorNode:', err);
      this._lastError = 'worklet failed: ' + (err && err.message ? err.message : err);
      await this._connectScriptProcessor(ctx, sampleRate);
      this._mode = 'script';
    }
    if (this._pendingSf2) {
      if (this._mode === 'worklet') {
        await this._postSf2ToWorklet(this._pendingSf2);
      } else {
        await this._loadSf2Main(this._pendingSf2);
      }
    }
  }

  async _connectWorklet(ctx, sampleRate) {
    if (!ctx.audioWorklet || typeof ctx.audioWorklet.addModule !== 'function') {
      throw new Error('AudioWorklet not supported');
    }
    await ctx.audioWorklet.addModule(PROCESSOR_URL);
    const node = new AudioWorkletNode(ctx, 'tsf-processor', {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
    });

    const ready = new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('worklet init timeout')), 20000);
      node.port.onmessage = (ev) => {
        const msg = ev.data;
        if (!msg) return;
        if (msg.type === 'ready') {
          clearTimeout(t);
          this._workletReady = true;
          resolve();
        } else if (msg.type === 'error') {
          if (!this._workletReady) {
            clearTimeout(t);
            reject(new Error(msg.message || 'worklet error'));
          } else {
            this._lastError = msg.message;
            console.error('[tsf worklet]', msg.message);
          }
        } else if (msg.type === 'sf2Loaded') {
          this._sf2Loaded = !!msg.ok;
          if (!msg.ok) this._lastError = msg.detail || 'SF2 load failed';
          else {
            this._lastError = null;
            this._presetCount = msg.presets || 0;
          }
          if (this._sf2Resolve) {
            this._sf2Resolve(msg);
            this._sf2Resolve = null;
          }
        } else if (msg.type === 'peak') {
          this._peakLevel = msg.value || 0;
          if (typeof window !== 'undefined' && window.__debug) {
            window.__debug._peakLevel = this._peakLevel;
          }
        }
      };
    });

    const jsUrl = new URL(WASM_JS_URL, self.location.origin).href;
    const wasmUrl = new URL(WASM_BIN_URL, self.location.origin).href;
    const [jsText, wasmBinary] = await Promise.all([
      fetch(jsUrl).then((r) => {
        if (!r.ok) throw new Error('fetch js ' + r.status);
        return r.text();
      }),
      fetch(wasmUrl).then((r) => {
        if (!r.ok) throw new Error('fetch wasm ' + r.status);
        return r.arrayBuffer();
      }),
    ]);
    node.port.postMessage(
      {
        type: 'init',
        jsUrl,
        wasmUrl,
        sampleRate,
        jsText,
        wasmBinary,
      },
      [wasmBinary]
    );

    await ready;
    node.connect(this._gain);
    this._node = node;
  }

  async _connectScriptProcessor(ctx, sampleRate) {
    await this._ensureMainWasm();
    const bufferSize = 2048;
    const node = ctx.createScriptProcessor(bufferSize, 0, 2);
    this._spnHandler = (e) => {
      const left = e.outputBuffer.getChannelData(0);
      const right = e.outputBuffer.getChannelData(1);
      const frames = left.length;
      left.fill(0);
      right.fill(0);
      if (!this._sf2Loaded || !this._api || !this._handle) return;
      try {
        this._ensureRenderBufMain(frames);
        this._api.renderFloat(this._handle, this._renderPtr, frames, 0);
        const heap = this._api.Module.HEAPF32;
        const base = this._renderPtr >> 2;
        let peak = 0;
        for (let i = 0; i < frames; i++) {
          const l = heap[base + i * 2];
          const r = heap[base + i * 2 + 1];
          left[i] = l;
          right[i] = r;
          const a = Math.abs(l) > Math.abs(r) ? Math.abs(l) : Math.abs(r);
          if (a > peak) peak = a;
        }
        this._peakLevel = Math.max(this._peakLevel * 0.95, peak);
        if (typeof window !== 'undefined' && window.__debug) {
          window.__debug._peakLevel = this._peakLevel;
        }
      } catch (err) {
        this._lastError = String(err && err.message ? err.message : err);
      }
    };
    node.onaudioprocess = this._spnHandler;
    node.connect(this._gain);
    this._node = node;
    void sampleRate;
  }

  _disconnectAudio() {
    if (this._node) {
      try {
        this._node.disconnect();
      } catch (_) {}
      if (this._node.port) {
        try {
          this._node.port.onmessage = null;
        } catch (_) {}
      }
      if ('onaudioprocess' in this._node) {
        this._node.onaudioprocess = null;
      }
      this._node = null;
    }
    if (this._gain) {
      try {
        this._gain.disconnect();
      } catch (_) {}
      this._gain = null;
    }
    this._workletReady = false;
    this._mode = 'none';
  }

  async _ensureMainWasm() {
    if (this._api) return;
    const Module = await loadTsfModule();
    this._api = wrapTsfApi(Module);
  }

  async _loadSf2Main(bytes) {
    await this._ensureMainWasm();
    if (this._handle) {
      this._api.close(this._handle);
      this._handle = 0;
    }
    const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
    const ptr = this._api.malloc(u8.byteLength);
    if (!ptr) throw new Error('malloc SF2 failed');
    this._api.Module.HEAPU8.set(u8, ptr);
    const handle = this._api.load(ptr, u8.byteLength);
    this._api.freeBuf(ptr);
    if (!handle) {
      this._sf2Loaded = false;
      this._lastError = 'tsf_load_memory failed (invalid SF2?)';
      throw new Error(this._lastError);
    }
    this._handle = handle;
    const rate = (this._ctx && this._ctx.sampleRate) || 44100;
    this._api.setMaxVoices(handle, 64);
    this._api.setOutput(handle, rate, 0);
    this._api.channelSetup(handle, 16);
    this._presetCount = this._api.getPresetcount(handle);
    this._sf2Loaded = true;
    this._lastError = null;
  }

  _postSf2ToWorklet(bytes) {
    return new Promise((resolve, reject) => {
      if (!this._node || !this._node.port) {
        reject(new Error('worklet node missing'));
        return;
      }
      const ab = bytes instanceof ArrayBuffer ? bytes : bytes.buffer;
      const copy = ab.slice(0);
      this._sf2Resolve = (msg) => {
        if (msg.ok) resolve(msg);
        else reject(new Error(msg.detail || 'SF2 load failed in worklet'));
      };
      this._node.port.postMessage({ type: 'sf2', data: copy }, [copy]);
      setTimeout(() => {
        if (this._sf2Resolve) {
          this._sf2Resolve = null;
          reject(new Error('SF2 load timeout'));
        }
      }, 30000);
    })
      .then(() => {
        this._sf2Loaded = true;
      })
      .catch((err) => {
        this._sf2Loaded = false;
        this._lastError = err.message;
        throw err;
      });
  }

  _ensureRenderBufMain(frames) {
    if (this._renderFrames >= frames && this._renderPtr) return;
    if (this._renderPtr) {
      this._api.freeBuf(this._renderPtr);
      this._renderPtr = 0;
    }
    this._renderPtr = this._api.malloc(frames * 2 * 4);
    if (!this._renderPtr) throw new Error('render malloc failed');
    this._renderFrames = frames;
  }

  _freeMainSynth() {
    if (this._renderPtr && this._api) {
      try {
        this._api.freeBuf(this._renderPtr);
      } catch (_) {}
      this._renderPtr = 0;
      this._renderFrames = 0;
    }
    if (this._handle && this._api) {
      try {
        this._api.close(this._handle);
      } catch (_) {}
      this._handle = 0;
    }
  }
}

export default TsfEngine;
