﻿/**
 * MuntEngine: AudioWorklet preferred; ScriptProcessorNode fallback (no SAB/COOP).
 * @module engine/munt-engine
 */

import { Engine } from './interface.js';
import { loadMt32EmuModule, wrapMt32Api } from './munt/glue.js';

const PROCESSOR_URL = new URL('./munt/processor.js', import.meta.url).href;
const WASM_JS_URL = new URL('../../wasm/mt32emu.js', import.meta.url).href;
const WASM_BIN_URL = new URL('../../wasm/mt32emu.wasm', import.meta.url).href;

export function packMidiMsg(status, data1 = 0, data2 = 0) {
  return (
    (status & 0xff) |
    ((data1 & 0xff) << 8) |
    ((data2 & 0xff) << 16)
  ) >>> 0;
}

export function decodeMt32LcdChars(heapU8, ptr, len = 20) {
  let s = '';
  const n = Math.max(0, len | 0);
  for (let i = 0; i < n; i++) {
    const b = heapU8[ptr + i] & 0xff;
    if (b === 0) {
      while (i < n) {
        s += ' ';
        i++;
      }
      break;
    }
    if (b === 1) s += '\u0001';
    else if (b < 32 || b > 126) s += ' ';
    else s += String.fromCharCode(b);
  }
  return s;
}

export class MuntEngine extends Engine {
  constructor() {
    super('munt', 'libmt32emu');
    this._mode = 'none';
    this._ctx = null;
    this._destination = null;
    this._node = null;
    this._gain = null;
    this._workletReady = false;
    this._romsLoaded = false;
    this._version = '';
    this._peakLevel = 0;
    this._pendingRoms = null;
    this._api = null;
    this._st = 0;
    this._renderPtr = 0;
    this._renderFrames = 0;
    this._spnHandler = null;
    this._lastError = null;
    this._connectPromise = null;
    this._romsResolve = null;
    this._initOpts = {};
    this._displayText = 'MUNT ---';
    this._midiLed = false;
    this._displayBufPtr = 0;
    this._displayCompatOverride = null;
    this._displayOldCompat = null;
    this._displayDefaultOldCompat = null;
  }

  get audioMode() {
    return this._mode;
  }

  get peakLevel() {
    return this._peakLevel;
  }

  get romsLoaded() {
    return this._romsLoaded;
  }

  get lastError() {
    return this._lastError;
  }

  get libraryVersion() {
    return this._version;
  }

  async init(opts = {}) {
    this._initOpts = opts || {};
    this._initialized = true;
  }

  async loadRoms(roms) {
    if (!roms || !roms.control || !roms.pcm) {
      this._lastError = 'Both control and PCM ROMs are required for munt';
      this._romsLoaded = false;
      throw new Error(this._lastError);
    }

    this._pendingRoms = {
      control: roms.control,
      pcm: roms.pcm,
    };

    if (this._mode === 'worklet' && this._node && this._workletReady) {
      await this._postRomsToWorklet(roms.control, roms.pcm);
      return;
    }

    if (this._mode === 'script') {
      await this._ensureMainWasm();
      await this._loadRomsMain(roms.control, roms.pcm);
      return;
    }

    this._romsLoaded = false;
  }

  playMsg(status, data1 = 0, data2 = 0) {
    if (!this._romsLoaded) return;
    const packed = packMidiMsg(status, data1, data2);
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'msg', packed });
      return;
    }
    if (this._mode === 'script' && this._api && this._st && this._api.isOpen(this._st)) {
      this._api.playMsg(this._st, packed);
    }
  }

  playSysex(sysex) {
    if (!this._romsLoaded || !sysex) return;
    const u8 =
      sysex instanceof Uint8Array
        ? sysex
        : new Uint8Array(Array.isArray(sysex) ? sysex : sysex);

    if (this._mode === 'worklet' && this._node) {
      const copy = u8.slice().buffer;
      this._node.port.postMessage({ type: 'sysex', data: copy }, [copy]);
      return;
    }

    if (this._mode === 'script' && this._api && this._st && this._api.isOpen(this._st)) {
      this._playSysexMain(u8);
    }
  }

  reset() {
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'reset' });
    }
  }

  setVolume(vol) {
    super.setVolume(vol);
    if (this._gain && this._ctx) {
      this._gain.gain.setValueAtTime(this._volume, this._ctx.currentTime);
    }
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'setVolume', volume: this._volume });
    }
  }

  setMainDisplayMode() {
    if (!this._romsLoaded) return;
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({ type: 'mainDisplay' });
      return;
    }
    if (
      this._mode === 'script' &&
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.setMainDisplayMode === 'function'
    ) {
      this._api.setMainDisplayMode(this._st);
      this._pollDisplayMain();
    }
  }

  setDisplayCompatibility(oldMt32Compatible) {
    if (oldMt32Compatible === 'auto' || oldMt32Compatible == null) {
      this._displayCompatOverride = null;
      if (!this._romsLoaded) return true;
      return this._restoreDefaultDisplayCompat();
    }
    this._displayCompatOverride = !!oldMt32Compatible;
    this._displayOldCompat = this._displayCompatOverride;
    return this._pushDisplayCompat(this._displayCompatOverride);
  }

  isDisplayOldMT32Compatible() {
    if (
      this._mode === 'script' &&
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.isDisplayOldMT32Compatible === 'function'
    ) {
      return !!this._api.isDisplayOldMT32Compatible(this._st);
    }
    return this._displayOldCompat;
  }

  isDefaultDisplayOldMT32Compatible() {
    if (
      this._mode === 'script' &&
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.isDefaultDisplayOldMT32Compatible === 'function'
    ) {
      return !!this._api.isDefaultDisplayOldMT32Compatible(this._st);
    }
    return this._displayDefaultOldCompat;
  }

  _pushDisplayCompat(oldMt32) {
    if (!this._romsLoaded) return false;
    if (this._mode === 'worklet' && this._node) {
      this._node.port.postMessage({
        type: 'displayCompat',
        oldMt32: !!oldMt32,
      });
      return true;
    }
    if (
      this._mode === 'script' &&
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.setDisplayCompatibility === 'function'
    ) {
      this._api.setDisplayCompatibility(this._st, oldMt32 ? 1 : 0);
      this._displayOldCompat = !!oldMt32;
      this._pollDisplayMain();
      return true;
    }
    return false;
  }

  _readDisplayCompatFlags() {
    if (
      !(
        this._mode === 'script' &&
        this._api &&
        this._st &&
        this._api.isOpen(this._st)
      )
    ) {
      return;
    }
    if (typeof this._api.isDefaultDisplayOldMT32Compatible === 'function') {
      this._displayDefaultOldCompat = !!this._api.isDefaultDisplayOldMT32Compatible(
        this._st,
      );
    }
    if (typeof this._api.isDisplayOldMT32Compatible === 'function') {
      this._displayOldCompat = !!this._api.isDisplayOldMT32Compatible(this._st);
    }
  }

  _restoreDefaultDisplayCompat() {
    if (this._displayDefaultOldCompat != null) {
      return this._pushDisplayCompat(this._displayDefaultOldCompat);
    }
    this._readDisplayCompatFlags();
    if (this._displayDefaultOldCompat != null) {
      return this._pushDisplayCompat(this._displayDefaultOldCompat);
    }
    return false;
  }

  _applyDisplayCompatAfterOpen() {
    this._readDisplayCompatFlags();
    if (this._displayCompatOverride != null) {
      this._pushDisplayCompat(this._displayCompatOverride);
      return;
    }
    if (this._displayDefaultOldCompat != null) {
      this._displayOldCompat = this._displayDefaultOldCompat;
    }
  }

  connect(ctx, destination) {
    if (!ctx || !destination) {
      throw new Error('[munt] connect() requires AudioContext and destination');
    }
    this._ctx = ctx;
    this._destination = destination;
    this._disconnectAudio();

    this._gain = ctx.createGain();
    this._gain.gain.value = this._volume;
    this._gain.connect(destination);

    this._connectPromise = this._connectAsync(ctx);
    return this._connectPromise;
  }

  async ensureConnected() {
    if (this._connectPromise) await this._connectPromise;
    return this._mode;
  }

  async dispose() {
    this._disconnectAudio();
    if (this._api) {
      this._freeMainSynth();
    }
    this._mode = 'none';
    this._romsLoaded = false;
    this._initialized = false;
    this._pendingRoms = null;
  }

  getDisplayState() {
    if (this._mode === 'script') {
      this._pollDisplayMain();
    }
    return {
      text: this._romsLoaded ? this._displayText : 'MUNT ---',
      patch: this._mode === 'worklet' ? 'AW' : this._mode === 'script' ? 'SP' : '---',
      ledReady: this._romsLoaded,
      ledMidi: !!this._midiLed,
    };
  }

  async _connectAsync(ctx) {
    const sampleRate = ctx.sampleRate || 44100;
    try {
      await this._connectWorklet(ctx, sampleRate);
      this._mode = 'worklet';
    } catch (err) {
      console.warn('[munt] AudioWorklet unavailable, using ScriptProcessorNode:', err);
      this._lastError = 'worklet failed: ' + (err && err.message ? err.message : err);
      await this._connectScriptProcessor(ctx, sampleRate);
      this._mode = 'script';
    }

    if (this._pendingRoms) {
      const { control, pcm } = this._pendingRoms;
      if (this._mode === 'worklet') {
        await this._postRomsToWorklet(control, pcm);
      } else {
        await this._loadRomsMain(control, pcm);
      }
    }
  }

  async _connectWorklet(ctx, sampleRate) {
    if (!ctx.audioWorklet || typeof ctx.audioWorklet.addModule !== 'function') {
      throw new Error('AudioWorklet not supported');
    }
    await ctx.audioWorklet.addModule(PROCESSOR_URL);
    const node = new AudioWorkletNode(ctx, 'munt-processor', {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
    });

    const ready = new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('worklet init timeout')), 20000);
      node.port.onmessage = (ev) => {
        const msg = ev.data;
        if (!msg) return;
        if (msg.type === 'ready') {
          clearTimeout(t);
          this._workletReady = true;
          this._version = msg.version || '';
          resolve();
        } else if (msg.type === 'error') {
          if (!this._workletReady) {
            clearTimeout(t);
            reject(new Error(msg.message || 'worklet error'));
          } else {
            this._lastError = msg.message;
            console.error('[munt worklet]', msg.message);
          }
        } else if (msg.type === 'romsLoaded') {
          this._romsLoaded = !!msg.ok;
          if (!msg.ok) {
            this._lastError = msg.detail || 'ROM load failed';
          } else {
            this._lastError = null;
            if (typeof msg.displayDefaultOld === 'boolean') {
              this._displayDefaultOldCompat = msg.displayDefaultOld;
            }
            if (typeof msg.displayOld === 'boolean') {
              this._displayOldCompat = msg.displayOld;
            }
          }
          if (this._romsResolve) {
            this._romsResolve(msg);
            this._romsResolve = null;
          }
        } else if (msg.type === 'displayCompatState') {
          if (typeof msg.displayDefaultOld === 'boolean') {
            this._displayDefaultOldCompat = msg.displayDefaultOld;
          }
          if (typeof msg.displayOld === 'boolean') {
            this._displayOldCompat = msg.displayOld;
          }
        } else if (msg.type === 'peak') {
          this._peakLevel = msg.value || 0;
          if (typeof window !== 'undefined' && window.__debug) {
            window.__debug._peakLevel = this._peakLevel;
          }
        } else if (msg.type === 'display') {
          if (typeof msg.text === 'string') {
            this._displayText = msg.text;
          }
          this._midiLed = !!msg.midiLed;
          if (typeof window !== 'undefined' && window.__debug) {
            window.__debug.lcdText = this._displayText;
            window.__debug.midiLed = this._midiLed;
          }
        }
      };
    });

    const jsUrl = new URL(WASM_JS_URL, self.location.origin).href;
    const wasmUrl = new URL(WASM_BIN_URL, self.location.origin).href;
    const [jsText, wasmBinary] = await Promise.all([
      fetch(jsUrl).then((r) => {
        if (!r.ok) throw new Error('fetch js ' + r.status);
        return r.text();
      }),
      fetch(wasmUrl).then((r) => {
        if (!r.ok) throw new Error('fetch wasm ' + r.status);
        return r.arrayBuffer();
      }),
    ]);
    node.port.postMessage(
      {
        type: 'init',
        jsUrl,
        wasmUrl,
        sampleRate,
        jsText,
        wasmBinary,
      },
      [wasmBinary]
    );

    await ready;
    node.connect(this._gain);
    this._node = node;
  }

  async _connectScriptProcessor(ctx, sampleRate) {
    await this._ensureMainWasm();
    if (this._st) {
      this._api.setSampleRate(this._st, sampleRate);
    }

    const bufferSize = 2048;
    const node = ctx.createScriptProcessor(bufferSize, 0, 2);
    this._spnHandler = (e) => {
      const left = e.outputBuffer.getChannelData(0);
      const right = e.outputBuffer.getChannelData(1);
      const frames = left.length;
      left.fill(0);
      right.fill(0);
      if (!this._romsLoaded || !this._api || !this._st || !this._api.isOpen(this._st)) {
        return;
      }
      try {
        this._ensureRenderBufMain(frames);
        this._api.renderFloat(this._st, this._renderPtr, frames);
        const heap = this._api.Module.HEAPF32;
        const base = this._renderPtr >> 2;
        let peak = 0;
        for (let i = 0; i < frames; i++) {
          const l = heap[base + i * 2];
          const r = heap[base + i * 2 + 1];
          left[i] = l;
          right[i] = r;
          const a = Math.abs(l) > Math.abs(r) ? Math.abs(l) : Math.abs(r);
          if (a > peak) peak = a;
        }
        this._peakLevel = Math.max(this._peakLevel * 0.95, peak);
        if (typeof window !== 'undefined' && window.__debug) {
          window.__debug._peakLevel = this._peakLevel;
        }
        if (!this._spnDisplayDiv) this._spnDisplayDiv = 0;
        this._spnDisplayDiv++;
        if (this._spnDisplayDiv >= 4) {
          this._spnDisplayDiv = 0;
          this._pollDisplayMain();
        }
      } catch (err) {
        this._lastError = String(err && err.message ? err.message : err);
      }
    };
    node.onaudioprocess = this._spnHandler;
    node.connect(this._gain);
    this._node = node;
  }

  _disconnectAudio() {
    if (this._node) {
      try {
        this._node.disconnect();
      } catch (_) {}
      if (this._node.port) {
        try {
          this._node.port.onmessage = null;
        } catch (_) {}
      }
      if ('onaudioprocess' in this._node) {
        this._node.onaudioprocess = null;
      }
      this._node = null;
    }
    if (this._gain) {
      try {
        this._gain.disconnect();
      } catch (_) {}
      this._gain = null;
    }
    this._workletReady = false;
    this._mode = 'none';
  }

  async _ensureMainWasm() {
    if (this._api && this._st) return;
    const Module = await loadMt32EmuModule();
    this._api = wrapMt32Api(Module);
    this._st = this._api.create();
    if (!this._st) throw new Error('mt32_create failed');
    try {
      this._version = this._api.libraryVersion() || '';
    } catch (_) {
      this._version = '';
    }
  }

  async _loadRomsMain(control, pcm) {
    await this._ensureMainWasm();
    if (this._api.isOpen(this._st)) {
      this._api.close(this._st);
    }
    const add = (buf, type) => {
      const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
      const ptr = this._api.malloc(u8.byteLength);
      if (!ptr) throw new Error('malloc ROM failed');
      this._api.Module.HEAPU8.set(u8, ptr);
      const rc = this._api.addRomData(this._st, ptr, u8.byteLength, type);
      this._api.freeBuf(ptr);
      return rc;
    };
    const rc0 = add(control, 0);
    const rc1 = add(pcm, 1);
    if (rc0 < 0 || rc1 < 0) {
      this._romsLoaded = false;
      this._lastError = `addRomData failed (control=${rc0}, pcm=${rc1})`;
      throw new Error(this._lastError);
    }
    const rate = (this._ctx && this._ctx.sampleRate) || 44100;
    this._api.setSampleRate(this._st, rate);
    const openRc = this._api.open(this._st);
    if (openRc < 0) {
      this._romsLoaded = false;
      this._lastError = `mt32_open failed (${openRc})`;
      throw new Error(this._lastError);
    }
    this._api.setSampleRate(this._st, rate);
    this._romsLoaded = true;
    this._lastError = null;
    this._applyDisplayCompatAfterOpen();
    this._pollDisplayMain();
  }

  _postRomsToWorklet(control, pcm) {
    return new Promise((resolve, reject) => {
      if (!this._node || !this._node.port) {
        reject(new Error('worklet node missing'));
        return;
      }
      const cAb = control instanceof ArrayBuffer ? control : control.buffer;
      const pAb = pcm instanceof ArrayBuffer ? pcm : pcm.buffer;
      const c = cAb.slice(0);
      const p = pAb.slice(0);
      this._romsResolve = (msg) => {
        if (msg.ok) {
          if (typeof msg.displayDefaultOld === 'boolean') {
            this._displayDefaultOldCompat = msg.displayDefaultOld;
          }
          if (typeof msg.displayOld === 'boolean') {
            this._displayOldCompat = msg.displayOld;
          }
          resolve(msg);
        } else {
          reject(new Error(msg.detail || 'ROM load failed in worklet'));
        }
      };
      this._node.port.postMessage({
        type: 'roms',
        control: c,
        pcm: p,
        displayCompatOverride:
          this._displayCompatOverride == null
            ? null
            : !!this._displayCompatOverride,
      });
      setTimeout(() => {
        if (this._romsResolve) {
          this._romsResolve = null;
          reject(new Error('ROM load timeout'));
        }
      }, 15000);
    })
      .then(() => {
        this._romsLoaded = true;
        this._applyDisplayCompatAfterOpen();
      })
      .catch((err) => {
        this._romsLoaded = false;
        this._lastError = err.message;
        throw err;
      });
  }

  _playSysexMain(u8) {
    let bytes = u8;
    if (u8.length && u8[0] !== 0xf0) {
      const framed = new Uint8Array(u8.length + 2);
      framed[0] = 0xf0;
      framed.set(u8, 1);
      framed[framed.length - 1] = 0xf7;
      bytes = framed;
    }
    const ptr = this._api.malloc(bytes.byteLength);
    if (!ptr) return;
    this._api.Module.HEAPU8.set(bytes, ptr);
    this._api.playSysex(this._st, ptr, bytes.byteLength);
    this._api.freeBuf(ptr);
    this._pollDisplayMain();
  }

  _pollDisplayMain() {
    if (!this._api || !this._st || !this._api.isOpen(this._st)) return;
    if (typeof this._api.getDisplayState !== 'function') return;
    if (!this._displayBufPtr) {
      this._displayBufPtr = this._api.malloc(32);
      if (!this._displayBufPtr) return;
    }
    try {
      this._midiLed = !!this._api.getDisplayState(this._st, this._displayBufPtr, 0);
      this._displayText = decodeMt32LcdChars(
        this._api.Module.HEAPU8,
        this._displayBufPtr,
        20,
      );
      if (typeof window !== 'undefined' && window.__debug) {
        window.__debug.lcdText = this._displayText;
        window.__debug.midiLed = this._midiLed;
      }
    } catch (_) {}
  }

  _ensureRenderBufMain(frames) {
    if (this._renderFrames >= frames && this._renderPtr) return;
    if (this._renderPtr) {
      this._api.freeBuf(this._renderPtr);
      this._renderPtr = 0;
    }
    this._renderPtr = this._api.malloc(frames * 2 * 4);
    if (!this._renderPtr) throw new Error('render malloc failed');
    this._renderFrames = frames;
  }

  _freeMainSynth() {
    if (this._displayBufPtr && this._api) {
      try {
        this._api.freeBuf(this._displayBufPtr);
      } catch (_) {}
      this._displayBufPtr = 0;
    }
    if (this._renderPtr && this._api) {
      try {
        this._api.freeBuf(this._renderPtr);
      } catch (_) {}
      this._renderPtr = 0;
      this._renderFrames = 0;
    }
    if (this._st && this._api) {
      try {
        this._api.free(this._st);
      } catch (_) {}
      this._st = 0;
    }
    this._api = null;
    this._displayText = 'MUNT ---';
    this._midiLed = false;
  }
}

export default MuntEngine;
