/**
 * MT-32 Web Player — Engine Interface
 *
 * Abstract base class defining the contract all engine backends must implement.
 * Stub methods throw descriptive errors until real engines are wired in later tasks.
 *
 * @module engine/interface
 */

/**
 * Base class for all synthesis engines (munt, tsf).
 *
 * Subclasses MUST override the methods below. The base implementations throw
 * `Error('not implemented')` with the method name for early detection of
 * incomplete adapters.
 */
export class Engine {
  /**
   * @param {string} id — Canonical engine identifier ('munt', 'tsf')
   * @param {string} name — Human-readable name for UI display
   */
  constructor(id, name) {
    if (new.target === Engine) {
      throw new TypeError('Engine is abstract — instantiate a subclass');
    }
    this.id = id;
    this.name = name;
    this._initialized = false;
    this._volume = 1;
  }

  /* ------------------------------------------------------------------ */
  /*  Lifecycle                                                         */
  /* ------------------------------------------------------------------ */

  /**
   * Initialize the engine. Prepares WASM module, worklet, etc.
   * @param {object} [opts]
   * @param {number} [opts.sampleRate] — Preferred sample rate
   * @returns {Promise<void>}
   */
  async init(opts = {}) {
    this._notImplemented('init');
  }

  /**
   * Load MT-32 / CM-32L ROM data into the engine.
   * @param {{control: ArrayBuffer, pcm: ArrayBuffer}} roms
   * @returns {Promise<void>}
   */
  async loadRoms(roms) {
    this._notImplemented('loadRoms');
  }

  /**
   * Load a SoundFont (.sf2) for TSF-based synthesis.
   * @param {ArrayBuffer} bytes — Raw SF2 file bytes
   * @returns {Promise<void>}
   */
  async loadSf2(bytes) {
    this._notImplemented('loadSf2');
  }

  /* ------------------------------------------------------------------ */
  /*  MIDI                                                              */
  /* ------------------------------------------------------------------ */

  /**
   * Send a short MIDI message (status + 1–2 data bytes).
   * @param {number} status — Status byte (0x80–0xFF)
   * @param {number} [data1=0] — First data byte
   * @param {number} [data2=0] — Second data byte (velocity, value, etc.)
   */
  playMsg(status, data1 = 0, data2 = 0) {
    this._notImplemented('playMsg');
  }

  /**
   * Send a System Exclusive message.
   * @param {Uint8Array|number[]} sysex — SysEx bytes (without 0xF0/0xF7 framing)
   */
  playSysex(sysex) {
    this._notImplemented('playSysex');
  }

  /**
   * Convenience: send a NOTE ON message on a given channel.
   * @param {number} channel  — MIDI channel 0–15
   * @param {number} note     — Note number 0–127
   * @param {number} velocity — Velocity 0–127
   */
  noteOn(channel, note, velocity = 100) {
    this.playMsg(0x90 | (channel & 0x0F), note & 0x7F, velocity & 0x7F);
  }

  /**
   * Convenience: send a NOTE OFF message on a given channel.
   * @param {number} channel  — MIDI channel 0–15
   * @param {number} note     — Note number 0–127
   * @param {number} velocity — Release velocity 0–127
   */
  noteOff(channel, note, velocity = 64) {
    this.playMsg(0x80 | (channel & 0x0F), note & 0x7F, velocity & 0x7F);
  }

  /* ------------------------------------------------------------------ */
  /*  Control                                                           */
  /* ------------------------------------------------------------------ */

  /**
   * Reset the engine (all notes off, controllers reset to defaults).
   */
  reset() {
    this._notImplemented('reset');
  }

  /**
   * Set the output volume of this engine (independent of master gain).
   * @param {number} vol — 0.0 (silent) to 1.0 (full)
   */
  setVolume(vol) {
    this._volume = Math.max(0, Math.min(1, vol));
  }

  /**
   * Connect the engine's audio output to a Web Audio destination.
   * @param {AudioContext} ctx
   * @param {AudioNode} destination — Typically a GainNode or AudioDestinationNode
   */
  connect(ctx, destination) {
    this._notImplemented('connect');
  }

  /**
   * Tear down the engine: disconnect nodes, free WASM memory, etc.
   * @returns {Promise<void>}
   */
  async dispose() {
    this._notImplemented('dispose');
  }

  /* ------------------------------------------------------------------ */
  /*  Status                                                            */
  /* ------------------------------------------------------------------ */

  /**
   * Return a plain object describing the engine's current displayable state.
   * Shape: `{ text, patch?, ledReady?, ledMidi? }`
   * @returns {object}
   */
  getDisplayState() {
    return {
      text: this.id.toUpperCase(),
      patch: '---',
      ledReady: this._initialized,
      ledMidi: false,
    };
  }

  /* ------------------------------------------------------------------ */
  /*  Internal helpers                                                  */
  /* ------------------------------------------------------------------ */

  /** @private */
  _notImplemented(method) {
    throw new Error(
      `[mt32-web] ${this.id} engine: "${method}()" is not implemented yet. ` +
      `Engine adapters will be wired in a later task.`
    );
  }
}
