﻿/**
 * Munt / libmt32emu WASM loader helpers.
 * Binary: ./wasm/mt32emu.js + ./wasm/mt32emu.wasm (separate files, LGPL-friendly)
 * Build: . <emsdk>/emsdk_env.ps1 ; .\tools\build-mt32emu.ps1
 */
export async function loadMt32EmuModule(options = {}) {
  const base = options.baseUrl || "./wasm";
  const jsUrl = options.jsUrl || `${base}/mt32emu.js`;
  const wasmUrl = options.wasmUrl || `${base}/mt32emu.wasm`;

  await new Promise((resolve, reject) => {
    if (typeof createMt32EmuModule === "function") {
      resolve();
      return;
    }
    const s = document.createElement("script");
    s.src = jsUrl;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Failed to load ${jsUrl}`));
    document.head.appendChild(s);
  });

  if (typeof createMt32EmuModule !== "function") {
    throw new Error("createMt32EmuModule not found after loading mt32emu.js");
  }

  const Module = await createMt32EmuModule({
    locateFile: (path) => (path.endsWith(".wasm") ? wasmUrl : `${base}/${path}`),
    ...(options.moduleConfig || {}),
  });
  return Module;
}

export function wrapMt32Api(Module) {
  const c = (name, ret, args) => Module.cwrap(name, ret, args);
  return {
    create: c("mt32_create", "number", []),
    free: c("mt32_free", null, ["number"]),
    addRomData: c("mt32_add_rom_data", "number", ["number", "number", "number", "number"]),
    open: c("mt32_open", "number", ["number"]),
    close: c("mt32_close", null, ["number"]),
    isOpen: c("mt32_is_open", "number", ["number"]),
    playMsg: c("mt32_play_msg", "number", ["number", "number"]),
    playSysex: c("mt32_play_sysex", "number", ["number", "number", "number"]),
    renderFloat: c("mt32_render_float", null, ["number", "number", "number"]),
    renderBit16s: c("mt32_render_bit16s", null, ["number", "number", "number"]),
    getSampleRate: c("mt32_get_samplerate", "number", ["number"]),
    setSampleRate: c("mt32_set_samplerate", null, ["number", "number"]),
    libraryVersion: c("mt32_library_version", "string", []),
    getDisplayState: c("mt32_get_display_state", "number", [
      "number",
      "number",
      "number",
    ]),
    setMainDisplayMode: c("mt32_set_main_display_mode", null, ["number"]),
    setDisplayCompatibility: c("mt32_set_display_compatibility", null, [
      "number",
      "number",
    ]),
    isDisplayOldMT32Compatible: c(
      "mt32_is_display_old_mt32_compatible",
      "number",
      ["number"],
    ),
    isDefaultDisplayOldMT32Compatible: c(
      "mt32_is_default_display_old_mt32_compatible",
      "number",
      ["number"],
    ),
    malloc: c("mt32_malloc", "number", ["number"]),
    freeBuf: c("mt32_free_buf", null, ["number"]),
    HEAPU8: Module.HEAPU8,
    HEAPF32: Module.HEAPF32,
    Module,
  };
}
