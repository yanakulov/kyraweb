﻿/**
 * Cross-thread protocol for munt AudioWorklet (no SAB/COOP).
 * Main→worklet: init | roms | msg | sysex | reset | setSampleRate | setVolume | mainDisplay | displayCompat
 * Worklet→main: ready | romsLoaded | error | peak | display
 */

function decodeMt32LcdChars(heapU8, ptr, len = 20) {
  let s = '';
  const n = Math.max(0, len | 0);
  for (let i = 0; i < n; i++) {
    const b = heapU8[ptr + i] & 0xff;
    if (b === 0) {
      while (i < n) {
        s += ' ';
        i++;
      }
      break;
    }
    if (b === 1) s += '\u0001';
    else if (b < 32 || b > 126) s += ' ';
    else s += String.fromCharCode(b);
  }
  return s;
}

function wrapMt32Api(Module) {
  const c = (name, ret, args) => Module.cwrap(name, ret, args);
  return {
    create: c('mt32_create', 'number', []),
    free: c('mt32_free', null, ['number']),
    addRomData: c('mt32_add_rom_data', 'number', ['number', 'number', 'number', 'number']),
    open: c('mt32_open', 'number', ['number']),
    close: c('mt32_close', null, ['number']),
    isOpen: c('mt32_is_open', 'number', ['number']),
    playMsg: c('mt32_play_msg', 'number', ['number', 'number']),
    playSysex: c('mt32_play_sysex', 'number', ['number', 'number', 'number']),
    renderFloat: c('mt32_render_float', null, ['number', 'number', 'number']),
    getSampleRate: c('mt32_get_samplerate', 'number', ['number']),
    setSampleRate: c('mt32_set_samplerate', null, ['number', 'number']),
    libraryVersion: c('mt32_library_version', 'string', []),
    getDisplayState: c('mt32_get_display_state', 'number', [
      'number',
      'number',
      'number',
    ]),
    setMainDisplayMode: c('mt32_set_main_display_mode', null, ['number']),
    setDisplayCompatibility: c('mt32_set_display_compatibility', null, [
      'number',
      'number',
    ]),
    isDisplayOldMT32Compatible: c(
      'mt32_is_display_old_mt32_compatible',
      'number',
      ['number'],
    ),
    isDefaultDisplayOldMT32Compatible: c(
      'mt32_is_default_display_old_mt32_compatible',
      'number',
      ['number'],
    ),
    malloc: c('mt32_malloc', 'number', ['number']),
    freeBuf: c('mt32_free_buf', null, ['number']),
    HEAPU8: Module.HEAPU8,
    HEAPF32: Module.HEAPF32,
    Module,
  };
}

function xhrArrayBuffer(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'arraybuffer';
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.response);
      else reject(new Error('XHR ' + xhr.status + ' ' + url));
    };
    xhr.onerror = () => reject(new Error('XHR network error ' + url));
    xhr.send();
  });
}

function xhrText(url) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.responseType = 'text';
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(xhr.responseText);
      else reject(new Error('XHR ' + xhr.status + ' ' + url));
    };
    xhr.onerror = () => reject(new Error('XHR network error ' + url));
    xhr.send();
  });
}

async function loadModuleInWorklet(jsUrl, wasmUrl, prefetched) {
  let jsText;
  let wasmBinary;
  if (prefetched && prefetched.jsText) {
    jsText = prefetched.jsText;
    wasmBinary = prefetched.wasmBinary || null;
  } else if (typeof fetch === 'function') {
    jsText = await (await fetch(jsUrl, { credentials: 'same-origin' })).text();
    if (wasmUrl) {
      wasmBinary = await (await fetch(wasmUrl, { credentials: 'same-origin' })).arrayBuffer();
    }
  } else {
    jsText = await xhrText(jsUrl);
    if (wasmUrl) wasmBinary = await xhrArrayBuffer(wasmUrl);
  }
  // AudioWorklet has no Blob/URL.createObjectURL in some environments — eval factory.
  const factory = new Function(
    jsText +
      ';\n' +
      'if (typeof createMt32EmuModule === "function") return createMt32EmuModule;\n' +
      'throw new Error("createMt32EmuModule missing after eval");\n'
  )();
  if (typeof factory !== 'function') {
    throw new Error('createMt32EmuModule not a function');
  }
  const config = {};
  if (wasmBinary) {
    config.wasmBinary = wasmBinary;
  } else {
    config.locateFile = (path) => (path.endsWith('.wasm') ? wasmUrl : path);
  }
  return await factory(config);
}

class MuntProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this._api = null;
    this._st = 0;
    this._renderPtr = 0;
    this._renderFrames = 0;
    this._volume = 1;
    this._sampleRate = sampleRate;
    this._initPromise = null;
    this._peak = 0;
    this._peakCounter = 0;
    this._displayPtr = 0;
    this._displayCounter = 0;
    this._lastDisplayText = '';
    this._lastMidiLed = false;

    this.port.onmessage = (ev) => {
      this._onMessage(ev.data).catch((err) => {
        this.port.postMessage({
          type: 'error',
          message: String(err && err.message ? err.message : err),
        });
      });
    };
  }

  async _onMessage(msg) {
    if (!msg || !msg.type) return;

    switch (msg.type) {
      case 'init':
        await this._init(msg);
        break;
      case 'roms':
        await this._loadRoms(msg.control, msg.pcm, msg);
        break;
      case 'msg':
        if (this._api && this._st && this._api.isOpen(this._st)) {
          this._api.playMsg(this._st, msg.packed >>> 0);
        }
        break;
      case 'sysex':
        this._playSysex(msg.data);
        break;
      case 'reset':
        break;
      case 'setSampleRate':
        if (this._api && this._st && typeof msg.rate === 'number') {
          this._sampleRate = msg.rate;
          this._api.setSampleRate(this._st, msg.rate);
        }
        break;
      case 'setVolume':
        if (typeof msg.volume === 'number') {
          this._volume = Math.max(0, Math.min(1, msg.volume));
        }
        break;
      case 'mainDisplay':
        if (this._api && this._st && this._api.isOpen(this._st) && this._api.setMainDisplayMode) {
          this._api.setMainDisplayMode(this._st);
          this._pollDisplay();
        }
        break;
      case 'displayCompat':
        if (
          this._api &&
          this._st &&
          this._api.isOpen(this._st) &&
          typeof this._api.setDisplayCompatibility === 'function'
        ) {
          this._api.setDisplayCompatibility(this._st, msg.oldMt32 ? 1 : 0);
          this._pollDisplay();
          this.port.postMessage({
            type: 'displayCompatState',
            displayOld: this._readDisplayOld(),
            displayDefaultOld: this._readDisplayDefaultOld(),
          });
        }
        break;
      default:
        break;
    }
  }

  async _init(msg) {
    if (this._initPromise) {
      await this._initPromise;
      return;
    }
    this._initPromise = (async () => {
      const jsUrl = msg.jsUrl || './wasm/mt32emu.js';
      const wasmUrl = msg.wasmUrl || './wasm/mt32emu.wasm';
      if (typeof msg.sampleRate === 'number' && msg.sampleRate > 0) {
        this._sampleRate = msg.sampleRate;
      }
      const Module = await loadModuleInWorklet(jsUrl, wasmUrl, {
        jsText: msg.jsText || null,
        wasmBinary: msg.wasmBinary || null,
      });
      this._api = wrapMt32Api(Module);
      this._st = this._api.create();
      if (!this._st) {
        throw new Error('mt32_create failed');
      }
      let version = '';
      try {
        version = this._api.libraryVersion() || '';
      } catch (_) {
        version = '';
      }
      this.port.postMessage({ type: 'ready', version });
    })();
    await this._initPromise;
  }

  _ensureRenderBuf(frames) {
    if (this._renderFrames >= frames && this._renderPtr) return;
    if (this._renderPtr) {
      this._api.freeBuf(this._renderPtr);
      this._renderPtr = 0;
    }
    const bytes = frames * 2 * 4;
    this._renderPtr = this._api.malloc(bytes);
    if (!this._renderPtr) {
      throw new Error('mt32_malloc render buffer failed');
    }
    this._renderFrames = frames;
  }

  async _loadRoms(control, pcm, opts = {}) {
    if (!this._api || !this._st) {
      this.port.postMessage({ type: 'romsLoaded', ok: false, detail: 'synth not ready' });
      return;
    }
    if (!control || !pcm) {
      this.port.postMessage({ type: 'romsLoaded', ok: false, detail: 'missing control or pcm ROM' });
      return;
    }

    if (this._api.isOpen(this._st)) {
      this._api.close(this._st);
    }

    const add = (buf, type) => {
      const u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
      const ptr = this._api.malloc(u8.byteLength);
      if (!ptr) throw new Error('malloc ROM failed');
      this._api.Module.HEAPU8.set(u8, ptr);
      const rc = this._api.addRomData(this._st, ptr, u8.byteLength, type);
      this._api.freeBuf(ptr);
      return rc;
    };

    try {
      const rc0 = add(control, 0);
      const rc1 = add(pcm, 1);
      if (rc0 < 0 || rc1 < 0) {
        this.port.postMessage({
          type: 'romsLoaded',
          ok: false,
          detail: `addRomData failed (control=${rc0}, pcm=${rc1})`,
        });
        return;
      }
      this._api.setSampleRate(this._st, this._sampleRate);
      const openRc = this._api.open(this._st);
      if (openRc < 0) {
        this.port.postMessage({
          type: 'romsLoaded',
          ok: false,
          detail: `mt32_open failed (${openRc})`,
        });
        return;
      }
      this._api.setSampleRate(this._st, this._sampleRate);
      const displayDefaultOld = this._readDisplayDefaultOld();
      if (
        typeof opts.displayCompatOverride === 'boolean' &&
        typeof this._api.setDisplayCompatibility === 'function'
      ) {
        this._api.setDisplayCompatibility(
          this._st,
          opts.displayCompatOverride ? 1 : 0,
        );
      }
      const displayOld = this._readDisplayOld();
      this.port.postMessage({
        type: 'romsLoaded',
        ok: true,
        detail: `open rc=${openRc} rate=${this._api.getSampleRate(this._st)} displayOld=${displayOld} defaultOld=${displayDefaultOld}`,
        displayOld,
        displayDefaultOld,
      });
      this._lastDisplayText = '';
      this._pollDisplay();
    } catch (err) {
      this.port.postMessage({
        type: 'romsLoaded',
        ok: false,
        detail: String(err && err.message ? err.message : err),
      });
    }
  }

  _readDisplayOld() {
    if (
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.isDisplayOldMT32Compatible === 'function'
    ) {
      return !!this._api.isDisplayOldMT32Compatible(this._st);
    }
    return null;
  }

  _readDisplayDefaultOld() {
    if (
      this._api &&
      this._st &&
      this._api.isOpen(this._st) &&
      typeof this._api.isDefaultDisplayOldMT32Compatible === 'function'
    ) {
      return !!this._api.isDefaultDisplayOldMT32Compatible(this._st);
    }
    return null;
  }

  _playSysex(data) {
    if (!this._api || !this._st || !this._api.isOpen(this._st) || !data) return;
    const u8 = data instanceof Uint8Array ? data : new Uint8Array(data);
    let bytes = u8;
    if (u8.length && u8[0] !== 0xf0) {
      const framed = new Uint8Array(u8.length + 2);
      framed[0] = 0xf0;
      framed.set(u8, 1);
      framed[framed.length - 1] = 0xf7;
      bytes = framed;
    }
    const ptr = this._api.malloc(bytes.byteLength);
    if (!ptr) return;
    this._api.Module.HEAPU8.set(bytes, ptr);
    this._api.playSysex(this._st, ptr, bytes.byteLength);
    this._api.freeBuf(ptr);
    this._pollDisplay();
  }

  process(_inputs, outputs) {
    const output = outputs[0];
    if (!output || !output.length) return true;

    const left = output[0];
    const right = output[1] || output[0];
    const frames = left.length;

    left.fill(0);
    if (right !== left) right.fill(0);

    if (!this._api || !this._st || !this._api.isOpen(this._st)) {
      return true;
    }

    try {
      this._ensureRenderBuf(frames);
      this._api.renderFloat(this._st, this._renderPtr, frames);
      const heap = this._api.Module.HEAPF32;
      const base = this._renderPtr >> 2;
      const vol = this._volume;
      let peak = 0;
      for (let i = 0; i < frames; i++) {
        const l = heap[base + i * 2] * vol;
        const r = heap[base + i * 2 + 1] * vol;
        left[i] = l;
        right[i] = r;
        const a = Math.abs(l) > Math.abs(r) ? Math.abs(l) : Math.abs(r);
        if (a > peak) peak = a;
      }
      this._peak = Math.max(this._peak * 0.95, peak);
      this._peakCounter++;
      if (this._peakCounter >= 64) {
        this._peakCounter = 0;
        this.port.postMessage({ type: 'peak', value: this._peak });
      }
      this._displayCounter++;
      if (this._displayCounter >= 32) {
        this._displayCounter = 0;
        this._pollDisplay();
      }
    } catch (err) {
      this.port.postMessage({
        type: 'error',
        message: 'render: ' + (err && err.message ? err.message : err),
      });
    }

    return true;
  }

  _pollDisplay() {
    if (!this._api || !this._st || !this._api.isOpen(this._st)) return;
    if (typeof this._api.getDisplayState !== 'function') return;
    if (!this._displayPtr) {
      this._displayPtr = this._api.malloc(32);
      if (!this._displayPtr) return;
    }
    const ledOn = !!this._api.getDisplayState(this._st, this._displayPtr, 0);
    const text = decodeMt32LcdChars(
      this._api.Module.HEAPU8,
      this._displayPtr,
      20,
    );
    if (text === this._lastDisplayText && ledOn === this._lastMidiLed) return;
    this._lastDisplayText = text;
    this._lastMidiLed = ledOn;
    this.port.postMessage({ type: 'display', text, midiLed: ledOn });
  }
}

registerProcessor('munt-processor', MuntProcessor);
