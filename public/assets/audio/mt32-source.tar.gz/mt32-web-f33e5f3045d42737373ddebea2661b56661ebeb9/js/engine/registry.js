import { MuntEngine } from './munt-engine.js';
import { TsfEngine } from './tsf-engine.js';

export const ENGINE_IDS = ['munt', 'tsf'];

export const ENGINE_META = Object.freeze({
  munt: {
    id: 'munt',
    name: 'munt (libmt32emu)',
    desc: 'Authentic MT-32/CM-32L synthesis via libmt32emu WASM',
    requiresRom: true,
    requiresSf2: false,
  },
  tsf: {
    id: 'tsf',
    name: 'tsf (TinySoundFont)',
    desc: 'SoundFont fallback via TinySoundFont WASM',
    requiresRom: false,
    requiresSf2: true,
  },
});

export function createEngine(id) {
  switch (id) {
    case 'munt':
      return new MuntEngine();
    case 'tsf':
      return new TsfEngine();
    default:
      throw new Error(`[mt32-web] Unknown engine id "${id}"`);
  }
}

export function suggestDefaultEngine(assets) {
  if (assets.hasRoms) return 'munt';
  if (assets.hasSf2) return 'tsf';
  return ENGINE_IDS[0];
}
