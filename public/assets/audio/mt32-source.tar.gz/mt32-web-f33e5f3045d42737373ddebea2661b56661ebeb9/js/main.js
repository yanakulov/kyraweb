import { getContext, resumeContext, wireVolumeSlider, getMasterGain, setMasterVolume } from './audio/context.js';
import { ENGINE_IDS, createEngine } from './engine/registry.js';
import { parseSmf } from './midi/smf-parser.js';
import { MidiScheduler } from './midi/scheduler.js';
import {
  requestWebMidi,
  setupDebugMidi,
  setMidiInputsChangedHandler,
  setSelectedMidiInputId,
  getSelectedMidiInputId,
  MIDI_INPUT_ALL,
  MIDI_INPUT_NONE,
  isWebMidiAvailable,
  hasMidiAccess,
} from './midi/webmidi.js';
import { Mt32FrontPanel } from './midi/mt32-front-panel.js';
import { LcdDisplay } from './chassis3d/lcd.js';
import {
  setupRomDrop,
  setupSf2Drop,
  clearRoms,
  validateSf2Size,
  getStoredRoms,
} from './rom/store.js';

const transport = new MidiScheduler();
const frontPanel = new Mt32FrontPanel();
let activeEngine = null;
let engineReady = false;
let chassis3d = null;
let lcd2d = null;
let chassisInitPromise = null;

const PREF_FORCE_WEBGL = 'mt32-web.forceWebGL';
const PREF_SHOW_3D = 'mt32-web.show3d';
const PREF_SHOW_2D = 'mt32-web.show2d';

function readPref(key, defaultOn) {
  try {
    const v = localStorage.getItem(key);
    if (v === null || v === undefined) return defaultOn;
    return v === '1' || v === 'true';
  } catch (_) {
    return defaultOn;
  }
}

function writePref(key, on) {
  try {
    localStorage.setItem(key, on ? '1' : '0');
  } catch (_) {}
}

function getDisplayPrefs() {
  const urlForce =
    typeof window !== 'undefined' && window.location.search.includes('webgl=1');
  return {
    forceWebGL: urlForce || readPref(PREF_FORCE_WEBGL, false),
    show3d: readPref(PREF_SHOW_3D, true),
    show2d: readPref(PREF_SHOW_2D, true),
  };
}

function ensureLcd2d() {
  if (!getDisplayPrefs().show2d) return null;
  if (lcd2d) return lcd2d;
  const host = document.getElementById('lcd');
  if (!host || host.classList.contains('display-off')) return null;
  lcd2d = new LcdDisplay();
  host.replaceChildren(lcd2d.canvas);
  lcd2d.setText('MT-32 WEB');
  return lcd2d;
}

function applyWebVolume01(v) {
  const t = Math.max(0, Math.min(1, v));
  setMasterVolume(t);
  if (activeEngine && typeof activeEngine.setVolume === 'function') {
    activeEngine.setVolume(t);
  }
}

function chassisStatus(msg) {
  const el = document.getElementById('status');
  if (el && msg) el.textContent = msg;
}

const PANEL_KEY_TO_ID = {
  Digit1: 'part1',
  Digit2: 'part2',
  Digit3: 'part3',
  Digit4: 'part4',
  Digit5: 'part5',
  Numpad1: 'part1',
  Numpad2: 'part2',
  Numpad3: 'part3',
  Numpad4: 'part4',
  Numpad5: 'part5',
  KeyS: 'sound',
  KeyG: 'sound-group',
  KeyV: 'volume',
  KeyM: 'master-volume',
  KeyR: 'rhythm',
};

const _kbHeldPanelIds = new Set();

function panelEngine() {
  return activeEngine && (activeEngine.id === 'munt' || typeof activeEngine.playSysex === 'function')
    ? activeEngine
    : null;
}

function syncChassisButtonsFromHeld() {
  syncChassisButtonsFromPanel();
}

function applyPanelResult(r, id) {
  if (!r) return;
  if (chassis3d && typeof r.knob01 === 'number') {
    chassis3d.setVolume01(r.knob01, true);
    frontPanel.potLast01 = r.knob01;
  }
  if (r.webVolume01 != null) {
    applyWebVolume01(r.webVolume01);
    const volumeSlider = document.getElementById('volume');
    if (volumeSlider) {
      volumeSlider.value = String(r.webVolume01);
    }
  }
  if (r.lcd != null) setLcdTextBoth(r.lcd);
  else if (r.panelLcdActive === false && activeEngine) updateLeds(activeEngine);
  if (r.status) chassisStatus(r.status);
  syncChassisButtonsFromHeld();
  if (window.__debug) {
    if (id) window.__debug.lastChassisButton = id;
    window.__debug.frontPanelMode = frontPanel.mode;
    window.__debug.frontPanelPart = frontPanel.selectedPart;
    window.__debug.frontPanel = frontPanel;
  }
}

function isTypingTarget(el) {
  if (!el || !(el instanceof Element)) return false;
  const tag = el.tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
  if (el.isContentEditable) return true;
  return !!el.closest('[contenteditable="true"]');
}

function wirePanelKeyboard() {
  if (window.__kbPanelWired === '1') return;
  window.__kbPanelWired = '1';

  window.addEventListener('keydown', (e) => {
    if (e.repeat) return;
    if (isTypingTarget(e.target)) return;

    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
      frontPanel.setKeyboardMaster(true);
      syncChassisButtonsFromHeld();
      return;
    }

    if (e.code === 'KeyR' && e.altKey) {
      e.preventDefault();
      applyPanelResult(frontPanel.showFirmwareVersion());
      return;
    }

    if (e.ctrlKey || e.altKey || e.metaKey) return;

    const id = PANEL_KEY_TO_ID[e.code];
    if (!id) return;
    e.preventDefault();
    if (_kbHeldPanelIds.has(id)) return;
    _kbHeldPanelIds.add(id);
    applyPanelResult(frontPanel.pressButton(id, panelEngine()), id);
  });

  window.addEventListener('keyup', (e) => {
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') {
      frontPanel.setKeyboardMaster(false);
      syncChassisButtonsFromHeld();
      return;
    }

    const id = PANEL_KEY_TO_ID[e.code];
    if (!id) return;
    if (!_kbHeldPanelIds.has(id) && !frontPanel.held.has(id)) return;
    _kbHeldPanelIds.delete(id);
    applyPanelResult(frontPanel.releaseButton(id), id);
  });

  window.addEventListener('blur', () => {
    for (const id of [..._kbHeldPanelIds]) {
      _kbHeldPanelIds.delete(id);
      applyPanelResult(frontPanel.releaseButton(id), id);
    }
    frontPanel.setKeyboardMaster(false);
    syncChassisButtonsFromHeld();
  });
}

function disposeChassis3D() {
  if (chassis3d && typeof chassis3d.dispose === 'function') {
    try {
      chassis3d.dispose();
    } catch (_) {}
  }
  chassis3d = null;
  chassisInitPromise = null;
  const container = document.getElementById('chassis3d');
  if (container) {
    container.replaceChildren();
    container.classList.remove('chassis3d-failed');
  }
  const wrap = document.getElementById('orbit-toggle-wrap');
  if (wrap) wrap.classList.add('hidden');
}

async function setupChassis3D(volumeSlider) {
  const container = document.getElementById('chassis3d');
  if (!container) return null;
  if (!getDisplayPrefs().show3d) {
    container.classList.add('display-off');
    return null;
  }
  if (chassis3d) return chassis3d;
  if (chassisInitPromise) return chassisInitPromise;

  chassisInitPromise = (async () => {
  try {
    container.classList.remove('display-off', 'chassis3d-failed');
    const prefs = getDisplayPrefs();
    const { initChassis3D } = await import('./chassis3d/main3d.js?v=btn-hold-2');
    let syncing = false;

    chassis3d = await initChassis3D(container, {
      forceWebGL: prefs.forceWebGL,
      onVolumeChange: (v) => {
        const r = frontPanel.setKnob01(v, panelEngine());
        applyPanelResult(r);
        if (r.webVolume01 == null && !panelEngine()) {
          applyWebVolume01(v);
          if (volumeSlider) {
            syncing = true;
            volumeSlider.value = String(v);
            syncing = false;
          }
        }
      },
      onButtonPress: (id) => {
        const r = frontPanel.pressButton(id, panelEngine());
        applyPanelResult(r, id);
      },
      onButtonRelease: (id) => {
        const r = frontPanel.releaseButton(id);
        applyPanelResult(r, id);
      },
    });
    if (volumeSlider) {
      chassis3d.setVolume01(frontPanel.knob01ForMode(), true);
      frontPanel.masterVol = Math.round(parseFloat(volumeSlider.value) * 100);
      if (volumeSlider.dataset.chassisVolWired !== '1') {
        volumeSlider.dataset.chassisVolWired = '1';
        volumeSlider.addEventListener('input', () => {
          if (syncing || !chassis3d) return;
          const v = parseFloat(volumeSlider.value);
          if (frontPanel.mode === 'master' || frontPanel.mode === 'main') {
            chassis3d.setVolume01(v, true);
            frontPanel.potCaught = true;
            frontPanel.setKnob01(v, panelEngine());
            applyWebVolume01(v);
          } else {
            applyWebVolume01(v);
          }
        });
      }
    }

    syncChassisButtonsFromHeld();
    updateLeds(activeEngine);
    wireOrbitToggle();
    if (window.__debug) window.__debug.chassis3d = chassis3d;
    return chassis3d;
  } catch (err) {
    console.info('[chassis3d] 3D panel unavailable:', err && err.message ? err.message : err);
    container.classList.add('chassis3d-failed');
    chassis3d = null;
    const wrap = document.getElementById('orbit-toggle-wrap');
    if (wrap) wrap.classList.add('hidden');
    return null;
  } finally {
    chassisInitPromise = null;
  }
  })();
  return chassisInitPromise;
}

function wireOrbitToggle() {
  const cb = document.getElementById('orbit-toggle');
  const wrap = document.getElementById('orbit-toggle-wrap');
  if (!cb || !chassis3d || typeof chassis3d.setOrbitEnabled !== 'function') {
    if (wrap) wrap.classList.add('hidden');
    return;
  }
  if (wrap) wrap.classList.remove('hidden');
  cb.checked = !!chassis3d.getOrbitEnabled?.();
  if (cb.dataset.wired === '1') return;
  cb.dataset.wired = '1';
  cb.addEventListener('change', async () => {
    try {
      if (chassis3d && typeof chassis3d.setOrbitEnabled === 'function') {
        await chassis3d.setOrbitEnabled(cb.checked);
      }
    } catch (err) {
      cb.checked = false;
      console.warn('[chassis3d] orbit toggle failed:', err);
    }
  });
}

function applyDisplayVisibility() {
  const prefs = getDisplayPrefs();
  const stage = document.querySelector('.stage');
  const chassisEl = document.getElementById('chassis3d');
  const lcdEl = document.getElementById('lcd');
  const orbitWrap = document.getElementById('orbit-toggle-wrap');
  const forceCb = document.getElementById('toggle-force-webgl');
  const show3dCb = document.getElementById('toggle-show-3d');
  const show2dCb = document.getElementById('toggle-show-2d');

  if (forceCb) forceCb.checked = prefs.forceWebGL;
  if (show3dCb) show3dCb.checked = prefs.show3d;
  if (show2dCb) show2dCb.checked = prefs.show2d;

  if (stage) stage.classList.toggle('no-3d', !prefs.show3d);
  if (chassisEl) {
    chassisEl.classList.toggle('display-off', !prefs.show3d);
  }
  if (lcdEl) {
    lcdEl.classList.toggle('display-off', !prefs.show2d);
  }
  if (!prefs.show3d && orbitWrap) orbitWrap.classList.add('hidden');
  if (!prefs.show2d) {
    lcd2d = null;
  }
}

function wireDisplayToggles(volumeSlider) {
  const forceCb = document.getElementById('toggle-force-webgl');
  const show3dCb = document.getElementById('toggle-show-3d');
  const show2dCb = document.getElementById('toggle-show-2d');

  applyDisplayVisibility();

  if (forceCb) {
    forceCb.addEventListener('change', () => {
      writePref(PREF_FORCE_WEBGL, forceCb.checked);
      const url = new URL(window.location.href);
      if (forceCb.checked) url.searchParams.set('webgl', '1');
      else url.searchParams.delete('webgl');
      window.location.replace(url.pathname + url.search + url.hash);
    });
  }

  if (show3dCb) {
    show3dCb.addEventListener('change', async () => {
      writePref(PREF_SHOW_3D, show3dCb.checked);
      if (show3dCb.checked) {
        applyDisplayVisibility();
        await setupChassis3D(volumeSlider || document.getElementById('volume'));
        updateLeds(activeEngine);
      } else {
        disposeChassis3D();
        applyDisplayVisibility();
      }
    });
  }

  if (show2dCb) {
    show2dCb.addEventListener('change', () => {
      writePref(PREF_SHOW_2D, show2dCb.checked);
      applyDisplayVisibility();
      if (show2dCb.checked) {
        ensureLcd2d();
        _lastLcdText = '';
        updateLeds(activeEngine);
      }
    });
  }
}

async function setStatus(el, msg) {
  if (el) el.textContent = msg;
}

let _lcdPollTimer = null;
let _lastLcdText = '';
let _lastMidiLed = false;

function setLcdTextBoth(text) {
  const t = text == null ? '' : String(text);
  if (t === _lastLcdText) return;
  _lastLcdText = t;
  const panel = ensureLcd2d();
  if (panel) panel.setText(t);
  if (chassis3d) chassis3d.setLcdText(t);
}

function feedMidiToPanel(s, d1, d2) {
  frontPanel.noteActivity(s, d1, d2);
  if ((s & 0xf0) === 0xc0) {
    const ch = s & 0x0f;
    for (let p = 0; p < 8; p++) {
      const mapCh = frontPanel.midiMapAlt ? p : p + 1;
      if (mapCh === ch) {
        frontPanel.showProgramChange(p, frontPanel._groupName7(p), frontPanel._timbreName10(p));
        break;
      }
    }
  }
}

function syncChassisButtonsFromPanel() {
  try {
    if (!chassis3d || typeof chassis3d.syncHeldButtons !== 'function') return;
    const ids =
      typeof frontPanel.visualHeldIds === 'function'
        ? frontPanel.visualHeldIds()
        : new Set(frontPanel.held);
    chassis3d.syncHeldButtons(ids);
  } catch (err) {
    console.warn('[chassis3d] syncHeldButtons failed:', err && err.message ? err.message : err);
  }
}

function updateLeds(engine) {
  const ready = document.getElementById('led-ready');
  const midiLed = document.getElementById('led-midi');
  ensureLcd2d();
  frontPanel.tick();
  syncChassisButtonsFromPanel();
  if (!engine) {
    if (ready) ready.classList.remove('on');
    if (midiLed) midiLed.classList.remove('on');
    if (chassis3d && typeof chassis3d.setMidiLed === 'function') chassis3d.setMidiLed(false);
    _lastMidiLed = false;
    const panelLcd = frontPanel.getPanelLcdText();
    if (panelLcd != null) setLcdTextBoth(panelLcd);
    return;
  }
  const st = engine.getDisplayState ? engine.getDisplayState() : null;
  if (ready) ready.classList.toggle('on', !!(st && st.ledReady));
  if (st && st.text != null) {
    const engText = String(st.text);
    const trimmed = engText.trim();
    if (trimmed && !/^(TSF|MUNT)\b/i.test(trimmed)) {
      frontPanel.setEngineMainText(engText);
    }
  }
  const panelLcd = frontPanel.getPanelLcdText();
  if (panelLcd != null) setLcdTextBoth(panelLcd);
  const on = !!(st && st.ledMidi);
  if (midiLed) midiLed.classList.toggle('on', on);
  if (on !== _lastMidiLed) {
    _lastMidiLed = on;
    if (chassis3d && typeof chassis3d.setMidiLed === 'function') {
      chassis3d.setMidiLed(on);
    }
  }
}

function startLcdPoll() {
  if (_lcdPollTimer != null) return;
  _lcdPollTimer = setInterval(() => {
    frontPanel.tick();
    syncChassisButtonsFromPanel();
    if (activeEngine) updateLeds(activeEngine);
    else {
      const panelLcd = frontPanel.getPanelLcdText();
      if (panelLcd != null) setLcdTextBoth(panelLcd);
    }
  }, 80);
}

async function ensureEngine(id, statusEl) {
  if (activeEngine && activeEngine.id === id && engineReady) {
    return activeEngine;
  }

  if (activeEngine) {
    try {
      await activeEngine.dispose();
    } catch (_) {}
    activeEngine = null;
    engineReady = false;
  }

  const engine = createEngine(id);
  await engine.init();
  const ctx = getContext();
  transport.setAudioContext(ctx);
  await engine.connect(ctx, getMasterGain());
  if (typeof engine.ensureConnected === 'function') {
    await engine.ensureConnected();
  }

  activeEngine = engine;
  transport.setEngine(engine);
  engineReady = true;
  startLcdPoll();

  if (window.__debug) {
    window.__debug.activeEngine = engine;
    window.__debug.audioMode = engine.audioMode;
  }

  const extra =
    id === 'munt' && engine.libraryVersion
      ? ` v${engine.libraryVersion}`
      : id === 'tsf' && engine.sf2Loaded
        ? ' SF2'
        : '';
  await setStatus(statusEl, `${id} ready (${engine.audioMode || 'n/a'}${extra})`);
  updateLeds(engine);
  return engine;
}

async function ensureMuntEngine(statusEl) {
  return ensureEngine('munt', statusEl);
}

async function ensureTsfEngine(statusEl) {
  return ensureEngine('tsf', statusEl);
}

async function tryLoadStoredRoms(statusEl) {
  const stored = await getStoredRoms();
  if (!stored.control || !stored.pcm) {
    return false;
  }
  try {
    const engine = await ensureMuntEngine(statusEl);
    await engine.loadRoms({
      control: stored.control.data,
      pcm: stored.pcm.data,
    });
    frontPanel.setFirmwareFromControlRom(stored.control.data);
    await setStatus(statusEl, 'ROMs loaded into munt');
    updateLeds(engine);
    return true;
  } catch (err) {
    await setStatus(statusEl, 'ROM load: ' + err.message);
    return false;
  }
}

async function onRomsChanged(statusEl) {
  const stored = await getStoredRoms();
  if (!stored.control || !stored.pcm) {
    if (activeEngine && activeEngine.id === 'munt') {
      activeEngine._romsLoaded = false;
    }
    updateLeds(activeEngine);
    return;
  }
  try {
    const engine = await ensureMuntEngine(statusEl);
    await engine.loadRoms({
      control: stored.control.data,
      pcm: stored.pcm.data,
    });
    frontPanel.setFirmwareFromControlRom(stored.control.data);
    await setStatus(statusEl, 'ROMs loaded into munt');
    updateLeds(engine);
  } catch (err) {
    await setStatus(statusEl, 'ROM load: ' + err.message);
  }
}

async function onSf2Changed(statusEl) {
  const stored = await getStoredRoms();
  if (!stored.sf2 || !stored.sf2.data) {
    if (activeEngine && activeEngine.id === 'tsf') {
      activeEngine._sf2Loaded = false;
    }
    updateLeds(activeEngine);
    return;
  }
  const sizeCheck = validateSf2Size(stored.sf2.size || stored.sf2.data.byteLength || 0);
  try {
    const engine = await ensureTsfEngine(statusEl);
    await engine.loadSf2(stored.sf2.data);
    let msg = `SF2 loaded into tsf (${engine.audioMode})`;
    if (sizeCheck.warn) {
      msg += ' — Warning: file exceeds 32 MB';
    }
    await setStatus(statusEl, msg);
    updateLeds(engine);
  } catch (err) {
    await setStatus(statusEl, 'SF2 load: ' + err.message);
  }
}

if (window.location.search.includes('debug=1')) {
  window.__debug = {
    parseSmf,
    transport,
    ENGINE_IDS,
    createEngine,
    validateSf2Size,
    resumeContext,
    getContext,
    getMasterGain,
    getStoredRoms,
    clearRoms,
    /** Load MT-32 ROMs from ArrayBuffers directly (bypasses file input) */
    async loadRomsFromBuffers(controlAb, pcmAb) {
      const statusEl = document.getElementById('status');
      const engine = await ensureMuntEngine(statusEl);
      await engine.loadRoms({ control: controlAb, pcm: pcmAb });
      frontPanel.setFirmwareFromControlRom(controlAb);
      if (statusEl) {
        const n = controlAb && (controlAb.byteLength || controlAb.length) || 0;
        statusEl.textContent =
          n >= 120000
            ? `ROMs loaded (debug) control~128K (2.x-class)`
            : `ROMs loaded (debug) control~${n || '?'}B`;
      }
      updateLeds(engine);
      return true;
    },
    setDisplayCompatibility(oldMt32Compatible) {
      if (!activeEngine || typeof activeEngine.setDisplayCompatibility !== 'function') {
        return false;
      }
      if (oldMt32Compatible === 'auto' || oldMt32Compatible == null) {
        return activeEngine.setDisplayCompatibility('auto');
      }
      return activeEngine.setDisplayCompatibility(!!oldMt32Compatible);
    },
    isDisplayOldMT32Compatible() {
      if (!activeEngine || typeof activeEngine.isDisplayOldMT32Compatible !== 'function') {
        return null;
      }
      return activeEngine.isDisplayOldMT32Compatible();
    },
    isDefaultDisplayOldMT32Compatible() {
      if (
        !activeEngine ||
        typeof activeEngine.isDefaultDisplayOldMT32Compatible !== 'function'
      ) {
        return null;
      }
      return activeEngine.isDefaultDisplayOldMT32Compatible();
    },
    async loadSf2FromBuffer(sf2Ab) {
      const statusEl = document.getElementById('status');
      const engine = await ensureTsfEngine(statusEl);
      await engine.loadSf2(sf2Ab);
      if (statusEl) statusEl.textContent = 'SF2 loaded (debug)';
      updateLeds(engine);
      return true;
    },
    ensureTsfEngine: () => ensureTsfEngine(document.getElementById('status')),
    ensureMuntEngine: () => ensureMuntEngine(document.getElementById('status')),
    get engine() {
      return activeEngine;
    },
    get peakLevel() {
      if (activeEngine && activeEngine.peakLevel != null) return activeEngine.peakLevel;
      return window.__debug && window.__debug._peakLevel != null ? window.__debug._peakLevel : 0;
    },
    get _peakLevel() {
      return this.__peakLevel || 0;
    },
    set _peakLevel(v) {
      this.__peakLevel = v;
    },
  };
  setupDebugMidi();
}

document.addEventListener('DOMContentLoaded', async () => {
  const volumeSlider = document.getElementById('volume');
  wireDisplayToggles(volumeSlider);
  if (getDisplayPrefs().show2d) ensureLcd2d();
  wireVolumeSlider();
  wirePanelKeyboard();
  if (getDisplayPrefs().show3d) {
    await setupChassis3D(volumeSlider);
  }

  const status = document.getElementById('status');
  const playBtn = document.getElementById('play');
  const pauseBtn = document.getElementById('pause');
  const stopBtn = document.getElementById('stop');
  const midFile = document.getElementById('mid-file');
  const clearBtn = document.getElementById('btn-clear-roms');
  const romZone = document.getElementById('rom-drop');
  const sf2Zone = document.getElementById('sf2-drop');
  const engineSelect = document.getElementById('engine-select');

  transport.onStateChange = (state) => {
    if (playBtn) playBtn.disabled = state === 'playing';
    if (pauseBtn) pauseBtn.disabled = state !== 'playing';
    if (stopBtn) stopBtn.disabled = state === 'stopped';
    if (engineSelect) engineSelect.disabled = state === 'playing';
    if (window.__debug) window.__debug.transportState = state;
  };
  transport.onStateChange(transport.state);

  if (romZone && status) {
    setupRomDrop(romZone, status, () => onRomsChanged(status));
  }
  if (sf2Zone && status) {
    setupSf2Drop(sf2Zone, status, () => onSf2Changed(status));
  }

  await tryLoadStoredRoms(status).catch(() => {});

  // Auto-default engine select based on stored assets
  const _stored = await getStoredRoms();
  if (_stored.control && _stored.pcm) {
    engineSelect.value = 'munt';
  } else if (_stored.sf2 && _stored.sf2.data) {
    engineSelect.value = 'tsf';
    if (!activeEngine || activeEngine.id !== 'tsf') {
      if (activeEngine) {
        try { await activeEngine.dispose(); } catch (_) {}
        activeEngine = null;
        engineReady = false;
      }
      await ensureEngine('tsf', status).catch(() => {});
    }
  }

  // Engine select change: block while playing, else switch
  let _prevEngineId = engineSelect.value;
  engineSelect.addEventListener('change', async () => {
    const newId = engineSelect.value;
    if (transport.state === 'playing') {
      engineSelect.value = _prevEngineId;
      if (status) status.textContent = 'Cannot switch engine while playing — stop first';
      return;
    }
    try {
      await ensureEngine(newId, status);
      _prevEngineId = newId;
    } catch (err) {
      if (status) status.textContent = 'Engine switch: ' + err.message;
      engineSelect.value = _prevEngineId;
    }
  });

  const midiInputSelect = document.getElementById('midi-input-select');

  function populateMidiInputSelect(inputs, selectedId) {
    if (!midiInputSelect) return;

    let desired = selectedId || getSelectedMidiInputId();
    const known = new Set(inputs.map((i) => i.id));
    if (desired !== MIDI_INPUT_ALL && desired !== MIDI_INPUT_NONE && !known.has(desired)) {
      desired = MIDI_INPUT_ALL;
      setSelectedMidiInputId(desired);
    }

    const prevFocus = document.activeElement === midiInputSelect;
    midiInputSelect.replaceChildren();

    const optAll = document.createElement('option');
    optAll.value = MIDI_INPUT_ALL;
    optAll.textContent = inputs.length ? `All devices (${inputs.length})` : 'All devices';
    midiInputSelect.appendChild(optAll);

    const optNone = document.createElement('option');
    optNone.value = MIDI_INPUT_NONE;
    optNone.textContent = 'None';
    midiInputSelect.appendChild(optNone);

    for (const input of inputs) {
      const opt = document.createElement('option');
      opt.value = input.id;
      const mfg = input.manufacturer ? ` — ${input.manufacturer}` : '';
      opt.textContent = `${input.name}${mfg}`;
      midiInputSelect.appendChild(opt);
    }

    midiInputSelect.value = desired;
    if (![...midiInputSelect.options].some((o) => o.value === desired)) {
      midiInputSelect.value = MIDI_INPUT_ALL;
    }

    if (!isWebMidiAvailable()) {
      midiInputSelect.disabled = true;
      midiInputSelect.title = 'Web MIDI API not available in this browser';
    } else if (!hasMidiAccess()) {
      midiInputSelect.disabled = false;
      midiInputSelect.title = 'MIDI access denied or pending — grant permission and reload if empty';
    } else {
      midiInputSelect.disabled = false;
      midiInputSelect.title = 'Select which MIDI input feeds the synth';
    }

    if (prevFocus) midiInputSelect.focus();
  }

  setMidiInputsChangedHandler(populateMidiInputSelect);

  if (midiInputSelect) {
    midiInputSelect.addEventListener('change', () => {
      setSelectedMidiInputId(midiInputSelect.value);
      if (status) {
        const label = midiInputSelect.selectedOptions[0]
          ? midiInputSelect.selectedOptions[0].textContent
          : midiInputSelect.value;
        status.textContent = `MIDI input: ${label}`;
      }
    });
  }

  requestWebMidi((s, d1, d2, bytes) => {
    const u8 =
      bytes instanceof Uint8Array
        ? bytes
        : bytes
          ? new Uint8Array(bytes)
          : null;
    if (u8 && u8.length && (u8[0] & 0xff) === 0xf0) {
      if (activeEngine && typeof activeEngine.playSysex === 'function') {
        activeEngine.playSysex(u8);
      }
      return;
    }
    feedMidiToPanel(s, d1, d2);
    if (activeEngine && typeof activeEngine.playMsg === 'function') {
      activeEngine.playMsg(s, d1, d2);
    }
  });

  transport.onEvent = (ev) => {
    if (!ev) return;
    if (ev.status != null) {
      feedMidiToPanel(ev.status, ev.data1 | 0, ev.data2 | 0);
    }
  };

  if (clearBtn) {
    clearBtn.addEventListener('click', async () => {
      await clearRoms();
      if (activeEngine && activeEngine.id === 'munt') {
        activeEngine._romsLoaded = false;
      }
      if (status) status.textContent = 'ROMs cleared';
      updateLeds(activeEngine);
    });
  }

  if (playBtn) {
    playBtn.addEventListener('click', async () => {
      await resumeContext();
      try {
        const id = (engineSelect && engineSelect.value) || 'munt';
        const stored = await getStoredRoms();

        if (id === 'munt') {
          if (!stored.control || !stored.pcm) {
            if (status) {
              status.textContent =
                'Error: munt requires control + PCM ROMs (drop MT32_CONTROL.ROM and MT32_PCM.ROM)';
            }
            return;
          }
          const engine = await ensureMuntEngine(status);
          if (!engine.romsLoaded) {
            await engine.loadRoms({
              control: stored.control.data,
              pcm: stored.pcm.data,
            });
            frontPanel.setFirmwareFromControlRom(stored.control.data);
          } else if (stored.control && stored.control.data) {
            frontPanel.setFirmwareFromControlRom(stored.control.data);
          }
          if (!engine.romsLoaded) {
            if (status) {
              status.textContent = 'Error: ' + (engine.lastError || 'ROMs not loaded');
            }
            return;
          }
          transport.setEngine(engine);
          transport.setAudioContext(getContext());
          transport.play();
          if (status) status.textContent = `Playing munt (${engine.audioMode})`;
          updateLeds(engine);
          return;
        }

        if (id === 'tsf') {
          if (!stored.sf2 || !stored.sf2.data) {
            if (status) {
              status.textContent =
                'Error: tsf requires a SoundFont (.sf2) — drop an SF2 file on the SF2 zone';
            }
            return;
          }
          const engine = await ensureTsfEngine(status);
          if (!engine.sf2Loaded) {
            await engine.loadSf2(stored.sf2.data);
          }
          if (!engine.sf2Loaded) {
            if (status) {
              status.textContent = 'Error: ' + (engine.lastError || 'SF2 not loaded');
            }
            return;
          }
          transport.setEngine(engine);
          transport.setAudioContext(getContext());
          transport.play();
          if (status) status.textContent = `Playing tsf (${engine.audioMode})`;
          updateLeds(engine);
          return;
        }

        if (status) status.textContent = `Engine "${id}" not implemented yet`;
      } catch (err) {
        if (status) status.textContent = 'Play: ' + err.message;
      }
    });
  }

  if (pauseBtn) {
    pauseBtn.addEventListener('click', () => transport.pause());
  }
  if (stopBtn) {
    stopBtn.addEventListener('click', () => transport.stop());
  }

  async function loadMidiFromUrl(url, label) {
    try {
      if (transport.state === 'playing' || transport.state === 'paused') {
        transport.stop();
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
      const buf = await res.arrayBuffer();
      const song = parseSmf(buf);
      transport.load(song);
      if (status) {
        status.textContent = `Loaded: ${label || url} (${song.events.length} events)`;
      }
      if (window.__debug) {
        window.__debug.lastMidiFile = label || url;
        window.__debug.lastSong = song;
      }
      return song;
    } catch (err) {
      if (status) status.textContent = 'MIDI error: ' + err.message;
      throw err;
    }
  }

  async function loadMidiFile(file) {
    if (!file) return;
    const name = (file.name || '').toLowerCase();
    if (name && !name.endsWith('.mid') && !name.endsWith('.midi')) {
      if (status) status.textContent = `Invalid: "${file.name}" is not a MIDI file`;
      return;
    }
    try {
      if (transport.state === 'playing' || transport.state === 'paused') {
        transport.stop();
      }
      const buf = await file.arrayBuffer();
      const song = parseSmf(buf);
      transport.load(song);
      if (status) status.textContent = `Loaded: ${file.name} (${song.events.length} events)`;
      if (window.__debug) {
        window.__debug.lastMidiFile = file.name;
        window.__debug.lastSong = song;
      }
    } catch (err) {
      if (status) status.textContent = 'MIDI error: ' + err.message;
    }
  }

  const midDrop = document.getElementById('mid-drop');
  if (midFile) {
    midFile.addEventListener('change', async () => {
      const file = midFile.files && midFile.files[0];
      await loadMidiFile(file);
      midFile.value = '';
    });
  }
  if (midDrop && midFile) {
    midDrop.addEventListener('dragover', (e) => {
      e.preventDefault();
      midDrop.classList.add('drag-over');
    });
    midDrop.addEventListener('dragleave', () => {
      midDrop.classList.remove('drag-over');
    });
    midDrop.addEventListener('drop', async (e) => {
      e.preventDefault();
      midDrop.classList.remove('drag-over');
      const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
      await loadMidiFile(file);
    });
  }

});
