let _ctx = null;
let _masterGain = null;
let _debug = false;

function checkDebug() {
  if (_debug === false) {
    _debug = window.location.search.includes('debug=1');
  }
}

export function getContext() {
  if (!_ctx) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) {
      throw new Error('[mt32-web] AudioContext not supported in this browser');
    }
    _ctx = new AudioCtx({ sampleRate: 44100 });
    _masterGain = _ctx.createGain();
    _masterGain.gain.value = 1;
    _masterGain.connect(_ctx.destination);

    checkDebug();
    if (_debug) {
      window.__debug = window.__debug || {};
      window.__debug.audioState = _ctx.state;
      _ctx.addEventListener('statechange', () => {
        window.__debug.audioState = _ctx.state;
      });
    }
  }
  return _ctx;
}

export async function resumeContext() {
  const ctx = getContext();
  if (ctx.state === 'running') return true;
  await ctx.resume();
  const running = ctx.state === 'running';
  if (_debug) {
    window.__debug.audioState = ctx.state;
  }
  return running;
}

export function getMasterGain() {
  if (!_masterGain) getContext();
  return _masterGain;
}

export function setMasterVolume(value) {
  const gain = getMasterGain();
  const clamped = Math.max(0, Math.min(1, value));
  gain.gain.setValueAtTime(clamped, _ctx.currentTime);
}

export function wireVolumeSlider() {
  const slider = document.getElementById('volume');
  if (!slider) {
    console.warn('[mt32-web] #volume element not found');
    return;
  }
  const update = () => setMasterVolume(parseFloat(slider.value));
  slider.addEventListener('input', update);
  update();
}

export async function disposeAudio() {
  if (_ctx) {
    await _ctx.close();
    _ctx = null;
    _masterGain = null;
  }
}

export function syncDebugState() {
  if (!_debug) checkDebug();
  if (_debug && _ctx) {
    window.__debug = window.__debug || {};
    window.__debug.audioState = _ctx.state;
  }
}
