import {
  Group,
  Mesh,
  MeshStandardMaterial,
  MeshPhysicalMaterial,
  PlaneGeometry,
  BoxGeometry,
  CanvasTexture,
  LinearMipmapLinearFilter,
  SRGBColorSpace,
} from 'three/webgpu';
import { PANEL, panelTransform, DIMS } from './layout.js';
import { LcdDisplay } from './lcd.js';

/* Silkscreen texture resolution: pixels per millimeter (higher = sharper, more VRAM usage) */
const TEX_SCALE = 13;

/* Font families (note.md spec; CDN loaded in index.html, main3d.js handles preloading)
 *   FONT_STACK   = Helvetica —— regular labels (PART / numbers / SOUND GROUP etc.)
 *   FONT_LOGO    = Univers 53 Extended —— "Roland" logo
 *   FONT_DISPLAY = Clonoid W01 Semibold (Earth/RBIO replica) —— MT-32 / MULTI TIMBRE / SOUND MODULE */
const FONT_STACK = '"Univers N W02 340 Xtd Lt", "Helvetica", "Helvetica Neue", Arial, "Liberation Sans", sans-serif';
const FONT_LOGO = '"Univers 53 Extended Regular", ' + FONT_STACK;
const FONT_DISPLAY = '"Clonoid W01 Semibold", ' + FONT_STACK;

function maxAnisotropy(renderer) {
  const caps = renderer && renderer.capabilities;
  if (caps && typeof caps.getMaxAnisotropy === 'function') return caps.getMaxAnisotropy();
  return 8;
}

/* Silkscreen colors: primary text / secondary text / blue labels (SOUND GROUP, SOUND, VOLUME) */
const COLOR_TEXT = '#d8d8d8';
const COLOR_TEXT_DIM = '#b9b9b9';
const COLOR_BLUE = '#7fa8d8';

function px(mm) {
  return mm * TEX_SCALE;
}

export function buildPanel(renderer, dims = DIMS) {
  const group = new Group();
  const tf = panelTransform(dims);
  group.position.set(...tf.position);
  group.rotation.x = tf.rotationX;
  group.name = 'front-panel';

  const labelTex = buildLabelTexture(renderer);
  const labelPlane = new Mesh(
    new PlaneGeometry(PANEL.w, PANEL.h),
    new MeshStandardMaterial({
      map: labelTex,
      transparent: true,
      roughness: 0.5,
      metalness: 0.25,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    }),
  );
  labelPlane.position.z = 1.35;
  labelPlane.receiveShadow = true;
  group.add(labelPlane);

  const display = buildDisplayGlass(renderer);
  display.group.position.set(PANEL.displayGlass.cx, PANEL.displayGlass.cy, 0.55);
  group.add(display.group);

  return { group, lcd: display.lcd, ledMat: display.ledMat };
}

function buildDisplayGlass(renderer) {
  const g = new Group();
  g.name = 'display-glass';

  const plate = new Mesh(
    new BoxGeometry(PANEL.displayGlass.w, PANEL.displayGlass.h, 1.8),
    new MeshPhysicalMaterial({
      color: 0x0a0b0d,
      roughness: 0.18,
      metalness: 0.55,
      clearcoat: 0.85,
      clearcoatRoughness: 0.12,
      reflectivity: 0.5,
    }),
  );
  plate.position.z = 0.9;
  plate.castShadow = true;
  plate.receiveShadow = true;
  g.add(plate);

  const rim = new Mesh(
    new BoxGeometry(PANEL.displayGlass.w + 1.2, PANEL.displayGlass.h + 1.2, 0.7),
    new MeshStandardMaterial({ color: 0x141516, roughness: 0.45, metalness: 0.4 }),
  );
  rim.position.z = 0.25;
  g.add(rim);

  const glassLabel = new Mesh(
    new PlaneGeometry(PANEL.displayGlass.w, PANEL.displayGlass.h),
    new MeshStandardMaterial({
      map: buildGlassLabelTexture(renderer),
      transparent: true,
      roughness: 0.3,
      metalness: 0.2,
      polygonOffset: true,
      polygonOffsetFactor: -2,
    }),
  );
  glassLabel.position.z = 1.86;
  g.add(glassLabel);

  const lcd = new LcdDisplay(PANEL.lcd.glassW, PANEL.lcd.glassH);
  const lcdTex = new CanvasTexture(lcd.canvas);
  lcdTex.anisotropy = maxAnisotropy(renderer);
  lcdTex.colorSpace = SRGBColorSpace;
  lcd.texture = lcdTex;

  const localLcdX = PANEL.lcd.cx - PANEL.displayGlass.cx;
  const localLcdY = PANEL.lcd.cy - PANEL.displayGlass.cy;

  const bezel = new Mesh(
    new BoxGeometry(PANEL.lcd.bezelW, PANEL.lcd.bezelH, 1.4),
    new MeshStandardMaterial({ color: 0x050505, roughness: 0.4, metalness: 0.3 }),
  );
  bezel.position.set(localLcdX, localLcdY, 1.9);
  g.add(bezel);

  const glassMat = new MeshStandardMaterial({
    color: 0x000000,
    emissive: 0xffffff,
    emissiveMap: lcdTex,
    emissiveIntensity: 0.95,
    roughness: 0.22,
    metalness: 0.05,
  });
  const glass = new Mesh(new PlaneGeometry(PANEL.lcd.glassW, PANEL.lcd.glassH), glassMat);
  glass.position.set(localLcdX, localLcdY, 2.75);
  g.add(glass);

  const ledMat = new MeshStandardMaterial({
    color: 0x04180a,
    emissive: 0x38e05c,
    emissiveIntensity: 0.06,
    roughness: 0.35,
    metalness: 0.1,
  });
  const led = new Mesh(new BoxGeometry(PANEL.midiLed.w, PANEL.midiLed.h, 0.7), ledMat);
  led.name = 'led-midi-3d';
  led.position.set(
    PANEL.midiLed.cx - PANEL.displayGlass.cx,
    PANEL.midiLed.cy - PANEL.displayGlass.cy,
    1.95,
  );
  g.add(led);

  return { group: g, lcd, ledMat };
}

function buildGlassLabelTexture(renderer) {
  const gw = PANEL.displayGlass.w;
  const gh = PANEL.displayGlass.h;
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(px(gw));
  canvas.height = Math.round(px(gh));
  const ctx = canvas.getContext('2d');
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;
  const ox = PANEL.displayGlass.cx;
  const oy = PANEL.displayGlass.cy;

  const text = (str, xmm, ymm, sizeMm, opts = {}) => {
    ctx.save();
    ctx.font = `${opts.weight || 600} ${px(sizeMm)}px ${opts.family || FONT_STACK}`;
    ctx.fillStyle = opts.color || COLOR_TEXT;
    ctx.textAlign = opts.align || 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(str, cx + px(xmm - ox), cy - px(ymm - oy));
    ctx.restore();
  };

  /* ---- Text on the glass panel (coordinates = panel mm coordinates, converted to glass-local inside the function) ---- */
  drawThickText(ctx, 'Roland', cx + px(-126 - ox), cy - px(14 - oy), 6.0, FONT_LOGO);
  text('MULTI TIMBRE', -102, 15.3, 3, { family: FONT_DISPLAY, weight: 300, color: COLOR_TEXT_DIM, align: 'left' });
  text('SOUND MODULE', -102, 13.0, 3, { family: FONT_DISPLAY, weight: 300, color: COLOR_TEXT_DIM, align: 'left' });
  text('MT-32', -58, 14.1, 6, { family: FONT_DISPLAY, weight: 400, align: 'left' });
  text('MIDI MESSAGE', PANEL.midiLabel.cx, PANEL.midiLabel.cy, 1.8, { weight: 600, color: COLOR_TEXT_DIM });

  const tex = new CanvasTexture(canvas);
  tex.anisotropy = maxAnisotropy(renderer);
  tex.minFilter = LinearMipmapLinearFilter;
  tex.colorSpace = SRGBColorSpace;
  return tex;
}

function drawThickText(ctx, str, x, y, sizeMm, family) {
  ctx.save();
  ctx.font = `700 ${px(sizeMm)}px ${family}`;
  ctx.letterSpacing = '-3.5px';
  ctx.fillStyle = COLOR_TEXT;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  const offsets = [
    [0, 0],
    [0.45, 0],
    [-0.45, 0],
    [0, 0.35],
    [0, -0.35],
    [0.3, 0.25],
    [-0.3, 0.25],
  ];
  for (const [dx, dy] of offsets) {
    ctx.fillText(str, x + dx, y + dy);
  }
  ctx.restore();
}

function buildLabelTexture(renderer) {
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(px(PANEL.w));
  canvas.height = Math.round(px(PANEL.h));
  const ctx = canvas.getContext('2d');
  const cx = canvas.width / 2;
  const cy = canvas.height / 2;

  const text = (str, xmm, ymm, sizeMm, opts = {}) => {
    ctx.save();
    ctx.font = `${opts.italic ? 'italic ' : ''}${opts.weight || 600} ${px(sizeMm)}px ${opts.family || FONT_STACK}`;
    ctx.fillStyle = opts.color || COLOR_TEXT;
    ctx.textAlign = opts.align || 'center';
    ctx.textBaseline = 'middle';
    if (opts.letterSpacing != null && 'letterSpacing' in ctx) {
      ctx.letterSpacing = `${px(opts.letterSpacing)}px`;
    }
    ctx.fillText(str, cx + px(xmm), cy - px(ymm));
    ctx.restore();
  };

  /* ---- PART title + horizontal lines on both sides (all coordinates are panel mm) ---- */
  text('PART', 18, 15.6, 2.8, { weight: 700 });
  ctx.save();
  ctx.strokeStyle = COLOR_TEXT;
  ctx.lineWidth = px(0.45);
  for (const [x0, x1] of [[-5, 11.6], [24.2, 37.8]]) {
    ctx.beginPath();
    ctx.moveTo(cx + px(x0), cy - px(15.6));
    ctx.lineTo(cx + px(x1), cy - px(15.6));
    ctx.stroke();
  }
  ctx.restore();

  /* ---- Button number labels ---- */
  const partLabels = [['1', '2', '3'], ['4', '5', 'RHYTHM']];
  for (let r = 0; r < 2; r++) {
    for (let c = 0; c < 3; c++) {
      const lab = partLabels[r][c];
      text(lab, PANEL.part.cols[c], PANEL.part.rows[r] - 6.5, 2 , { weight: 700 });
    }
  }

  /* ---- Blue column labels (top-row titles at y=15.6, middle-row small text at y=-0.6) ---- */
  text('SOUND GROUP', 57.1, 15.6, 2, { weight: 700, color: COLOR_BLUE, letterSpacing: -0.1 });
  text('SOUND', 57.1, 1.4, 2, { weight: 700, color: COLOR_BLUE, letterSpacing: -0.1 });
  text('VOLUME', 82.9, 15.6, 2, { weight: 700, color: COLOR_BLUE, letterSpacing: -0.1 });
  text('MASTER VOLUME', 82.9, 1.4, 2, { weight: 700, letterSpacing: -0.1 });

  text('SELECT/VOLUME', 123.2, 16.4, 2.4, { weight: 700 });

  const knob = PANEL.knob;
  ctx.save();
  ctx.fillStyle = COLOR_TEXT_DIM;
  const tickR = knob.skirtR + 2.5;
  for (let i = 0; i <= 20; i++) {
    const a = ((225 - i * 13.5) * Math.PI) / 180;
    const tx = cx + px(knob.cx + tickR * Math.cos(a));
    const ty = cy - px(knob.cy + tickR * Math.sin(a));
    ctx.beginPath();
    ctx.arc(tx, ty, px(0.55), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  const tex = new CanvasTexture(canvas);
  tex.anisotropy = maxAnisotropy(renderer);
  tex.minFilter = LinearMipmapLinearFilter;
  tex.colorSpace = SRGBColorSpace;
  return tex;
}
