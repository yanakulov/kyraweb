/**
 * ============================================================================
 * MT-32 chassis 3D layout tuning center
 * ============================================================================
 *
 * [Units] All values are in millimeters (mm) — 1:1 real-device dimensions;
 * the real unit is 305 wide × 220 deep × 45 high.
 *
 * [Coordinate systems]
 *   - World coordinates: X = width (right+), Y = height (up+), Z = depth
 *     (front+, panel faces +Z).
 *   - Panel-local coordinates (all cx/cy inside PANEL): origin at the panel
 *     center, x ∈ [-152.5, +152.5] (left negative, right positive),
 *     y ∈ [-22.5, +22.5] (down negative, up positive).
 *   - All controls hang under the same tilted panel Group; you only supply
 *     planar coordinates (cx, cy), the tilt is applied uniformly by
 *     panelTransform(), so controls automatically stay coplanar with the slope.
 *
 * [How to adjust]
 *   - Move: change cx / cy of the corresponding component in PANEL (mm, using
 *     the coordinate systems above).
 *   - Resize: change fields such as w / h / r.
 *   - Text position: silkscreen text coordinates live in buildLabelTexture() /
 *     buildGlassLabelTexture() in panel.js (also panel mm coordinates).
 *   - Value source: most are converted from pixel measurements of real-device
 *     photos / reference renders (4.95 px/mm); the glass panel coordinates
 *     come directly from the mt32glass primitive of the GLTF model.
 * ============================================================================
 */

export const DIMS = {
  /* ---- Overall chassis dimensions ---- */
  width: 305,        // Body width (excluding side ears)
  depth: 220,        // Body depth (bottom edge)
  height: 45,        // Body height (excluding feet)

  /* ---- Rubber feet ---- */
  footHeight: 6,     // Foot height (real total height 51 = 45 + 6)
  footRadius: 8,     // Foot radius

  /* ---- Wedge side profile (pentagon, calibrated from GLTF side-view pixel measurements) ---- */
  panelTiltDeg: 15.3, // Rearward tilt of the front panel main slope (from vertical, degrees)
  noseHeight: 6.4,    // "Nose point" height: height of the front panel's most protruding point above the bottom edge
  noseChamfer: 9,     // Bottom edge inward inset: horizontal distance from the nose point to the bottom front edge
};

export const PANEL = {
  w: DIMS.width,   // Panel width (= body width)
  h: DIMS.height,  // Panel height (= body height)

  /* ---- Full glass panel on the left (Roland / two small text lines / MT-32 / LCD / MIDI LED all sit on it) ----
   * Coordinates taken from the mt32glass primitive of the GLTF: width 111, height 31, center (-78.3, +7) */
  displayGlass: { cx: -78.3, cy: 7.6, w: 111, h: 32.2 },

  /* ---- LCD display window (20 chars × 1 row, 5×7 dot matrix) ----
   * cx/cy = window center; glassW/glassH = yellow-green glass size; bezel = black window frame size */
  lcd: { cx: -88, cy: 3, glassW: 74, glassH: 8, bezelW: 79, bezelH: 10.4 },

  /* ---- MIDI MESSAGE indicator LED (small green light on the right of the glass panel) ---- */
  midiLed: { cx: -39, cy: 3, w: 2.5, h: 1 },
  midiLabel: { cx: -39, cy: 6 },   // "MIDI MESSAGE" text position (directly above the LED)

  /* ---- PART button group (6 square buttons: 1 2 3 / 4 5 RHYTHM) ----
   * cols = x of the three columns; rows = y of the two rows; size = button side length */
  part: {
    cols: [1.6, 17.4, 32.9],
    rows: [9.5, -4.1],
    size: 8,
    ids: [
      ['part1', 'part2', 'part3'],
      ['part4', 'part5', 'rhythm'],
    ],
  },

  /* ---- Wide buttons (SOUND GROUP / SOUND / VOLUME / MASTER VOLUME) ----
   * w/h = button size; items gives the center position of each of the four buttons (id is used for interaction callbacks) */
  wide: {
    w: 17,
    h: 7,
    items: [
      { id: 'sound-group', cx: 57.1, cy: 9.5 },
      { id: 'sound', cx: 57.1, cy: -4.1 },
      { id: 'volume', cx: 82.9, cy: 9.5 },
      { id: 'master-volume', cx: 82.9, cy: -4.1 },
    ],
  },

  /* ---- SELECT/VOLUME large knob ----
   * r = knob body radius; height = thickness; skirtR/skirtH = base disc at the bottom */
  knob: { cx: 124.8, cy: -0.2, r: 10, height: 6.5, skirtR: 12, skirtH: 1.3 },
};

/**
 * World z coordinate of the panel front edge (slope) at height y — piecewise profile:
 *   y >= noseHeight: main slope (recedes tan(tilt) for each 1mm rise)
 *   y <  noseHeight: bottom chamfer (bevel from nose point to bottom front edge)
 * Control layout usually doesn't need to care about this; to move controls, edit the PANEL constants above.
 */
export function panelFrontZ(y, dims = DIMS) {
  const tilt = (dims.panelTiltDeg * Math.PI) / 180;
  const half = dims.depth / 2;
  if (y >= dims.noseHeight) {
    return half - (y - dims.noseHeight) * Math.tan(tilt);
  }
  const t = (dims.noseHeight - y) / dims.noseHeight;
  return half - t * dims.noseChamfer;
}

/**
 * Panel Group transform: position (world coordinates of the panel center) + rearward tilt about the X axis.
 * All controls are its children, so they are naturally coplanar with the slope.
 */
export function panelTransform(dims = DIMS) {
  const tilt = (dims.panelTiltDeg * Math.PI) / 180;
  return {
    position: [0, dims.height / 2, panelFrontZ(dims.height / 2, dims)],
    rotationX: -tilt,
  };
}
