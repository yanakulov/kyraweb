import {
  Scene,
  PerspectiveCamera,
  WebGPURenderer,
  HemisphereLight,
  DirectionalLight,
  Mesh,
  MeshStandardMaterial,
  PlaneGeometry,
  ShadowMaterial,
  ACESFilmicToneMapping,
  PCFSoftShadowMap,
} from 'three/webgpu';
import { DIMS } from './layout.js';
import { buildChassis } from './chassis.js';
import { buildPanel } from './panel.js';
import { PanelControls } from './controls.js?v=btn-hold-2';

const BOOT_TEXT = ' ** Roland MT-32 ** ';
const MIDI_FLASH_MS = 100;                // MIDI indicator single flash duration (ms)

export async function initChassis3D(container, hooks = {}) {
  if (!container) throw new Error('[chassis3d] container element required');

  const canvas = document.createElement('canvas');
  canvas.id = 'chassis3d-canvas';
  container.appendChild(canvas);

  const forceWebGL =
    !!hooks.forceWebGL ||
    window.location.search.includes('webgl=1') ||
    (() => {
      try {
        return localStorage.getItem('mt32-web.forceWebGL') === '1';
      } catch (_) {
        return false;
      }
    })();
  const renderer = new WebGPURenderer({
    canvas,
    antialias: true,
    alpha: true,
    forceWebGL,
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = PCFSoftShadowMap;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  await renderer.init();

  const backend = renderer.backend && renderer.backend.isWebGPUBackend ? 'webgpu' : 'webgl2';
  console.info(`[chassis3d] renderer backend: ${backend}${forceWebGL ? ' (force WebGL)' : ''}`);

  const scene = new Scene();

  /* Camera: fov 33°, looking down at the panel from front-top (adjust framing here) */
  const camera = new PerspectiveCamera(33, 2, 1, 3000);
  camera.position.set(4, 88, 312);
  camera.lookAt(0, 16, 2);

  /* Lighting: hemisphere ambient + key light (shadows) + left fill + back rim light */
  const hemi = new HemisphereLight(0x9aa7b8, 0x1c1e22, 0.85);
  scene.add(hemi);

  const key = new DirectionalLight(0xfff1dd, 2.1);
  key.position.set(140, 190, 230);
  key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048);
  key.shadow.camera.left = -240;
  key.shadow.camera.right = 240;
  key.shadow.camera.top = 160;
  key.shadow.camera.bottom = -80;
  key.shadow.camera.near = 50;
  key.shadow.camera.far = 800;
  key.shadow.bias = -0.0006;
  scene.add(key);

  const fill = new DirectionalLight(0x8fa0c8, 0.75);
  fill.position.set(-180, 70, 140);
  scene.add(fill);

  const rim = new DirectionalLight(0xaaccee, 0.5);
  rim.position.set(-60, 120, -220);
  scene.add(rim);

  const chassis = buildChassis(DIMS);
  scene.add(chassis);

  try {
    await Promise.race([
      Promise.all([
        document.fonts.load('40px "Univers 53 Extended Regular"'),
        document.fonts.load('40px "Clonoid W01 Semibold"'),
        document.fonts.load('40px "Univers N W02 340 Xtd Lt"'),
      ]),
      new Promise((resolve) => setTimeout(resolve, 3000)),
    ]);
  } catch (_) {}

  const panel = buildPanel(renderer, DIMS);
  chassis.add(panel.group);

  const ground = new Mesh(
    new PlaneGeometry(1400, 1000),
    new ShadowMaterial({ opacity: 0.32 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -DIMS.footHeight - 0.4;
  ground.receiveShadow = true;
  scene.add(ground);

  const controls = new PanelControls(panel.group, hooks);
  if (typeof controls.syncHeldButtons !== 'function') {
    controls.syncHeldButtons = function syncHeldButtons() {};
  }
  if (typeof controls.setButtonPressed !== 'function') {
    controls.setButtonPressed = function setButtonPressed() {};
  }
  panel.lcd.setText(BOOT_TEXT);

  let ledOn = false;
  let ledTimer = 0;
  function setMidiLed(on) {
    ledOn = !!on;
    panel.ledMat.emissiveIntensity = ledOn ? 1.7 : 0.06;
  }
  function flashMidiLed() {
    setMidiLed(true);
    clearTimeout(ledTimer);
    ledTimer = setTimeout(() => setMidiLed(false), MIDI_FLASH_MS);
  }

  function resize() {
    const w = container.clientWidth;
    const h = container.clientHeight;
    if (w === 0 || h === 0) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(resize);
  ro.observe(container);
  resize();

  let orbit = null;
  let orbitWanted = false;

  async function setOrbitEnabled(on) {
    orbitWanted = !!on;
    if (orbitWanted) {
      if (!orbit) {
        const { OrbitControls } = await import('three/addons/controls/OrbitControls.js');
        orbit = new OrbitControls(camera, canvas);
        orbit.target.set(0, 12, 0);
        orbit.enableDamping = true;
        orbit.enablePan = false;
        orbit.minDistance = 120;
        orbit.maxDistance = 520;
        orbit.maxPolarAngle = Math.PI * 0.49;
        orbit.update();
        api.orbit = orbit;
      }
      orbit.enabled = true;
    } else if (orbit) {
      orbit.enabled = false;
    }
    return orbitWanted;
  }

  function getOrbitEnabled() {
    return !!(orbit && orbit.enabled && orbitWanted);
  }

  const api = {
    renderer,
    scene,
    camera,
    backend,
    setLcdText: (t) => panel.lcd.setText(t),
    setMidiLed,
    flashMidiLed,
    setVolume01: (v) => controls.setVolume01(v, true),
    getVolume01: () => controls.knobValue,
    setButtonPressed: (id, pressed) => {
      if (controls && typeof controls.setButtonPressed === 'function') {
        controls.setButtonPressed(id, pressed);
      }
    },
    syncHeldButtons: (ids) => {
      if (controls && typeof controls.syncHeldButtons === 'function') {
        controls.syncHeldButtons(ids);
      }
    },
    setOrbitEnabled,
    getOrbitEnabled,
    dispose: () => {
      ro.disconnect();
      renderer.setAnimationLoop(null);
      if (orbit) {
        orbit.dispose();
        orbit = null;
      }
      renderer.dispose();
      container.removeChild(canvas);
    },
  };

  canvas.addEventListener('pointerdown', (e) => {
    const used = controls.onPointerDown(e, camera);
    if (used) {
      e.preventDefault();
      if (orbit) orbit.enabled = false;
    }
  });
  canvas.addEventListener('pointermove', (e) => controls.onPointerMove(e, camera));
  const endPointer = (e) => {
    controls.onPointerUp(e);
    if (orbit) orbit.enabled = orbitWanted;
  };
  canvas.addEventListener('pointerup', endPointer);
  canvas.addEventListener('pointercancel', endPointer);
  canvas.addEventListener('lostpointercapture', endPointer);
  canvas.addEventListener('wheel', (e) => controls.onWheel(e, camera), { passive: false });
  window.addEventListener('blur', () => {
    if (typeof controls.releaseAll === 'function') controls.releaseAll();
  });

  let last = performance.now();
  renderer.setAnimationLoop((time) => {
    const dt = Math.min(64, time - last);
    last = time;
    controls.update(dt);
    if (orbit && orbitWanted) orbit.update();
    renderer.render(scene, camera);
  });

  return api;
}
