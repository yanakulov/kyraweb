import {
  ExtrudeGeometry,
  Shape,
  Mesh,
  MeshStandardMaterial,
  CylinderGeometry,
  Group,
} from 'three/webgpu';
import { DIMS } from './layout.js';

export function buildChassis(dims = DIMS) {
  const { width, depth, height, panelTiltDeg, footHeight, footRadius, noseHeight, noseChamfer } = dims;
  const tilt = (panelTiltDeg * Math.PI) / 180;
  const topFrontX = (height - noseHeight) * Math.tan(tilt);

  /* Wedge side profile (pentagon): x = depth (0 = front edge), y = height
   *  (noseChamfer,0) bottom front edge (inset) → (depth,0) bottom rear edge → (depth,height) top rear edge
   *  → (topFrontX,height) top front edge → (0,noseHeight) nose point (most protruding) → close (bottom chamfer) */
  const profile = new Shape();
  profile.moveTo(noseChamfer, 0);
  profile.lineTo(depth, 0);
  profile.lineTo(depth, height);
  profile.lineTo(topFrontX, height);
  profile.lineTo(0, noseHeight);
  profile.closePath();

  const geo = new ExtrudeGeometry(profile, {
    depth: width,
    bevelEnabled: true,
    bevelThickness: 1.2,
    bevelSize: 1.2,
    bevelSegments: 2,
    steps: 1,
  });
  geo.rotateY(Math.PI / 2);
  geo.translate(-width / 2, 0, depth / 2);

  const bodyMat = new MeshStandardMaterial({
    color: 0x191a1d,
    roughness: 0.58,
    metalness: 0.32,
  });
  const body = new Mesh(geo, bodyMat);
  body.castShadow = true;
  body.receiveShadow = true;
  body.name = 'chassis-body';

  const group = new Group();
  group.add(body);

  const footGeo = new CylinderGeometry(footRadius, footRadius * 0.92, footHeight, 24);
  const footMat = new MeshStandardMaterial({ color: 0x0c0c0d, roughness: 0.9, metalness: 0.05 });
  const fx = width / 2 - 26;
  const fz = depth / 2 - 30;
  for (const [sx, sz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const foot = new Mesh(footGeo, footMat);
    foot.position.set(sx * fx, -footHeight / 2 + 0.4, sz * fz);
    foot.castShadow = true;
    group.add(foot);
  }

  return group;
}
