import {
  Group,
  Mesh,
  MeshStandardMaterial,
  BoxGeometry,
  CylinderGeometry,
  Raycaster,
  Vector2,
} from 'three/webgpu';
import { PANEL } from './layout.js';

const PRESS_DEPTH = 1.4;
const KNOB_SWEEP_DEG = 270;
const DRAG_PER_PX = 0.0045;
const WHEEL_PER_DELTA = 0.00045;

function makeButtonMaterial() {
  return new MeshStandardMaterial({ color: 0x2b2c30, roughness: 0.42, metalness: 0.15 });
}

function buildButton(w, h, id) {
  const g = new Group();
  const geo = new BoxGeometry(w, h, 3);
  const mesh = new Mesh(geo, makeButtonMaterial());
  mesh.position.z = 1.5;
  mesh.castShadow = true;
  g.add(mesh);
  g.userData = { id, mesh, baseZ: 0, pressed: false, pointerId: null, logicalHold: false };
  return g;
}

function buildKnob() {
  const g = new Group();
  const { r, height, skirtR, skirtH } = PANEL.knob;

  const skirt = new Mesh(
    new CylinderGeometry(skirtR, skirtR, skirtH, 48),
    new MeshStandardMaterial({ color: 0x131314, roughness: 0.5, metalness: 0.4 }),
  );
  skirt.rotation.x = Math.PI / 2;
  skirt.position.z = skirtH / 2 + 0.4;
  g.add(skirt);

  const rotor = new Group();
  const bodyGeo = new CylinderGeometry(r, r * 1.04, height, 48, 1);
  const body = new Mesh(
    bodyGeo,
    new MeshStandardMaterial({ color: 0x17181a, roughness: 0.32, metalness: 0.55 }),
  );
  body.rotation.x = Math.PI / 2;
  body.position.z = height / 2 + skirtH + 0.3;
  body.castShadow = true;
  body.name = 'knob-hit';
  rotor.add(body);

  const ridgeGeo = new BoxGeometry(0.9, 1.6, height * 0.92);
  const ridgeMat = new MeshStandardMaterial({ color: 0x0c0c0d, roughness: 0.55, metalness: 0.3 });
  for (let i = 0; i < 20; i++) {
    const a = (i / 20) * Math.PI * 2;
    const ridge = new Mesh(ridgeGeo, ridgeMat);
    ridge.position.set(Math.cos(a) * (r - 0.35), Math.sin(a) * (r - 0.35), height / 2 + skirtH + 0.3);
    ridge.rotation.z = a;
    rotor.add(ridge);
  }

  const line = new Mesh(
    new BoxGeometry(1.1, r * 0.72, 0.7),
    new MeshStandardMaterial({ color: 0xd9d9d9, roughness: 0.4, metalness: 0.1 }),
  );
  line.position.set(0, r * 0.34, height + skirtH + 0.65);
  rotor.add(line);

  g.add(rotor);
  g.userData = { rotor, hitMesh: body };
  return g;
}

export class PanelControls {
  constructor(panelGroup, callbacks) {
    this._cb = callbacks || {};
    this._raycaster = new Raycaster();
    this._ndc = new Vector2();
    this._buttons = [];
    this._value = 1;
    this._drag = null;
    this._activePointers = new Map();
    this._logicalHeld = new Set();

    this._root = new Group();
    this._root.name = 'controls';
    panelGroup.add(this._root);

    for (let r = 0; r < 2; r++) {
      for (let c = 0; c < 3; c++) {
        const id = PANEL.part.ids[r][c];
        const btn = buildButton(PANEL.part.size, PANEL.part.size, id);
        btn.position.set(PANEL.part.cols[c], PANEL.part.rows[r], 0.7);
        this._root.add(btn);
        this._buttons.push(btn);
      }
    }
    for (const item of PANEL.wide.items) {
      const btn = buildButton(PANEL.wide.w, PANEL.wide.h, item.id);
      btn.position.set(item.cx, item.cy, 0.7);
      this._root.add(btn);
      this._buttons.push(btn);
    }

    this._knob = buildKnob();
    this._knob.position.set(PANEL.knob.cx, PANEL.knob.cy, 0.4);
    this._root.add(this._knob);
    this.setVolume01(this._value, true);
  }

  get knobValue() {
    return this._value;
  }

  findButton(id) {
    return this._buttons.find((b) => b.userData.id === id) || null;
  }

  hitTargets() {
    const targets = this._buttons.map((b) => b.userData.mesh);
    targets.push(this._knob.userData.hitMesh);
    return targets;
  }

  setVolume01(v, silent) {
    this._value = Math.min(1, Math.max(0, v));
    const deg = KNOB_SWEEP_DEG / 2 - this._value * KNOB_SWEEP_DEG;
    this._knob.userData.rotor.rotation.z = (deg * Math.PI) / 180;
    if (!silent && typeof this._cb.onVolumeChange === 'function') {
      this._cb.onVolumeChange(this._value);
    }
  }

  _applyVisual(btn) {
    const ud = btn.userData;
    const down = ud.pointerId != null || ud.logicalHold || this._logicalHeld.has(ud.id);
    ud.pressed = down;
    ud.mesh.position.z = down ? 1.5 - PRESS_DEPTH : 1.5;
  }

  _refreshAllVisuals() {
    for (const btn of this._buttons) this._applyVisual(btn);
  }

  setButtonPressed(id, pressed) {
    if (pressed) this._logicalHeld.add(id);
    else this._logicalHeld.delete(id);
    const btn = this.findButton(id);
    if (btn) {
      btn.userData.logicalHold = !!pressed;
      this._applyVisual(btn);
    }
  }

  syncHeldButtons(ids) {
    const next = new Set(ids || []);
    this._logicalHeld = next;
    for (const btn of this._buttons) {
      btn.userData.logicalHold = next.has(btn.userData.id);
      this._applyVisual(btn);
    }
  }

  pressButton(btn, pointerId) {
    const ud = btn.userData;
    ud.pointerId = pointerId;
    this._applyVisual(btn);
    if (typeof this._cb.onButtonPress === 'function') {
      this._cb.onButtonPress(ud.id);
    }
  }

  releaseButton(btn, opts = {}) {
    const ud = btn.userData;
    const fire = opts.fire !== false;
    const hadPointer = ud.pointerId != null;
    ud.pointerId = null;
    this._applyVisual(btn);
    if (fire && hadPointer && typeof this._cb.onButtonRelease === 'function') {
      this._cb.onButtonRelease(ud.id);
    }
  }

  releaseAll() {
    for (const btn of this._buttons) {
      if (btn.userData.pointerId != null) {
        this.releaseButton(btn, { fire: true });
      }
    }
    this._activePointers.clear();
    this._refreshAllVisuals();
  }

  update(_dtMs) {
    this._refreshAllVisuals();
  }

  pointerHit(event, camera) {
    const el = event.target;
    const rect = el.getBoundingClientRect();
    this._ndc.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this._raycaster.setFromCamera(this._ndc, camera);
    const hits = this._raycaster.intersectObjects(this.hitTargets(), false);
    return hits.length > 0 ? hits[0] : null;
  }

  onPointerDown(event, camera) {
    const hit = this.pointerHit(event, camera);
    if (!hit) return false;
    const btn = this._buttons.find((b) => b.userData.mesh === hit.object);
    if (btn) {
      this._activePointers.set(event.pointerId, { type: 'button', btn });
      this.pressButton(btn, event.pointerId);
      try {
        event.target.setPointerCapture(event.pointerId);
      } catch (_) {}
      return true;
    }
    if (hit.object === this._knob.userData.hitMesh) {
      this._drag = { startY: event.clientY, startValue: this._value };
      this._activePointers.set(event.pointerId, { type: 'knob' });
      try {
        event.target.setPointerCapture(event.pointerId);
      } catch (_) {}
      return true;
    }
    return false;
  }

  onPointerMove(event, camera) {
    if (this._drag && this._activePointers.get(event.pointerId)?.type === 'knob') {
      const dv = (this._drag.startY - event.clientY) * DRAG_PER_PX;
      this.setVolume01(this._drag.startValue + dv);
      return true;
    }
    const hit = this.pointerHit(event, camera);
    event.target.style.cursor = hit ? 'pointer' : '';
    return false;
  }

  onPointerUp(event) {
    const rec = this._activePointers.get(event.pointerId);
    this._activePointers.delete(event.pointerId);

    if (rec?.type === 'button' && rec.btn) {
      this.releaseButton(rec.btn, { fire: true });
      if (event.target.hasPointerCapture && event.target.hasPointerCapture(event.pointerId)) {
        try {
          event.target.releasePointerCapture(event.pointerId);
        } catch (_) {}
      }
      this._refreshAllVisuals();
      return true;
    }

    if (this._drag && (rec?.type === 'knob' || !rec)) {
      this._drag = null;
      if (event.target.hasPointerCapture && event.target.hasPointerCapture(event.pointerId)) {
        try {
          event.target.releasePointerCapture(event.pointerId);
        } catch (_) {}
      }
      return true;
    }
    return false;
  }

  onWheel(event, camera) {
    const hit = this.pointerHit(event, camera);
    if (hit && hit.object === this._knob.userData.hitMesh) {
      event.preventDefault();
      this.setVolume01(this._value - event.deltaY * WHEEL_PER_DELTA);
      return true;
    }
    return false;
  }
}
