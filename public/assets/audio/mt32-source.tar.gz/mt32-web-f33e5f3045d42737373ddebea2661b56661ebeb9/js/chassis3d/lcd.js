import { glyphBits, GLYPH_W, GLYPH_H } from './dotfont.js';

const COLS = 20;               // 20 chars × 1 row (LCD2001 hardware spec)
const CHAR_PITCH = GLYPH_W + 1; // Character pitch = 5-dot glyph width + 1-dot gap

/* LCD color scheme (real unit is STN positive display: bright yellow-green background + dark dots; do not switch to dark background with bright dots) */
const PALETTE = {
  background: '#7d9c2e',            // Glass background (middle)
  glassTint: '#8fb038',             // Glass background (top/bottom edge gradient)
  dotOn: '#26330d',                 // Lit dot (dark olive)
  dotOff: 'rgba(38, 51, 13, 0.10)', // Unlit dot (barely visible)
  vignette: 'rgba(30, 42, 8, 0.28)',// Corner vignette
};

export class LcdDisplay {
  constructor(glassW, glassH) {
    this.cols = COLS;
    this.text = '';
    /* Dot pitch and padding (canvas pixels).
     * Real LCD dots are vertically-elongated ellipses: horizontal pitch < vertical pitch.
     * Total canvas size = (20×6×pitchX + 2×padX) × (7×pitchY + 2×padY),
     * whose aspect ratio must match glassW/glassH of the glass plane (layout.js PANEL.lcd),
     * otherwise the dot matrix gets stretched. */
    this._pitchX = 7;
    this._pitchY = 8;
    this._padX = 30;
    this._padY = 20;

    const dotFieldW = COLS * CHAR_PITCH * this._pitchX;
    const dotFieldH = GLYPH_H * this._pitchY;
    this.canvas = document.createElement('canvas');
    this.canvas.width = dotFieldW + this._padX * 2;
    this.canvas.height = dotFieldH + this._padY * 2;
    this._ctx = this.canvas.getContext('2d');
    this.texture = null;
    this.setText('');
  }

  setText(text) {
    const clean = String(text == null ? '' : text)
      .replace(/[\r\n]+/g, ' ')
      .replace(/[\u0000\u0002-\u0008\u000b\u000c\u000e-\u001f]/g, ' ')
      .replace(/#/g, '\u0001')
      .slice(0, COLS);
    this.text = clean;
    this._draw(clean.padEnd(COLS, ' '));
  }

  _draw(row) {
    const ctx = this._ctx;
    const { width: w, height: h } = this.canvas;

    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, PALETTE.glassTint);
    bg.addColorStop(0.5, PALETTE.background);
    bg.addColorStop(1, PALETTE.glassTint);
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    const px_ = this._pitchX;
    const py_ = this._pitchY;
    for (let ci = 0; ci < COLS; ci++) {
      const bits = glyphBits(row[ci]);
      const ox = this._padX + ci * CHAR_PITCH * px_;
      for (let gy = 0; gy < GLYPH_H; gy++) {
        for (let gx = 0; gx < GLYPH_W; gx++) {
          const on = bits[gy * GLYPH_W + gx] === 1;
          const cx = ox + gx * px_ + px_ / 2;
          const cy = this._padY + gy * py_ + py_ / 2;
          ctx.beginPath();
          ctx.ellipse(cx, cy, on ? px_ * 0.38 : px_ * 0.32, on ? py_ * 0.38 : py_ * 0.32, 0, 0, Math.PI * 2);
          ctx.fillStyle = on ? PALETTE.dotOn : PALETTE.dotOff;
          ctx.fill();
        }
      }
    }

    const vg = ctx.createRadialGradient(w / 2, h / 2, h * 0.4, w / 2, h / 2, w * 0.62);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, PALETTE.vignette);
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, w, h);

    if (this.texture) {
      this.texture.needsUpdate = true;
    }
  }
}
