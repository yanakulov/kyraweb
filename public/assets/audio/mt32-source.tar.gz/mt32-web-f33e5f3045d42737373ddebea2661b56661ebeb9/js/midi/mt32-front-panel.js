import {
  ROM_STARTUP_LCD,
  LCD_TMPL,
  ROM_GROUP_NAMES,
  ROM_TIMBRE_NAMES,
  ROM_TIMBRE_GROUP_IX,
  ROM_GROUP_MEMBERS,
} from './mt32-rom-lcd-data.js';

export { ROM_STARTUP_LCD };

function asciiWindow(u8, off, len) {
  let s = '';
  for (let i = 0; i < len; i++) {
    const idx = off + i;
    if (idx < 0 || idx >= u8.length) {
      s += ' ';
      continue;
    }
    const b = u8[idx];
    s += b >= 32 && b <= 126 ? String.fromCharCode(b) : ' ';
  }
  return s;
}

function isFirmwareBanner(s) {
  if (!s || s.length < 10) return false;
  if (/overflow|everb|checksum|error|assign|buffer|verify/i.test(s)) return false;
  if (/ver(?:\d|\.|X)/i.test(s) && (/\d+\.\d{2}/.test(s) || /verX\.XX/i.test(s))) return true;
  if (/MT-?32\s*v\s*\d+\.\d{2}/i.test(s)) return true;
  if (/CM-?32|LAPC/i.test(s) && /\d+\.\d{2}/.test(s)) return true;
  return false;
}

function scoreFirmwareCandidate(start, s, romLen) {
  let score = 1;
  if (/MT-?32\s*v\s*2\./i.test(s)) score += 5;
  if (/MT-?32\s*v\s*1\./i.test(s)) score += 4;
  if (/^ ?ver\d+\.\d{2}/i.test(s.trim())) score += 4;
  if (/CM-?32|LAPC/i.test(s)) score += 3;
  if (romLen <= 65536 && start >= 0x3f00 && start <= 0x4200) score += 2;
  if (romLen > 65536 && start >= 0x2000 && start <= 0x2800) score += 2;
  if (/\d{2}[-/ ]\d{2}/.test(s) || /[A-Za-z]{3}/.test(s)) score += 1;
  return score;
}

export function extractFirmwareLcdFromControlRom(bytes) {
  if (!bytes) return null;
  const u8 = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (u8.length < 32) return null;

  const candidates = [];
  const seen = new Set();
  const push = (start, s) => {
    if (!isFirmwareBanner(s)) return;
    const key = start + '|' + s;
    if (seen.has(key)) return;
    seen.add(key);
    candidates.push({
      start,
      s,
      score: scoreFirmwareCandidate(start, s, u8.length),
    });
  };

  const limit = Math.min(u8.length - 3, 0x20000);
  for (let i = 0; i < limit; i++) {
    if (u8[i] !== 0x76 && u8[i] !== 0x56) continue;
    if (u8[i + 1] !== 0x65 && u8[i + 1] !== 0x45) continue;
    if (u8[i + 2] !== 0x72 && u8[i + 2] !== 0x52) continue;
    const start = i > 0 && (u8[i - 1] === 0x20 || u8[i - 1] < 32) ? i - 1 : i;
    push(start, asciiWindow(u8, start, 20));
  }

  for (let i = 0; i < limit; i++) {
    const b0 = u8[i];
    if (b0 !== 0x4d && b0 !== 0x43 && b0 !== 0x6d && b0 !== 0x4d) {
      if (b0 !== 0x4d && b0 !== 0x43) continue;
    }
    if (b0 === 0x4d || b0 === 0x6d) {
      const s3 = asciiWindow(u8, i, 4);
      if (!/^MT-?3/i.test(s3) && !/^mt-?3/i.test(s3)) continue;
    } else if (b0 === 0x43 || b0 === 0x63) {
      const s3 = asciiWindow(u8, i, 4);
      if (!/^CM/i.test(s3) && !/^cm/i.test(s3)) continue;
    }
    push(i, asciiWindow(u8, i, 20));
  }

  for (let i = 0; i < limit - 8; i++) {
    if (u8[i] !== 0x76 && u8[i] !== 0x56) continue;
    if (u8[i + 1] < 0x30 || u8[i + 1] > 0x39) continue;
    if (u8[i + 2] !== 0x2e) continue;
    const start = i > 5 ? i - 5 : 0;
    push(start, asciiWindow(u8, start, 20));
    push(i > 0 && u8[i - 1] === 0x20 ? i - 1 : i, asciiWindow(u8, i > 0 && u8[i - 1] === 0x20 ? i - 1 : i, 20));
  }

  if (!candidates.length) return null;
  candidates.sort((a, b) => b.score - a.score || a.start - b.start);
  return candidates[0].s;
}

export function rolandChecksum(addrAndData) {
  let sum = 0;
  for (let i = 0; i < addrAndData.length; i++) sum += addrAndData[i] & 0x7f;
  return (128 - (sum & 0x7f)) & 0x7f;
}

export function buildDt1(addr3, data, unitNumber = 17) {
  const dev = Math.max(0, Math.min(31, (unitNumber | 0) - 1)) & 0x7f;
  const payload = [0x41, dev, 0x16, 0x12, addr3[0], addr3[1], addr3[2], ...data];
  const cs = rolandChecksum([addr3[0], addr3[1], addr3[2], ...data]);
  payload.push(cs);
  return new Uint8Array(payload);
}

export function masterVolumeSysex(level0to100, unitNumber = 17) {
  const v = Math.max(0, Math.min(100, level0to100 | 0));
  return buildDt1([0x10, 0x00, 0x16], [v], unitNumber);
}

export function masterTuneSysex(value0to127, unitNumber = 17) {
  const v = Math.max(0, Math.min(127, value0to127 | 0));
  return buildDt1([0x10, 0x00, 0x00], [v], unitNumber);
}

export function reverbModeSysex(mode0to7, unitNumber = 17) {
  const v = Math.max(0, Math.min(7, mode0to7 | 0));
  return buildDt1([0x10, 0x00, 0x01], [v], unitNumber);
}

export function reverbTimeSysex(time0to7, unitNumber = 17) {
  const v = Math.max(0, Math.min(7, time0to7 | 0));
  return buildDt1([0x10, 0x00, 0x02], [v], unitNumber);
}

export function reverbLevelSysex(level0to7, unitNumber = 17) {
  const v = Math.max(0, Math.min(7, level0to7 | 0));
  return buildDt1([0x10, 0x00, 0x03], [v], unitNumber);
}

export function partMidiChannelSysex(partIndex, channelOrOff, unitNumber = 17) {
  const p = Math.max(0, Math.min(8, partIndex | 0));
  const ch = Math.max(0, Math.min(16, channelOrOff | 0));
  return buildDt1([0x10, 0x00, 0x0d + p], [ch], unitNumber);
}

export function partOutputLevelSysex(partIndex, level0to100, unitNumber = 17) {
  const p = Math.max(0, Math.min(8, partIndex | 0));
  const off = p * 16 + 8;
  const addr = [0x03, (off >> 7) & 0x7f, off & 0x7f];
  const v = Math.max(0, Math.min(100, level0to100 | 0));
  return buildDt1(addr, [v], unitNumber);
}

export function partTimbreSysex(partIndex, group, number, unitNumber = 17) {
  const p = Math.max(0, Math.min(8, partIndex | 0));
  const off = p * 16;
  const addr = [0x03, (off >> 7) & 0x7f, off & 0x7f];
  const g = Math.max(0, Math.min(3, group | 0));
  const n = Math.max(0, Math.min(63, number | 0));
  return buildDt1(addr, [g, n], unitNumber);
}

export function allResetSysex(unitNumber = 17) {
  return buildDt1([0x7f, 0x00, 0x00], [0x00], unitNumber);
}

export function displayResetSysex(unitNumber = 17) {
  return buildDt1([0x20, 0x01, 0x00], [], unitNumber);
}

function mapPanelReverbToEngine(panel0to10) {
  const v = Math.max(0, Math.min(10, panel0to10 | 0));
  if (v === 0) return { mode: 0, time: 0, level: 0 };
  const mode = Math.min(3, Math.floor((v - 1) / 3));
  const time = Math.min(7, 1 + Math.floor(v * 0.7));
  const level = Math.min(7, Math.ceil(v * 0.7));
  return { mode, time, level };
}

export function defaultMidiChannelForPart(partIndex, mapAlt) {
  const p = Math.max(0, Math.min(8, partIndex | 0));
  if (p === 8) return 9;
  if (mapAlt) return p;
  return p + 1;
}

export const SOUND_GROUPS = ROM_GROUP_NAMES.slice(0, 17).map((name, id) => ({
  id,
  name,
  members: ROM_GROUP_MEMBERS[id] || [],
}));

function pad20(s) {
  const t = String(s == null ? '' : s).slice(0, 20);
  return t + ' '.repeat(Math.max(0, 20 - t.length));
}

function padLeft(n, w) {
  const s = String(n);
  return ' '.repeat(Math.max(0, w - s.length)) + s;
}

function vol3(n) {
  return padLeft(Math.max(0, Math.min(100, n | 0)), 3);
}

function hzFromTune(tune0to127) {
  const hz = 427.5 + (tune0to127 / 127) * (452.6 - 427.5);
  return Math.round(hz * 10) / 10;
}

function tuneFromHz(hz) {
  const t = ((hz - 427.5) / (452.6 - 427.5)) * 127;
  return Math.max(0, Math.min(127, Math.round(t)));
}

function formatHz(hz) {
  if (Math.abs(hz - 442) < 0.15) return '442.0Hz';
  const x = Math.round(hz * 10) / 10;
  return x.toFixed(1) + 'Hz';
}

function lcdMasterVol(vol) {
  return pad20(`1 2 3 4 5 R |vol:${vol3(vol)}`);
}

function lcdPartVolume(partLabel, timbre10, vol) {
  const name = pad20(timbre10).slice(0, 10);
  return pad20(`${partLabel}|${name}|vol>${vol3(vol)}`);
}

function lcdSoundGroup(partLabel, group7, timbre10, flashOn) {
  const g = pad20(group7).slice(0, 7);
  const n = pad20(timbre10).slice(0, 10);
  const cur = flashOn ? '>' : ' ';
  return pad20(`${partLabel}${cur}${g}|${n}`);
}

function lcdSound(partLabel, group7, timbre10, flashOn) {
  const g = pad20(group7).slice(0, 7);
  const n = pad20(timbre10).slice(0, 10);
  const cur = flashOn ? '>' : ' ';
  return pad20(`${partLabel}|${g}${cur}${n}`);
}

const BLOCK = '\u0001';

function lcdMainActivity(activeParts, masterVol, flashRhythm) {
  let s = '';
  for (let i = 0; i < 5; i++) {
    const on = !!(activeParts && activeParts[i]);
    s += on ? BLOCK : String(i + 1);
    s += ' ';
  }
  const rhy = !!(activeParts && activeParts[8]) || flashRhythm;
  s += rhy ? BLOCK : 'R';
  s += ' ';
  s += `|vol:${vol3(masterVol)}`;
  return pad20(s.slice(0, 20));
}

function patchMainVol(text, masterVol) {
  const base = pad20(text == null ? '' : text);
  if (!/\|vol:/.test(base)) return base;
  return pad20(base.replace(/\|vol:\s*\d+/, `|vol:${vol3(masterVol)}`));
}

function isMainActivityLcd(text) {
  if (text == null) return false;
  const s = String(text);
  return /\|vol:/.test(s) && /[1-5R\u0001#\u2588]/.test(s);
}

function isEngineDisplayStub(text) {
  const t = String(text == null ? '' : text).trim();
  if (!t) return true;
  if (/^(TSF|MUNT)\b/i.test(t)) return true;
  return false;
}


function lcdMasterTune(hz) {
  return pad20(LCD_TMPL.tunePrefix + formatHz(hz));
}

function lcdReverb(mode) {
  return pad20(LCD_TMPL.reverbPrefix + padLeft(mode, 3));
}

function lcdUnit(num) {
  return pad20(LCD_TMPL.unitPrefix + padLeft(num, 3));
}

function flatIndex(group, number) {
  const g = Math.max(0, Math.min(3, group | 0));
  const n = Math.max(0, Math.min(63, number | 0));
  if (g === 0) return n;
  if (g === 1) return 64 + n;
  return n;
}

function groupIxForFlat(flat) {
  const f = Math.max(0, Math.min(127, flat | 0));
  return ROM_TIMBRE_GROUP_IX[f] | 0;
}

const CHORD_STEP_MS = 5000;
const BANNER_MS = 1600;
const SYSTEM_BANNER_MS = 4500;
const MASTER_LONG_MS = 400;
const MASTER_STICKY_MS = 3500;
const FLASH_MS = 400;
const PC_BANNER_MS = 1300;
const ACTIVITY_MS = 220;

export class Mt32FrontPanel {
  constructor() {
    this.mode = 'main';
    this.selectedPart = 0;
    this.masterVol = 100;
    this.partVol = [80, 80, 80, 80, 80, 80, 80, 80, 80];
    this.timbreGroup = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    this.timbreNum = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    this.panelGroup = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    this.panelTone = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    this.masterTune = tuneFromHz(442.0);
    this.reverbMode = 0;
    this.reverbTime = 5;
    this.reverbLevel = 3;
    this.unitNumber = 17;
    this.midiMapAlt = false;
    this.overflowAssign = false;
    this.firmwareLcd = null;

    this.held = new Set();
    this.keyboardMaster = false;
    this.masterStickyUntil = 0;
    this.masterDownAt = 0;
    this.masterLongArmed = false;
    this.chordSeq = null;
    this.banner = null;
    this.panelLcdActive = false;
    this.pcBanner = null;

    this.potCaught = true;
    this.potTarget01 = 1;
    this.potLast01 = 1;

    this.partActiveUntil = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    this.engineMainText = null;
  }

  setFirmwareLcd(text) {
    const t = String(text == null ? '' : text).slice(0, 20);
    if (t.trim().length) this.firmwareLcd = pad20(t);
  }

  setFirmwareFromControlRom(controlBytes) {
    const ver = extractFirmwareLcdFromControlRom(controlBytes);
    this.firmwareLcd = ver;
    return this.firmwareLcd;
  }

  showFirmwareVersion() {
    this.masterStickyUntil = 0;
    this.chordSeq = null;
    this.mode = 'main';
    this.panelLcdActive = true;
    const text = this.firmwareLcd || pad20('Load CONTROL.ROM  ');
    this.setBanner(text, 4000);
    return this._result({ status: this.firmwareLcd ? 'Firmware ' + this.firmwareLcd.trim() : 'No CONTROL.ROM' });
  }

  now() {
    return typeof performance !== 'undefined' ? performance.now() : Date.now();
  }

  _unit() {
    return this.unitNumber;
  }

  isMasterModifier() {
    if (this.keyboardMaster) return true;
    if (this.held.has('master-volume')) return true;
    if (this.now() < this.masterStickyUntil) return true;
    return false;
  }

  visualHeldIds() {
    const ids = new Set(this.held);
    if (this.keyboardMaster) ids.add('master-volume');
    return ids;
  }

  _extendMasterSticky() {
    if (this.isMasterModifier()) {
      this.masterStickyUntil = this.now() + MASTER_STICKY_MS;
    }
  }

  _clearMasterSticky() {
    this.masterStickyUntil = 0;
    this.masterLongArmed = false;
  }

  flashOn() {
    return Math.floor(this.now() / FLASH_MS) % 2 === 0;
  }

  partIndexFromId(id) {
    switch (id) {
      case 'part1': return 0;
      case 'part2': return 1;
      case 'part3': return 2;
      case 'part4': return 3;
      case 'part5': return 4;
      case 'rhythm': return 8;
      default: return this.selectedPart;
    }
  }

  _partLabel(p = this.selectedPart) {
    return p === 8 ? 'R' : String(p + 1);
  }

  _flatTimbre(p = this.selectedPart) {
    const g = this.panelGroup[p] | 0;
    const members = ROM_GROUP_MEMBERS[g] || [0];
    const tone = Math.max(0, Math.min(members.length - 1, this.panelTone[p] | 0));
    return members[tone] | 0;
  }

  _timbreName10(p = this.selectedPart) {
    if (p === 8) return 'Rhythm    ';
    const flat = this._flatTimbre(p);
    const n = ROM_TIMBRE_NAMES[flat] || '**********';
    return pad20(n).slice(0, 10);
  }

  _groupName7(p = this.selectedPart) {
    if (p === 8) return 'Rhythm ';
    const g = Math.max(0, Math.min(ROM_GROUP_NAMES.length - 1, this.panelGroup[p] | 0));
    return pad20(ROM_GROUP_NAMES[g]).slice(0, 7);
  }

  _syncPatchFromPanel(p) {
    const flat = this._flatTimbre(p);
    if (flat < 64) {
      this.timbreGroup[p] = 0;
      this.timbreNum[p] = flat;
    } else {
      this.timbreGroup[p] = 1;
      this.timbreNum[p] = flat - 64;
    }
  }

  getPanelLcdText() {
    const t = this.now();
    if (this.banner && t < this.banner.until) return pad20(this.banner.text);
    if (this.banner && t >= this.banner.until) this.banner = null;
    if (this.pcBanner && t < this.pcBanner.until) return pad20(this.pcBanner.text);
    if (this.pcBanner && t >= this.pcBanner.until) this.pcBanner = null;

    const pl = this._partLabel();
    const name = this._timbreName10();
    const g7 = this._groupName7();
    const fl = this.flashOn();

    switch (this.mode) {
      case 'main':
      case 'master':
        return this._lcdMain();
      case 'volume':
        return lcdPartVolume(pl, name, this.partVol[this.selectedPart]);
      case 'sound-group':
        return lcdSoundGroup(pl, g7, name, fl);
      case 'sound':
        return lcdSound(pl, g7, name, fl);
      case 'master-tune':
        return lcdMasterTune(hzFromTune(this.masterTune));
      case 'reverb':
        return lcdReverb(this.reverbMode);
      case 'unit-number':
        return lcdUnit(this.unitNumber);
      default:
        return null;
    }
  }

  _lcdMain() {
    const t = this.now();
    const active = this.partActiveUntil.map((u) => u > t);
    const eng = this.engineMainText != null ? String(this.engineMainText) : '';
    if (eng && isMainActivityLcd(eng)) {
      return patchMainVol(eng, this.masterVol);
    }
    if (eng && !isEngineDisplayStub(eng)) {
      return pad20(eng);
    }
    return lcdMainActivity(active, this.masterVol, active[8]);
  }

  noteActivity(status, data1, data2) {
    const st = status & 0xff;
    const cmd = st & 0xf0;
    const ch = st & 0x0f;
    if (cmd !== 0x90 && cmd !== 0x80) return;
    const vel = data2 & 0x7f;
    if (cmd === 0x90 && vel === 0) return;
    if (cmd === 0x80) return;
    let part = -1;
    for (let p = 0; p < 9; p++) {
      if (defaultMidiChannelForPart(p, this.midiMapAlt) === ch) {
        part = p;
        break;
      }
    }
    if (part < 0) return;
    this.partActiveUntil[part] = this.now() + ACTIVITY_MS;
    if (this.mode === 'main' || this.mode === 'master') this.panelLcdActive = true;
  }

  setEngineMainText(text) {
    this.engineMainText = text == null ? null : String(text);
  }

  showProgramChange(partIndex, group7, timbre10) {
    if (this.mode !== 'main' && this.mode !== 'master') return;
    const p = Math.max(0, Math.min(7, partIndex | 0));
    const g = pad20(group7 || this._groupName7(p)).slice(0, 7);
    const n = pad20(timbre10 || this._timbreName10(p)).slice(0, 10);
    this.pcBanner = {
      text: pad20(`${p + 1}|${g} ${n}`),
      until: this.now() + PC_BANNER_MS,
    };
  }

  setBanner(text, ms = BANNER_MS) {
    this.banner = { text: pad20(text), until: this.now() + ms };
    this.panelLcdActive = true;
  }

  _midimapPrompt() {
    return this.midiMapAlt ? 'Channel 2 to 9 ? [1]' : LCD_TMPL.channel;
  }

  _armChord(kind, promptLcd) {
    const t = this.now();
    this._extendMasterSticky();
    this.chordSeq = { kind, until: t + CHORD_STEP_MS };
    if (promptLcd != null) this.setBanner(promptLcd, SYSTEM_BANNER_MS);
    return this._result({ status: '' });
  }

  armPotCatch() {
    this.potCaught = false;
    this.potTarget01 = this.knob01ForMode();
  }

  knob01ForMode() {
    const p = this.selectedPart;
    switch (this.mode) {
      case 'master':
      case 'main':
        return this.masterVol / 100;
      case 'volume':
        return this.partVol[p] / 100;
      case 'sound': {
        const members = ROM_GROUP_MEMBERS[this.panelGroup[p]] || [0];
        const max = Math.max(1, members.length - 1);
        return (this.panelTone[p] | 0) / max;
      }
      case 'sound-group':
        return (this.panelGroup[p] | 0) / 16;
      case 'master-tune':
        return this.masterTune / 127;
      case 'reverb':
        return this.reverbMode / 10;
      case 'unit-number':
        return (this.unitNumber - 1) / 31;
      default:
        return this.masterVol / 100;
    }
  }

  _result(extra = {}) {
    const lcd = this.getPanelLcdText();
    return {
      knob01: this.knob01ForMode(),
      status: extra.status || this._statusLine(),
      lcd,
      panelLcdActive: lcd != null || !!this.banner,
      mode: this.mode,
      selectedPart: this.selectedPart,
      ...extra,
    };
  }

  _statusLine() {
    switch (this.mode) {
      case 'master':
      case 'main':
        return `Master ${this.masterVol}`;
      case 'volume':
        return `P${this._partLabel()} vol ${this.partVol[this.selectedPart]}`;
      case 'sound':
        return `P${this._partLabel()} #${this.timbreNum[this.selectedPart]}`;
      case 'sound-group':
        return `P${this._partLabel()} G${this.timbreGroup[this.selectedPart]}`;
      case 'master-tune':
        return `Tune ${hzFromTune(this.masterTune)}Hz`;
      case 'reverb':
        return `Reverb ${this.reverbMode}`;
      case 'unit-number':
        return `Unit ${this.unitNumber}`;
      default:
        return '';
    }
  }

  setKeyboardMaster(on) {
    this.keyboardMaster = !!on;
  }

  pressButton(id, engine) {
    if (typeof window !== 'undefined' && window.__debug) window.__debug.lastChassisButton = id;
    this.held.add(id);
    const t = this.now();

    if (this.chordSeq && t > this.chordSeq.until) this.chordSeq = null;

    if (id === 'master-volume') {
      const hadSticky = t < this.masterStickyUntil || this.masterLongArmed;
      this._clearMasterSticky();
      this.masterDownAt = t;
      this.mode = 'master';
      this.panelLcdActive = true;
      this.banner = null;
      this.pcBanner = null;
      this.armPotCatch();
      if (engine && typeof engine.setMainDisplayMode === 'function') {
        engine.setMainDisplayMode();
      } else if (engine && typeof engine.playSysex === 'function') {
        engine.playSysex(displayResetSysex(this._unit()));
      }
      if (engine && typeof engine.getDisplayState === 'function') {
        const st = engine.getDisplayState();
        if (st && st.text != null) this.setEngineMainText(st.text);
      }
      return this._result({
        status: hadSticky ? 'Master Volume (latch off)' : 'Master Volume',
      });
    }

    if (this.held.has('master-volume') && this.masterDownAt && t - this.masterDownAt >= MASTER_LONG_MS) {
      this.masterLongArmed = true;
      this.masterStickyUntil = t + MASTER_STICKY_MS;
    }

    const masterMod = this.isMasterModifier() && id !== 'master-volume';

    if (this.chordSeq) {
      const kind = this.chordSeq.kind;
      if (kind === 'part4-branch') {
        if (id === 'part1') {
          this.chordSeq = null;
          this._clearMasterSticky();
          this.overflowAssign = !this.overflowAssign;
          this.setBanner(
            this.overflowAssign ? 'Overflow Assign  ON' : 'Overflow Assign OFF',
            SYSTEM_BANNER_MS,
          );
          return this._result({
            status: this.overflowAssign ? 'Overflow ON' : 'Overflow OFF',
          });
        }
        if (id === 'rhythm') {
          this.chordSeq = null;
          this._clearMasterSticky();
          return this.showFirmwareVersion();
        }
      }
      if (kind === 'rhythm-branch') {
        if (id === 'part1') {
          this.chordSeq = null;
          this._clearMasterSticky();
          return this._doReset(engine, 'all');
        }
        if (id === 'part4') {
          this.chordSeq = null;
          this._clearMasterSticky();
          return this.showFirmwareVersion();
        }
        if (id.startsWith('part')) {
          const p = this.partIndexFromId(id);
          this.chordSeq = null;
          this._clearMasterSticky();
          return this._doReset(engine, p === 0 ? 'all' : 'partial');
        }
      }
      if (kind === 'midimap' && id === 'part1') {
        this.chordSeq = null;
        this._clearMasterSticky();
        return this._setMidiMap(engine, !this.midiMapAlt);
      }
    }

    if (masterMod) {
      if (
        (id === 'part4' && (this.held.has('rhythm') || this.chordSeq?.kind === 'rhythm-branch')) ||
        (id === 'rhythm' && (this.held.has('part4') || this.chordSeq?.kind === 'part4-branch'))
      ) {
        this.chordSeq = null;
        this._clearMasterSticky();
        return this.showFirmwareVersion();
      }
      if (id === 'part1' || id === 'part2' || id === 'part3') {
        this._clearMasterSticky();
        const base = this.partIndexFromId(id);
        this.selectedPart = base + 5;
        if (this.mode === 'main' || this.mode === 'master') this.mode = 'volume';
        this.panelLcdActive = true;
        this.armPotCatch();
        return this._result({ status: `Part ${this._partLabel()}` });
      }
      if (id === 'part4') {
        return this._armChord('part4-branch', LCD_TMPL.overflow);
      }
      if (id === 'part5') {
        return this._armChord('midimap', this._midimapPrompt());
      }
      if (id === 'rhythm') {
        return this._armChord('rhythm-branch', LCD_TMPL.allReset);
      }
      if (id === 'sound-group') {
        this.mode = 'master-tune';
        this.panelLcdActive = true;
        this.banner = null;
        this.armPotCatch();
        return this._result({ status: 'Master Tuning' });
      }
      if (id === 'sound') {
        this.mode = 'unit-number';
        this.panelLcdActive = true;
        this.banner = null;
        this.armPotCatch();
        return this._result({ status: 'Unit Number' });
      }
      if (id === 'volume') {
        this.mode = 'reverb';
        this.panelLcdActive = true;
        this.banner = null;
        this.armPotCatch();
        return this._result({ status: 'Reverb Mode' });
      }
    }

    if (id === 'volume') {
      this.mode = 'volume';
      this.panelLcdActive = true;
      this.armPotCatch();
      return this._result({ status: `Part ${this._partLabel()} volume` });
    }
    if (id === 'sound') {
      this.mode = 'sound';
      this.panelLcdActive = true;
      this.armPotCatch();
      return this._result({ status: `Part ${this._partLabel()} sound` });
    }
    if (id === 'sound-group') {
      this.mode = 'sound-group';
      this.panelLcdActive = true;
      this.armPotCatch();
      return this._result({ status: `Part ${this._partLabel()} group` });
    }
    if (id === 'part1' || id === 'part2' || id === 'part3' || id === 'part4' || id === 'part5' || id === 'rhythm') {
      this.selectedPart = this.partIndexFromId(id);
      if (this.mode === 'main' || this.mode === 'master') this.mode = 'volume';
      this.panelLcdActive = true;
      this.armPotCatch();
      return this._result({ status: `Part ${this._partLabel()}` });
    }

    return this._result();
  }

  releaseButton(id) {
    const t = this.now();
    if (id === 'master-volume') {
      const heldMs = this.masterDownAt ? t - this.masterDownAt : 0;
      if (heldMs >= MASTER_LONG_MS || this.masterLongArmed) {
        this.masterStickyUntil = t + MASTER_STICKY_MS;
        this.masterLongArmed = true;
      } else {
        this._clearMasterSticky();
      }
      this.masterDownAt = 0;
    }
    this.held.delete(id);
    return this._result({ status: this._statusLine() });
  }

  _doReset(engine, kind) {
    if (kind === 'all') {
      this.masterVol = 100;
      this.partVol = [80, 80, 80, 80, 80, 80, 80, 80, 80];
      this.timbreGroup = [0, 0, 0, 0, 0, 0, 0, 0, 0];
      this.timbreNum = [0, 0, 0, 0, 0, 0, 0, 0, 0];
      this.panelGroup = [0, 0, 0, 0, 0, 0, 0, 0, 0];
      this.panelTone = [0, 0, 0, 0, 0, 0, 0, 0, 0];
      this.masterTune = tuneFromHz(442.0);
      this.reverbMode = 0;
      this.reverbTime = 5;
      this.reverbLevel = 3;
      this.midiMapAlt = false;
      this.overflowAssign = false;
      this.mode = 'main';
      this.setBanner('** All Reset **     ', SYSTEM_BANNER_MS);
      if (engine) {
        if (typeof engine.reset === 'function') engine.reset();
        else if (typeof engine.playSysex === 'function') engine.playSysex(allResetSysex(this._unit()));
        if (typeof engine.setMainDisplayMode === 'function') engine.setMainDisplayMode();
        this._pushAllState(engine);
      }
      return this._result({ status: 'All Reset', webVolume01: 1 });
    }

    this.masterVol = 100;
    this.partVol = [80, 80, 80, 80, 80, 80, 80, 80, 80];
    this.mode = 'main';
    this.setBanner('** Partial Reset ** ', SYSTEM_BANNER_MS);
    if (engine) {
      if (typeof engine.setMainDisplayMode === 'function') engine.setMainDisplayMode();
      this._sendMaster(engine);
      for (let p = 0; p < 9; p++) {
        if (typeof engine.playSysex === 'function') {
          engine.playSysex(partOutputLevelSysex(p, this.partVol[p], this._unit()));
        }
      }
    }
    return this._result({ status: 'Partial Reset', webVolume01: 1 });
  }

  _setMidiMap(engine, alt) {
    this.midiMapAlt = !!alt;
    this.setBanner(
      this.midiMapAlt ? LCD_TMPL.channel : 'Channel 2 to 9 ? [1]',
      SYSTEM_BANNER_MS,
    );
    if (engine && typeof engine.playSysex === 'function') {
      for (let p = 0; p < 9; p++) {
        const ch = defaultMidiChannelForPart(p, this.midiMapAlt);
        engine.playSysex(partMidiChannelSysex(p, ch, this._unit()));
      }
    }
    return this._result({ status: this.midiMapAlt ? 'MIDI map 1-8' : 'MIDI map 2-9' });
  }

  _pushAllState(engine) {
    if (!engine || typeof engine.playSysex !== 'function') return;
    this._sendMaster(engine);
    engine.playSysex(masterTuneSysex(this.masterTune, this._unit()));
    this._sendReverb(engine);
    for (let p = 0; p < 9; p++) {
      engine.playSysex(partOutputLevelSysex(p, this.partVol[p], this._unit()));
      if (p <= 7) {
        this._syncPatchFromPanel(p);
        engine.playSysex(partTimbreSysex(p, this.timbreGroup[p], this.timbreNum[p], this._unit()));
      }
      engine.playSysex(partMidiChannelSysex(p, defaultMidiChannelForPart(p, this.midiMapAlt), this._unit()));
    }
  }

  _sendMaster(engine) {
    if (engine && typeof engine.playSysex === 'function') {
      engine.playSysex(masterVolumeSysex(this.masterVol, this._unit()));
    }
  }

  _sendReverb(engine) {
    if (!engine || typeof engine.playSysex !== 'function') return;
    const m = mapPanelReverbToEngine(this.reverbMode);
    this.reverbTime = m.time;
    this.reverbLevel = m.level;
    engine.playSysex(reverbModeSysex(m.mode, this._unit()));
    engine.playSysex(reverbTimeSysex(m.time, this._unit()));
    engine.playSysex(reverbLevelSysex(m.level, this._unit()));
  }

  _sendTimbre(engine, p) {
    if (p === 8) return;
    this._syncPatchFromPanel(p);
    if (typeof engine.playSysex === 'function') {
      engine.playSysex(partTimbreSysex(p, this.timbreGroup[p], this.timbreNum[p], this._unit()));
    }
    if (typeof engine.playMsg === 'function' && p <= 7) {
      const ch = defaultMidiChannelForPart(p, this.midiMapAlt);
      const flat = this._flatTimbre(p);
      engine.playMsg(0xc0 | (ch & 0x0f), (flat % 128) & 0x7f, 0);
      this.showProgramChange(p, this._groupName7(p), this._timbreName10(p));
    }
  }

  setKnob01(v, engine) {
    const t = Math.max(0, Math.min(1, v));
    const prev = this.potLast01;
    this.potLast01 = t;

    if (!this.potCaught) {
      const target = this.potTarget01;
      const crossed =
        (prev <= target && t >= target) ||
        (prev >= target && t <= target) ||
        Math.abs(t - target) <= 0.02;
      if (!crossed) {
        return this._result({ status: this._statusLine() + ' (catch)', caught: false });
      }
      this.potCaught = true;
    }

    this.panelLcdActive = true;

    if (this.mode === 'master' || this.mode === 'main') {
      this.mode = 'master';
      this.masterVol = Math.round(t * 100);
      if (engine && typeof engine.playSysex === 'function') {
        engine.playSysex(masterVolumeSysex(this.masterVol, this._unit()));
      }
      return this._result({
        webVolume01: t,
        status: 'Master ' + this.masterVol,
      });
    }

    const p = this.selectedPart;

    if (this.mode === 'volume') {
      this.partVol[p] = Math.round(t * 100);
      if (engine && typeof engine.playSysex === 'function') {
        engine.playSysex(partOutputLevelSysex(p, this.partVol[p], this._unit()));
      }
      return this._result({ status: 'P' + this._partLabel() + ' vol ' + this.partVol[p] });
    }

    if (this.mode === 'sound') {
      const members = ROM_GROUP_MEMBERS[this.panelGroup[p]] || [0];
      const max = Math.max(0, members.length - 1);
      this.panelTone[p] = Math.round(t * max);
      this._syncPatchFromPanel(p);
      if (engine) this._sendTimbre(engine, p);
      return this._result({ status: 'P' + this._partLabel() + ' ' + this._timbreName10(p).trim() });
    }

    if (this.mode === 'sound-group') {
      this.panelGroup[p] = Math.round(t * 16);
      this.panelTone[p] = 0;
      this._syncPatchFromPanel(p);
      if (engine) this._sendTimbre(engine, p);
      return this._result({ status: 'P' + this._partLabel() + ' ' + this._groupName7(p).trim() });
    }

    if (this.mode === 'master-tune') {
      this.masterTune = Math.round(t * 127);
      if (engine && typeof engine.playSysex === 'function') {
        engine.playSysex(masterTuneSysex(this.masterTune, this._unit()));
      }
      return this._result({ status: 'Tune ' + formatHz(hzFromTune(this.masterTune)) });
    }

    if (this.mode === 'reverb') {
      this.reverbMode = Math.round(t * 10);
      this._sendReverb(engine);
      return this._result({ status: 'Reverb ' + this.reverbMode });
    }

    if (this.mode === 'unit-number') {
      this.unitNumber = Math.round(t * 31) + 1;
      return this._result({ status: 'Unit ' + this.unitNumber });
    }

    return this._result();
  }

  tick() {
    const t = this.now();
    if (this.banner && t >= this.banner.until) {
      this.banner = null;
      if (this.mode === 'main' && !this.partActiveUntil.some((u) => u > t)) {
        this.panelLcdActive = false;
      }
    }
    if (this.pcBanner && t >= this.pcBanner.until) this.pcBanner = null;
    if (this.chordSeq && t > this.chordSeq.until) this.chordSeq = null;
    if (this.held.has('master-volume') && this.masterDownAt && !this.masterLongArmed) {
      if (t - this.masterDownAt >= MASTER_LONG_MS) {
        this.masterLongArmed = true;
        this.masterStickyUntil = t + MASTER_STICKY_MS;
      }
    }
  }
}

export default Mt32FrontPanel;
