const LOOKAHEAD_MS = 200;
const TICK_MS = 20;
const CATCHUP_BURST_MS = 80;

export class MidiScheduler {
  constructor() {
    this._song = null;
    this._engine = null;
    this._audioContext = null;

    this._state = 'stopped';
    this._positionMs = 0;
    this._clockOriginMs = 0;
    this._songOriginMs = 0;

    this._eventIndex = 0;
    this._timerId = null;

    this.onStateChange = null;
    this.onEvent = null;
  }

  load(song) {
    this.stop();
    if (!song || !Array.isArray(song.events)) {
      throw new Error('[scheduler] load() expects { events[] } from parseSmf');
    }
    this._song = song;
    this._positionMs = 0;
    this._eventIndex = 0;
  }

  setEngine(engine) {
    this._engine = engine;
  }

  setAudioContext(ctx) {
    this._audioContext = ctx || null;
  }

  get state() {
    return this._state;
  }

  get positionMs() {
    if (this._state === 'playing') {
      return this._songOriginMs + (this._nowMs() - this._clockOriginMs);
    }
    return this._positionMs;
  }

  get song() {
    return this._song;
  }

  play() {
    if (!this._song) {
      throw new Error('[scheduler] no song loaded');
    }
    if (!this._engine || typeof this._engine.playMsg !== 'function') {
      throw new Error('[scheduler] no engine with playMsg()');
    }
    if (this._state === 'playing') return;

    if (
      this._state === 'stopped' &&
      this._eventIndex >= this._song.events.length
    ) {
      this._positionMs = 0;
      this._eventIndex = 0;
    }

    this._songOriginMs = this._positionMs;
    this._clockOriginMs = this._nowMs();
    this._setState('playing');
    this._scheduleLoop();
  }

  pause() {
    if (this._state !== 'playing') return;
    this._positionMs = this.positionMs;
    this._cancelTimers();
    this._setState('paused');
  }

  stop() {
    const was = this._state;
    this._cancelTimers();
    this._positionMs = 0;
    this._eventIndex = 0;
    this._songOriginMs = 0;
    this._clockOriginMs = 0;
    this._setState('stopped');

    if (was === 'playing' || was === 'paused') {
      this._allNotesOffAndReset();
    }
  }

  _nowMs() {
    if (this._audioContext && typeof this._audioContext.currentTime === 'number') {
      return this._audioContext.currentTime * 1000;
    }
    return performance.now();
  }

  _setState(s) {
    this._state = s;
    if (typeof this.onStateChange === 'function') {
      try {
        this.onStateChange(s);
      } catch (_) {}
    }
  }

  _cancelTimers() {
    if (this._timerId != null) {
      clearTimeout(this._timerId);
      this._timerId = null;
    }
  }

  _allNotesOffAndReset() {
    const eng = this._engine;
    if (!eng) return;
    try {
      for (let ch = 0; ch < 16; ch++) {
        eng.playMsg(0xb0 | ch, 123, 0);
        eng.playMsg(0xb0 | ch, 120, 0);
      }
    } catch (_) {}
    if (typeof eng.reset === 'function') {
      try {
        eng.reset();
      } catch (_) {}
    }
  }

  _scheduleLoop() {
    this._cancelTimers();
    if (this._state !== 'playing' || !this._song) return;

    const events = this._song.events;
    const songNow = this.positionMs;
    const until = songNow + LOOKAHEAD_MS;

    while (this._eventIndex < events.length) {
      const ev = events[this._eventIndex];
      if (ev.ms > until) break;
      // Late events still fire (catch-up) rather than being skipped.
      // Cap extreme catch-up bursts so a long tab-throttle dump is softer.
      if (ev.ms < songNow - CATCHUP_BURST_MS) {
        // Very late: still dispatch note-offs / controllers; skip pure note-ons far behind.
        const isNoteOn =
          ev.type === 'channel' &&
          (ev.status & 0xf0) === 0x90 &&
          (ev.data2 | 0) > 0;
        if (isNoteOn) {
          this._eventIndex++;
          continue;
        }
      }
      this._dispatch(ev);
      this._eventIndex++;
    }

    if (this._eventIndex >= events.length) {
      this._positionMs = 0;
      this._eventIndex = 0;
      this._cancelTimers();
      this._setState('stopped');
      this._allNotesOffAndReset();
      return;
    }

    this._timerId = setTimeout(() => {
      this._timerId = null;
      this._scheduleLoop();
    }, TICK_MS);
  }

  _dispatch(ev) {
    const eng = this._engine;
    if (!eng) return;

    try {
      if (ev.type === 'channel') {
        eng.playMsg(ev.status, ev.data1 | 0, ev.data2 | 0);
      } else if (ev.type === 'sysex' && typeof eng.playSysex === 'function') {
        eng.playSysex(ev.data);
      }
    } catch (err) {
      console.error('[scheduler] dispatch error', err);
    }

    if (typeof this.onEvent === 'function') {
      try {
        this.onEvent(ev);
      } catch (_) {}
    }
  }
}

export function createScheduler() {
  return new MidiScheduler();
}

export default MidiScheduler;
