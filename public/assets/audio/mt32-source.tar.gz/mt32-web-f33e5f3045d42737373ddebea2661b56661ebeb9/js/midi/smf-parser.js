import { parseSmfRaw } from '../../vendor/smf-parser/smf-parser.js';

const DEFAULT_TEMPO_US = 500_000;

function tempoFromMeta(data) {
  if (!data || data.length < 3) return DEFAULT_TEMPO_US;
  return ((data[0] << 16) | (data[1] << 8) | data[2]) >>> 0;
}

function toAbsoluteTickEvents(tracks) {
  const merged = [];

  for (const track of tracks) {
    let tick = 0;
    for (const ev of track.events) {
      tick += ev.delta | 0;
      const abs = {
        tick,
        track: track.index,
        type: ev.type,
      };
      if (ev.type === 'channel') {
        abs.status = ev.status;
        abs.data1 = ev.data1;
        abs.data2 = ev.data2;
        abs.data = ev.data;
      } else if (ev.type === 'sysex') {
        abs.status = ev.status;
        abs.data = ev.data;
      } else if (ev.type === 'meta') {
        abs.metaType = ev.metaType;
        abs.data = ev.data;
        if (ev.metaType === 0x51) {
          abs.tempoUs = tempoFromMeta(ev.data);
        }
      } else if (ev.type === 'system') {
        abs.status = ev.status;
        abs.data = ev.data;
      }
      merged.push(abs);
    }
  }

  merged.sort((a, b) => {
    if (a.tick !== b.tick) return a.tick - b.tick;
    return a.track - b.track;
  });

  return merged;
}

function applyTempoMap(events, division) {
  if (division <= 0) {
    throw new Error('SMF: invalid PPQ division');
  }

  let tempoUs = DEFAULT_TEMPO_US;
  let lastTick = 0;
  let lastMs = 0;

  for (const ev of events) {
    const dticks = ev.tick - lastTick;
    if (dticks > 0) {
      // ms = ticks * (µs/quarter) / (ticks/quarter) / 1000
      lastMs += (dticks * tempoUs) / division / 1000;
      lastTick = ev.tick;
    }
    ev.ms = lastMs;

    if (ev.type === 'meta' && ev.metaType === 0x51 && ev.tempoUs) {
      tempoUs = ev.tempoUs;
    }
  }

  return events;
}

/**
 * ArrayBuffer → { division, tracks, events[] } with absolute tick + ms (tempo map).
 * @param {ArrayBuffer|ArrayBufferView} buffer
 */
export function parseSmf(buffer) {
  const raw = parseSmfRaw(buffer);
  const abs = toAbsoluteTickEvents(raw.tracks);
  applyTempoMap(abs, raw.division);

  const durationMs = abs.length ? abs[abs.length - 1].ms : 0;

  return {
    format: raw.format,
    division: raw.division,
    tracks: raw.ntrks,
    events: abs,
    durationMs,
  };
}

export default parseSmf;
