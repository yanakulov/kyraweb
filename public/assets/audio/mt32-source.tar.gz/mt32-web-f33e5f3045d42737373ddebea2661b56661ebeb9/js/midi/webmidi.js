export const MIDI_INPUT_ALL = '__all__';
export const MIDI_INPUT_NONE = '__none__';

const PREF_MIDI_INPUT = 'mt32-web.midiInput';
const MIDI_LOG_MAX = 80;

let _onMidiMessage = null;
let _access = null;
let _selectedId = MIDI_INPUT_ALL;
let _onInputsChanged = null;
const _hooked = new Map();
const _midiLog = [];

function readPref() {
  try {
    return localStorage.getItem(PREF_MIDI_INPUT);
  } catch (_) {
    return null;
  }
}

function writePref(id) {
  try {
    if (id == null) localStorage.removeItem(PREF_MIDI_INPUT);
    else localStorage.setItem(PREF_MIDI_INPUT, id);
  } catch (_) {}
}

function flashLed() {
  const led = document.getElementById('led-midi');
  if (!led) return;
  led.classList.add('on');
  clearTimeout(led._flashTimer);
  led._flashTimer = setTimeout(() => {
    led.classList.remove('on');
  }, 100);
}

function toU8(data) {
  if (!data) return new Uint8Array(0);
  if (data instanceof Uint8Array) return data;
  if (ArrayBuffer.isView(data)) {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (Array.isArray(data)) return new Uint8Array(data.map((b) => b & 0xff));
  return new Uint8Array(0);
}

function bytesToHex(u8, max = 48) {
  const n = Math.min(u8.length, max);
  let s = '';
  for (let i = 0; i < n; i++) {
    if (i) s += ' ';
    s += u8[i].toString(16).toUpperCase().padStart(2, '0');
  }
  if (u8.length > max) s += ` …(+${u8.length - max})`;
  return s;
}

function formatMidiLine(u8, fromPortId) {
  if (!u8.length) return '(empty)';
  const st = u8[0] & 0xff;
  const port = fromPortId != null ? ` @${String(fromPortId).slice(0, 24)}` : '';
  if (st === 0xf0) {
    return `SysEx ${u8.length}B${port}: ${bytesToHex(u8)}`;
  }
  if (u8.length === 1) return `MIDI${port}: ${bytesToHex(u8)}`;
  if (u8.length === 2) return `MIDI${port}: ${bytesToHex(u8)}`;
  if (u8.length === 3) return `MIDI${port}: ${bytesToHex(u8)}`;
  return `MIDI ${u8.length}B${port}: ${bytesToHex(u8)}`;
}

function pushMidiLog(line) {
  const entry = { t: Date.now(), line };
  _midiLog.push(entry);
  if (_midiLog.length > MIDI_LOG_MAX) _midiLog.splice(0, _midiLog.length - MIDI_LOG_MAX);

  if (window.__debug) {
    window.__debug.lastMidiLine = line;
    window.__debug.midiLog = _midiLog.slice(-MIDI_LOG_MAX);
  }

  const el = document.getElementById('midi-debug-log');
  if (el) {
    const row = document.createElement('div');
    row.className = 'midi-debug-line';
    const ts = new Date(entry.t).toISOString().slice(11, 23);
    row.textContent = `${ts} ${line}`;
    el.appendChild(row);
    while (el.childElementCount > MIDI_LOG_MAX) el.removeChild(el.firstChild);
    el.scrollTop = el.scrollHeight;
  }

  console.info('[midi-in]', line);
}

function ensureMidiDebugPanel() {
  if (typeof document === 'undefined') return;
  if (document.getElementById('midi-debug-log')) return;
  if (!window.location.search.includes('debug=1') && !window.__debug) return;

  const host = document.querySelector('.hud-meta') || document.querySelector('.hud') || document.body;
  const wrap = document.createElement('div');
  wrap.id = 'midi-debug-wrap';
  wrap.className = 'midi-debug-wrap';
  wrap.innerHTML =
    '<div class="midi-debug-title">MIDI in (debug)</div>' +
    '<div id="midi-debug-log" class="midi-debug-log" aria-live="polite"></div>';
  host.appendChild(wrap);

  if (!document.getElementById('midi-debug-style')) {
    const st = document.createElement('style');
    st.id = 'midi-debug-style';
    st.textContent =
      '.midi-debug-wrap{margin-top:8px;max-width:100%;font:11px/1.35 ui-monospace,Consolas,monospace;}' +
      '.midi-debug-title{opacity:.75;margin-bottom:4px;}' +
      '.midi-debug-log{max-height:140px;overflow:auto;background:rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.12);' +
      'border-radius:6px;padding:6px 8px;color:#c8f0c8;}' +
      '.midi-debug-line{white-space:pre-wrap;word-break:break-all;border-bottom:1px solid rgba(255,255,255,.06);padding:1px 0;}' +
      '.midi-debug-line:last-child{border-bottom:0;}';
    document.head.appendChild(st);
  }
}

function dispatchBytes(raw, fromPortId) {
  const u8 = toU8(raw);
  if (!u8.length) return;

  if (fromPortId != null) {
    if (_selectedId === MIDI_INPUT_NONE) return;
    if (_selectedId !== MIDI_INPUT_ALL && _selectedId !== fromPortId) return;
  }

  flashLed();

  const line = formatMidiLine(u8, fromPortId);
  pushMidiLog(line);

  const status = u8[0] & 0xff;
  const d1 = u8.length > 1 ? u8[1] & 0xff : 0;
  const d2 = u8.length > 2 ? u8[2] & 0xff : 0;

  if (window.__debug) {
    window.__debug.lastMidi = [status, d1, d2];
    window.__debug.lastMidiBytes = Array.from(u8);
    window.__debug.lastMidiPortId = fromPortId;
    window.__debug.lastMidiIsSysex = status === 0xf0;
  }

  if (typeof _onMidiMessage === 'function') {
    _onMidiMessage(status, d1, d2, u8, fromPortId);
  }
}

function dispatch(status, d1, d2, fromPortId) {
  dispatchBytes([status & 0xff, (d1 | 0) & 0xff, (d2 | 0) & 0xff], fromPortId);
}

function unhookInput(input) {
  try {
    input.onmidimessage = null;
  } catch (_) {}
}

function hookInput(input) {
  if (!input || input.type !== 'input') return;

  input.onmidimessage = (ev) => {
    const d = ev.data;
    if (!d || d.length < 1) return;
    dispatchBytes(d, input.id);
  };
  _hooked.set(input.id, input);
}

function rehookAllInputs() {
  if (!_access) return;

  for (const input of _access.inputs.values()) {
    hookInput(input);
  }

  for (const [id, input] of [..._hooked.entries()]) {
    if (!_access.inputs.has(id)) {
      unhookInput(input);
      _hooked.delete(id);
    }
  }
}

function notifyInputsChanged() {
  if (typeof _onInputsChanged !== 'function') return;
  try {
    _onInputsChanged(listMidiInputs(), _selectedId);
  } catch (_) {}
}

export function listMidiInputs() {
  if (!_access) return [];
  const out = [];
  for (const input of _access.inputs.values()) {
    out.push({
      id: input.id,
      name: input.name || input.id,
      manufacturer: input.manufacturer || '',
      state: input.state || 'connected',
    });
  }
  out.sort((a, b) => a.name.localeCompare(b.name));
  return out;
}

export function getSelectedMidiInputId() {
  return _selectedId;
}

export function setSelectedMidiInputId(id) {
  const next =
    id === MIDI_INPUT_NONE || id === MIDI_INPUT_ALL || (typeof id === 'string' && id.length > 0)
      ? id
      : MIDI_INPUT_ALL;

  _selectedId = next;
  writePref(_selectedId);

  if (window.__debug) {
    window.__debug.midiInputId = _selectedId;
  }

  return _selectedId;
}

export function setMidiInputsChangedHandler(fn) {
  _onInputsChanged = typeof fn === 'function' ? fn : null;
}

export function isWebMidiAvailable() {
  return typeof navigator !== 'undefined' && typeof navigator.requestMIDIAccess === 'function';
}

export function hasMidiAccess() {
  return _access != null;
}

export function getMidiLog() {
  return _midiLog.slice();
}

export function clearMidiLog() {
  _midiLog.length = 0;
  const el = document.getElementById('midi-debug-log');
  if (el) el.replaceChildren();
}

export async function requestWebMidi(onMessage) {
  _onMidiMessage = onMessage || null;
  ensureMidiDebugPanel();

  const pref = readPref();
  if (pref === MIDI_INPUT_ALL || pref === MIDI_INPUT_NONE || (typeof pref === 'string' && pref.length > 0)) {
    _selectedId = pref;
  }

  if (!isWebMidiAvailable()) {
    console.info('[webmidi] Web MIDI API not available in this browser');
    pushMidiLog('Web MIDI API not available');
    notifyInputsChanged();
    return null;
  }

  let access;
  try {
    access = await navigator.requestMIDIAccess({ sysex: true });
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    console.info('[webmidi] MIDI access denied:', msg);
    pushMidiLog('MIDI access denied: ' + msg + ' (need sysex permission)');
    _access = null;
    notifyInputsChanged();
    return null;
  }

  _access = access;
  rehookAllInputs();

  access.onstatechange = (e) => {
    if (!e.port || e.port.type !== 'input') return;

    if (e.port.state === 'connected') {
      hookInput(e.port);
      pushMidiLog(`input connected: ${e.port.name || e.port.id}`);
    } else if (e.port.state === 'disconnected') {
      unhookInput(e.port);
      _hooked.delete(e.port.id);
      pushMidiLog(`input disconnected: ${e.port.name || e.port.id}`);
    }
    notifyInputsChanged();
  };

  const names = listMidiInputs()
    .map((i) => i.name)
    .join(', ');
  console.info('[webmidi] MIDI access granted (sysex=true)');
  pushMidiLog(`MIDI access OK (sysex). inputs: ${names || '(none)'}`);
  notifyInputsChanged();
  return access;
}

export function setupDebugMidi() {
  if (!window.__debug) return;
  ensureMidiDebugPanel();

  window.__debug.injectMidi = (msg) => {
    if (msg == null) return;
    if (typeof msg === 'string') {
      const hex = msg.trim().split(/[\s,]+/).filter(Boolean).map((h) => parseInt(h, 16) & 0xff);
      if (!hex.length || hex.some((n) => Number.isNaN(n))) return;
      dispatchBytes(hex, null);
      return;
    }
    dispatchBytes(msg, null);
  };

  window.__debug.listMidiInputs = () => listMidiInputs();
  window.__debug.getMidiInput = () => getSelectedMidiInputId();
  window.__debug.setMidiInput = (id) => setSelectedMidiInputId(id);
  window.__debug.midiInputId = _selectedId;
  window.__debug.getMidiLog = () => getMidiLog();
  window.__debug.clearMidiLog = () => clearMidiLog();

  if (window.__debug.lastMidi === undefined) {
    window.__debug.lastMidi = null;
  }
  if (window.__debug.midiLog === undefined) {
    window.__debug.midiLog = [];
  }
}
