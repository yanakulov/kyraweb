AdPlug and Nuked OPL3 source from https://github.com/adplug/adplug/tree/3d9457ac91121302a752577b2bf063b4aea202b8
Kyrandia Web uses the Westwood driver and the OPL2-compatible mode of Nuked OPL3.
To rebuild the extracted source, run: node build.mjs . . /path/to/zig
